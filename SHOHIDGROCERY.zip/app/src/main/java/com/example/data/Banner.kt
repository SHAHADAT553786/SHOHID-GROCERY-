package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "banners")
data class BannerEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val section: String, // "top", "middle", "bottom"
    val title: String,
    val subtitle: String,
    val targetCategory: String, // "Groceries", "Bakery & Desserts", etc.
    val backgroundColor: String, // Hex or gradient styling key
    val imageEmoji: String, // Rich representation of illustration
    val active: Boolean = true
)

@Dao
interface BannerDao {
    @Query("SELECT * FROM banners")
    fun getAllBanners(): Flow<List<BannerEntity>>

    @Query("SELECT * FROM banners WHERE section = :section AND active = 1")
    fun getActiveBannersBySection(section: String): Flow<List<BannerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanner(banner: BannerEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBanners(banners: List<BannerEntity>)

    @Update
    suspend fun updateBanner(banner: BannerEntity)

    @Query("DELETE FROM banners WHERE id = :id")
    suspend fun deleteBanner(id: Int)
}
