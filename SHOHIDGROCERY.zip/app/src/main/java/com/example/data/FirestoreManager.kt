package com.example.data

import android.content.Context
import android.util.Log
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

// A clean extension function to wait for Tasks (like Firestore tasks)
suspend fun <T> Task<T>.awaitTask(): T = suspendCancellableCoroutine { continuation ->
    addOnCompleteListener { task ->
        if (task.isSuccessful) {
            continuation.resume(task.result)
        } else {
            continuation.resumeWithException(task.exception ?: RuntimeException("Firestore task failed"))
        }
    }
}

data class Supplier(
    val id: String = "",
    val name: String = "",
    val contact: String = "",
    val email: String = "",
    val category: String = "",
    val address: String = ""
)

data class Category(
    val id: String = "",
    val name: String = "",
    val iconResName: String = "",
    val description: String = ""
)

data class User(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val address: String = "",
    val registeredAt: Long = 0L,
    val role: String = "customer", // customer / admin
    val photoUrl: String = "",
    val createdAt: Long = 0L
)

data class CartItem(
    val productId: Int = 0,
    val quantity: Int = 0
)

data class Cart(
    val id: String = "",
    val items: List<CartItem> = emptyList(),
    val lastUpdated: Long = 0L
)

object FirestoreManager {
    private const val TAG = "FirestoreManager"
    private var firestoreInstance: FirebaseFirestore? = null

    fun initialize(context: Context) {
        if (firestoreInstance != null) return
        try {
            val app = try {
                FirebaseApp.getInstance()
            } catch (e: Exception) {
                null
            }

            if (app != null) {
                Log.d(TAG, "FirebaseApp already initialized with project ID: ${app.options.projectId}")
                firestoreInstance = FirebaseFirestore.getInstance()
            } else {
                Log.d(TAG, "Initializing FirebaseApp programmatically with custom configuration...")
                try {
                    val options = FirebaseOptions.Builder()
                        .setApplicationId("1:420614408730:android:2483357216d5e21806dfa3")
                        .setApiKey("AIzaSyC1DbWYOU3e_2UmCWU7fos7Hm1qV5iVxxc")
                        .setProjectId("shohid-grocery")
                        .setStorageBucket("shohid-grocery.firebasestorage.app")
                        .build()
                    FirebaseApp.initializeApp(context.applicationContext, options)
                    firestoreInstance = FirebaseFirestore.getInstance()
                    Log.d(TAG, "FirebaseApp initialized programmatically.")
                } catch (pe: Exception) {
                    Log.e(TAG, "Custom programmatic init failed, falling back...", pe)
                    val options = FirebaseOptions.Builder()
                        .setApplicationId("1:1781649758281:android:3e020ddc94f1c9533f81e3")
                        .setApiKey("AIzaSyB0x-Goc-Shohid-Grocery-Project-InitialKey")
                        .setProjectId("shohid-grocery-db")
                        .setDatabaseUrl("https://shohid-grocery-db.firebaseio.com")
                        .build()
                    FirebaseApp.initializeApp(context.applicationContext, options)
                    firestoreInstance = FirebaseFirestore.getInstance()
                }
            }
            Log.d(TAG, "Firestore successfully initialized.")
        } catch (e: Exception) {
            Log.e(TAG, "Firestore initialization error: ${e.message}", e)
        }
    }

    suspend fun testFirestoreConnection(): String {
        return try {
            Log.d(TAG, "1. Writing Connection Test...")
            val data = mapOf(
                "message" to "Firebase Connected",
                "time" to java.util.Date()
            )
            val docRef = getDb().collection("test").document()
            docRef.set(data).awaitTask()

            Log.d(TAG, "2. Seeding Categories Collection...")
            seedDefaultData()

            Log.d(TAG, "3. Verifying Users Collection...")
            val testUser = User(
                id = "test_user_id",
                name = "Test Connection User",
                email = "test@shohidgrocery.com",
                phone = "01700000000",
                address = "Shohid Grocery Firebase Studio",
                registeredAt = System.currentTimeMillis(),
                role = "admin"
            )
            saveUser(testUser)

            Log.d(TAG, "4. Verifying Cart Collection...")
            val testCart = Cart(
                id = "test_user_id",
                items = listOf(CartItem(productId = 1, quantity = 5)),
                lastUpdated = System.currentTimeMillis()
            )
            saveCartSingular(testCart)

            Log.d(TAG, "5. Verifying Products Collection...")
            val existingProducts = getProducts()
            val prodCount = existingProducts.size

            "Success! Connected to Firebase Firestore.\n\n" +
                    "• Collection 'test': Created doc /test/${docRef.id}\n" +
                    "• Collection 'categories': Seeded default product categories\n" +
                    "• Collection 'users': Created doc /users/test_user_id\n" +
                    "• Collection 'cart': Created doc /cart/test_user_id\n" +
                    "• Collection 'products': Confirmed active sync ($prodCount products available)"
        } catch (e: Exception) {
            Log.e(TAG, "Firestore connection test failed: ${e.message}", e)
            throw e
        }
    }

    private fun getDb(): FirebaseFirestore {
        if (firestoreInstance == null) {
            Log.e(TAG, "Firestore is null, returning static instance.")
            return FirebaseFirestore.getInstance()
        }
        return firestoreInstance!!
    }

    // ==========================================
    // 1. PRODUCTS COLLECTION CRUD
    // ==========================================
    suspend fun getProducts(): List<ProductEntity> {
        return try {
            val snapshot = getDb().collection("products").get().awaitTask()
            val list = mutableListOf<ProductEntity>()
            for (doc in snapshot.documents) {
                try {
                    val idStr = doc.id
                    val id = idStr.toIntOrNull() ?: doc.getLong("id")?.toInt() ?: continue
                    val title = doc.getString("title") ?: ""
                    val description = doc.getString("description") ?: ""
                    val price = doc.getDouble("price") ?: 0.0
                    val originalPrice = doc.getDouble("originalPrice") ?: price
                    val category = doc.getString("category") ?: "Groceries"
                    val rating = doc.getDouble("rating") ?: 4.5
                    val unit = doc.getString("unit") ?: "1 unit"
                    val imageLocalResName = doc.getString("imageLocalResName") ?: "ic_bananas"
                    val rollback = doc.getBoolean("rollback") ?: false
                    val stock = doc.getLong("stock")?.toInt() ?: 100
                    val calories = doc.getLong("calories")?.toInt() ?: 0
                    val organic = doc.getBoolean("organic") ?: false

                    list.add(
                        ProductEntity(
                            id = id,
                            title = title,
                            description = description,
                            price = price,
                            originalPrice = originalPrice,
                            category = category,
                            rating = rating,
                            unit = unit,
                            imageLocalResName = imageLocalResName,
                            rollback = rollback,
                            stock = stock,
                            calories = calories,
                            organic = organic
                        )
                    )
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing product: ${doc.id}", e)
                }
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "Error getting products: ${e.message}")
            emptyList()
        }
    }

    suspend fun saveProduct(product: ProductEntity) {
        try {
            val data = mapOf(
                "id" to product.id,
                "title" to product.title,
                "description" to product.description,
                "price" to product.price,
                "originalPrice" to product.originalPrice,
                "category" to product.category,
                "rating" to product.rating,
                "unit" to product.unit,
                "imageLocalResName" to product.imageLocalResName,
                "rollback" to product.rollback,
                "stock" to product.stock,
                "calories" to product.calories,
                "organic" to product.organic
            )
            getDb().collection("products").document(product.id.toString())
                .set(data, SetOptions.merge())
                .awaitTask()
            
            // Sync with inventory automatically
            updateInventoryFromProduct(product)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving product to Firestore: ${e.message}")
        }
    }

    suspend fun deleteProduct(id: Int) {
        try {
            getDb().collection("products").document(id.toString()).delete().awaitTask()
            getDb().collection("inventory").document(id.toString()).delete().awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting product from Firestore: ${e.message}")
        }
    }

    // ==========================================
    // 2. INVENTORY COLLECTION CRUD
    // ==========================================
    suspend fun getInventoryList(): List<Map<String, Any>> {
        return try {
            val snapshot = getDb().collection("inventory").get().awaitTask()
            snapshot.documents.map { doc ->
                val data = doc.data ?: emptyMap<String, Any>()
                data + ("docId" to doc.id)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting inventory: ${e.message}")
            emptyList()
        }
    }

    suspend fun updateInventoryFromProduct(product: ProductEntity) {
        try {
            val status = when {
                product.stock <= 0 -> "Out of Stock"
                product.stock < 20 -> "Low Stock"
                else -> "In Stock"
            }
            val data = mapOf(
                "productId" to product.id,
                "productTitle" to product.title,
                "stock" to product.stock,
                "status" to status,
                "lastUpdated" to System.currentTimeMillis()
            )
            getDb().collection("inventory").document(product.id.toString())
                .set(data, SetOptions.merge())
                .awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error updating inventory in Firestore: ${e.message}")
        }
    }

    suspend fun updateInventoryQty(productId: Int, newStock: Int) {
        try {
            val status = when {
                newStock <= 0 -> "Out of Stock"
                newStock < 20 -> "Low Stock"
                else -> "In Stock"
            }
            val data = mapOf(
                "stock" to newStock,
                "status" to status,
                "lastUpdated" to System.currentTimeMillis()
            )
            getDb().collection("inventory").document(productId.toString())
                .set(data, SetOptions.merge())
                .awaitTask()

            // Also update the stock on the product document!
            getDb().collection("products").document(productId.toString())
                .set(mapOf("stock" to newStock), SetOptions.merge())
                .awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error updating inventory quantity: ${e.message}")
        }
    }

    // ==========================================
    // 3. ORDERS COLLECTION CRUD
    // ==========================================
    suspend fun getOrders(): List<OrderEntity> {
        return try {
            val snapshot = getDb().collection("orders").get().awaitTask()
            val list = mutableListOf<OrderEntity>()
            for (doc in snapshot.documents) {
                try {
                    val id = doc.getString("id") ?: doc.id
                    val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                    val status = doc.getString("status") ?: "Processing"
                    val total = doc.getDouble("total") ?: 0.0
                    val savings = doc.getDouble("savings") ?: 0.0
                    val deliveryType = doc.getString("deliveryType") ?: "Delivery"
                    val itemsJson = doc.getString("itemsJson") ?: "[]"
                    list.add(OrderEntity(id, timestamp, status, total, savings, deliveryType, itemsJson))
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing order document: ${doc.id}", e)
                }
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "Error getting orders from Firestore: ${e.message}")
            emptyList()
        }
    }

    suspend fun saveOrder(order: OrderEntity, userId: String? = null) {
        try {
            val finalUserId = userId ?: try {
                com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.phoneNumber
            } catch (ex: Exception) {
                null
            }
            val data = mapOf(
                "id" to order.id,
                "timestamp" to order.timestamp,
                "status" to order.status,
                "total" to order.total,
                "savings" to order.savings,
                "deliveryType" to order.deliveryType,
                "itemsJson" to order.itemsJson,
                "userId" to (finalUserId ?: "")
            )
            getDb().collection("orders").document(order.id).set(data).awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving order to Firestore: ${e.message}")
        }
    }

    suspend fun deleteOrder(orderId: String) {
        try {
            getDb().collection("orders").document(orderId).delete().awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting order: ${e.message}")
        }
    }

    suspend fun updateOrderStatus(orderId: String, status: String) {
        try {
            getDb().collection("orders").document(orderId)
                .set(mapOf("status" to status), SetOptions.merge())
                .awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error updating order status in Firestore: ${e.message}")
        }
    }

    // ==========================================
    // 4. CUSTOMERS COLLECTION CRUD
    // ==========================================
    suspend fun getCustomers(): List<Map<String, Any>> {
        return try {
            val snapshot = getDb().collection("customers").get().awaitTask()
            snapshot.documents.map { doc ->
                val data = doc.data ?: emptyMap<String, Any>()
                data + ("phone" to doc.id)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting customers list: ${e.message}")
            emptyList()
        }
    }

    suspend fun saveCustomer(phone: String, name: String) {
        try {
            val data = mapOf(
                "name" to name,
                "phone" to phone,
                "registeredAt" to System.currentTimeMillis()
            )
            getDb().collection("customers").document(phone).set(data, SetOptions.merge()).awaitTask()

            // Synchronize with the new requested 'users' collection model
            val user = User(
                id = phone,
                name = name,
                phone = phone,
                registeredAt = System.currentTimeMillis(),
                role = "customer"
            )
            saveUser(user)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving customer to Firestore: ${e.message}")
        }
    }

    suspend fun deleteCustomer(phone: String) {
        try {
            getDb().collection("customers").document(phone).delete().awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting customer: ${e.message}")
        }
    }

    // ==========================================
    // 5. SUPPLIERS COLLECTION CRUD
    // ==========================================
    suspend fun getSuppliers(): List<Supplier> {
        return try {
            val snapshot = getDb().collection("suppliers").get().awaitTask()
            val list = mutableListOf<Supplier>()
            for (doc in snapshot.documents) {
                try {
                    val id = doc.getString("id") ?: doc.id
                    val name = doc.getString("name") ?: ""
                    val contact = doc.getString("contact") ?: ""
                    val email = doc.getString("email") ?: ""
                    val category = doc.getString("category") ?: "All"
                    val address = doc.getString("address") ?: ""
                    list.add(Supplier(id, name, contact, email, category, address))
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing supplier: ${doc.id}", e)
                }
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "Error getting suppliers: ${e.message}")
            emptyList()
        }
    }

    suspend fun saveSupplier(supplier: Supplier) {
        try {
            val data = mapOf(
                "id" to supplier.id,
                "name" to supplier.name,
                "contact" to supplier.contact,
                "email" to supplier.email,
                "category" to supplier.category,
                "address" to supplier.address
            )
            getDb().collection("suppliers").document(supplier.id).set(data, SetOptions.merge()).awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving supplier to Firestore: ${e.message}")
        }
    }

    suspend fun deleteSupplier(supplierId: String) {
        try {
            getDb().collection("suppliers").document(supplierId).delete().awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting supplier: ${e.message}")
        }
    }

    // ==========================================
    // 6. CART RESIDENT SYNC
    // ==========================================
    suspend fun saveCart(phone: String, items: List<CartItemEntity>) {
        if (phone.isEmpty()) return
        try {
            val listData = items.map {
                mapOf("productId" to it.productId, "quantity" to it.quantity)
            }
            val data = mapOf("items" to listData, "lastUpdated" to System.currentTimeMillis())
            getDb().collection("carts").document(phone).set(data).awaitTask()

            // Synchronize with the new requested 'cart' (singular) collection model
            val singularItems = items.map { CartItem(it.productId, it.quantity) }
            val singularCart = Cart(
                id = phone,
                items = singularItems,
                lastUpdated = System.currentTimeMillis()
            )
            saveCartSingular(singularCart)
        } catch (e: Exception) {
            Log.e(TAG, "Error saving cart in Firestore: ${e.message}")
        }
    }

    @Suppress("UNCHECKED_CAST")
    suspend fun getCart(phone: String): List<CartItemEntity> {
        if (phone.isEmpty()) return emptyList()
        return try {
            val doc = getDb().collection("carts").document(phone).get().awaitTask()
            if (doc.exists()) {
                val list = doc.get("items") as? List<Map<String, Any>> ?: emptyList()
                list.mapNotNull { itemMap ->
                    val prodId = (itemMap["productId"] as? Long)?.toInt() ?: return@mapNotNull null
                    val qty = (itemMap["quantity"] as? Long)?.toInt() ?: 1
                    CartItemEntity(prodId, qty)
                }
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting cart from Firestore: ${e.message}")
            emptyList()
        }
    }

    // ==========================================
    // 7. CATEGORIES COLLECTION CRUD
    // ==========================================
    suspend fun getCategories(): List<Category> {
        return try {
            val snapshot = getDb().collection("categories").get().awaitTask()
            snapshot.documents.mapNotNull { doc ->
                try {
                    val id = doc.id
                    val name = doc.getString("name") ?: ""
                    val iconResName = doc.getString("iconResName") ?: ""
                    val description = doc.getString("description") ?: ""
                    Category(id, name, iconResName, description)
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing category: ${doc.id}", e)
                    null
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting categories: ${e.message}")
            emptyList()
        }
    }

    suspend fun saveCategory(category: Category) {
        try {
            val data = mapOf(
                "id" to category.id,
                "name" to category.name,
                "iconResName" to category.iconResName,
                "description" to category.description
            )
            getDb().collection("categories").document(category.id).set(data, SetOptions.merge()).awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving category: ${e.message}")
        }
    }

    suspend fun deleteCategory(id: String) {
        try {
            getDb().collection("categories").document(id).delete().awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting category: ${e.message}")
        }
    }

    // ==========================================
    // 8. USERS COLLECTION CRUD
    // ==========================================
    suspend fun getUsers(): List<User> {
        return try {
            val snapshot = getDb().collection("users").get().awaitTask()
            snapshot.documents.mapNotNull { doc ->
                try {
                    val id = doc.id
                    val name = doc.getString("name") ?: ""
                    val email = doc.getString("email") ?: ""
                    val phone = doc.getString("phone") ?: ""
                    val address = doc.getString("address") ?: ""
                    val registeredAt = doc.getLong("registeredAt") ?: 0L
                    val role = doc.getString("role") ?: "customer"
                    val photoUrl = doc.getString("photoUrl") ?: ""
                    val createdAt = doc.getLong("createdAt") ?: 0L
                    User(id, name, email, phone, address, registeredAt, role, photoUrl, createdAt)
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing user: ${doc.id}", e)
                    null
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting users: ${e.message}")
            emptyList()
        }
    }

    suspend fun saveUser(user: User) {
        try {
            val data = mapOf(
                "id" to user.id,
                "name" to user.name,
                "email" to user.email,
                "phone" to user.phone,
                "address" to user.address,
                "registeredAt" to user.registeredAt,
                "role" to user.role,
                "photoUrl" to user.photoUrl,
                "createdAt" to user.createdAt
            )
            getDb().collection("users").document(user.id).set(data, SetOptions.merge()).awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving user: ${e.message}")
        }
    }

    suspend fun deleteUser(userId: String) {
        try {
            getDb().collection("users").document(userId).delete().awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting user: ${e.message}")
        }
    }

    // ==========================================
    // 9. CART SINGLE COLLECTION CRUD (SINGULAR 'cart')
    // ==========================================
    suspend fun saveCartSingular(cart: Cart) {
        if (cart.id.isEmpty()) return
        try {
            val listData = cart.items.map {
                mapOf("productId" to it.productId, "quantity" to it.quantity)
            }
            val data = mapOf(
                "id" to cart.id,
                "items" to listData,
                "lastUpdated" to cart.lastUpdated
            )
            getDb().collection("cart").document(cart.id).set(data).awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving singular cart to Firestore: ${e.message}")
        }
    }

    @Suppress("UNCHECKED_CAST")
    suspend fun getCartSingular(cartId: String): Cart {
        if (cartId.isEmpty()) return Cart()
        return try {
            val doc = getDb().collection("cart").document(cartId).get().awaitTask()
            if (doc.exists()) {
                val listMap = doc.get("items") as? List<Map<String, Any>> ?: emptyList()
                val items = listMap.mapNotNull { itemMap ->
                    val prodId = (itemMap["productId"] as? Long)?.toInt() ?: return@mapNotNull null
                    val qty = (itemMap["quantity"] as? Long)?.toInt() ?: 1
                    CartItem(prodId, qty)
                }
                val lastUpdated = doc.getLong("lastUpdated") ?: 0L
                Cart(id = cartId, items = items, lastUpdated = lastUpdated)
            } else {
                Cart(id = cartId)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting singular cart: ${e.message}")
            Cart(id = cartId)
        }
    }

    suspend fun deleteCartSingular(cartId: String) {
        try {
            getDb().collection("cart").document(cartId).delete().awaitTask()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting singular cart: ${e.message}")
        }
    }

    // ==========================================
    // Seed default categories & products to Firestore
    // ==========================================
    suspend fun seedDefaultData() {
        try {
            val categories = listOf(
                Category("groceries", "Groceries", "ic_bananas", "Fresh fruits, vegetables, and daily grocery items"),
                Category("bakery", "Bakery & Desserts", "ic_bread", "Delicious breads, cakes, pastries, and treats"),
                Category("seafood", "Meat & Seafood", "ic_chicken", "Premium meats, poultry, and fresh seafood"),
                Category("dairy", "Dairy & Eggs", "ic_milk", "Fresh milk, hand-made butter, cheeses, and eggs"),
                Category("beverages", "Beverages", "ic_beverage", "Cool beverages, natural fruit juices, sodas, and water"),
                Category("snacks", "Pantry & Snacks", "ic_chips", "Crunchy chips, biscuits, chocolates, and condiments"),
                Category("household", "Household Essentials", "ic_cleaner", "Cleaning items, laundry liquids, and home care products")
            )
            for (cat in categories) {
                saveCategory(cat)
            }
            Log.d(TAG, "Default categories successfully seeded to Firestore.")
        } catch (e: Exception) {
            Log.e(TAG, "Error seeding categories: ${e.message}")
        }
    }
}
