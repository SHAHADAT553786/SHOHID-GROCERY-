package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class FreshMartRepository(
    private val productDao: ProductDao,
    private val cartDao: CartDao,
    private val orderDao: OrderDao,
    private val favoriteDao: FavoriteDao,
    private val bannerDao: BannerDao
) {
    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
    val cartItems: Flow<List<CartItemEntity>> = cartDao.getCartItems()
    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()
    val favorites: Flow<List<FavoriteEntity>> = favoriteDao.getFavorites()
    val allBanners: Flow<List<BannerEntity>> = bannerDao.getAllBanners()

    fun getActiveBannersBySection(section: String): Flow<List<BannerEntity>> =
        bannerDao.getActiveBannersBySection(section)

    suspend fun saveBanner(banner: BannerEntity) = withContext(Dispatchers.IO) {
        bannerDao.insertBanner(banner)
    }

    suspend fun deleteBanner(id: Int) = withContext(Dispatchers.IO) {
        bannerDao.deleteBanner(id)
    }

    fun getProductsByCategory(category: String): Flow<List<ProductEntity>> =
        productDao.getProductsByCategory(category)

    fun getRollbackProducts(): Flow<List<ProductEntity>> =
        productDao.getRollbackProducts()

    fun searchProducts(query: String): Flow<List<ProductEntity>> =
        productDao.searchProducts(query)

    suspend fun getProductById(id: Int): ProductEntity? = withContext(Dispatchers.IO) {
        productDao.getProductById(id)
    }

    suspend fun addToCart(productId: Int, quantity: Int) = withContext(Dispatchers.IO) {
        val existing = cartItems.first().find { it.productId == productId }
        if (existing != null) {
            cartDao.updateCartItem(existing.copy(quantity = existing.quantity + quantity))
        } else {
            cartDao.addToCart(CartItemEntity(productId, quantity))
        }
    }

    suspend fun updateCartQuantity(productId: Int, quantity: Int) = withContext(Dispatchers.IO) {
        if (quantity <= 0) {
            cartDao.removeFromCart(productId)
        } else {
            cartDao.updateCartItem(CartItemEntity(productId, quantity))
        }
    }

    suspend fun removeFromCart(productId: Int) = withContext(Dispatchers.IO) {
        cartDao.removeFromCart(productId)
    }

    suspend fun clearCart() = withContext(Dispatchers.IO) {
        cartDao.clearCart()
    }

    suspend fun placeOrder(
        id: String,
        total: Double,
        savings: Double,
        deliveryType: String,
        itemsJson: String
    ) = withContext(Dispatchers.IO) {
        val order = OrderEntity(
            id = id,
            timestamp = System.currentTimeMillis(),
            status = if (deliveryType == "Delivery") "Processing" else "Ready for Pickup",
            total = total,
            savings = savings,
            deliveryType = deliveryType,
            itemsJson = itemsJson
        )
        orderDao.insertOrder(order)
        cartDao.clearCart()
    }

    suspend fun toggleFavorite(productId: Int) = withContext(Dispatchers.IO) {
        if (favoriteDao.isFavorite(productId)) {
            favoriteDao.removeFavorite(productId)
        } else {
            favoriteDao.addFavorite(FavoriteEntity(productId))
        }
    }

    suspend fun isFavorite(productId: Int): Boolean = withContext(Dispatchers.IO) {
        favoriteDao.isFavorite(productId)
    }

    suspend fun saveProduct(product: ProductEntity) = withContext(Dispatchers.IO) {
        productDao.insertProduct(product)
    }

    suspend fun deleteProduct(productId: Int) = withContext(Dispatchers.IO) {
        productDao.deleteProduct(productId)
    }

    suspend fun updateOrderStatus(id: String, status: String) = withContext(Dispatchers.IO) {
        orderDao.updateOrderStatus(id, status)
    }

    suspend fun deleteOrder(id: String) = withContext(Dispatchers.IO) {
        orderDao.deleteOrder(id)
    }

    suspend fun insertProducts(products: List<ProductEntity>) = withContext(Dispatchers.IO) {
        productDao.insertProducts(products)
    }

    suspend fun insertOrderDirectly(order: OrderEntity) = withContext(Dispatchers.IO) {
        orderDao.insertOrder(order)
    }

    suspend fun seedIfNeeded() = withContext(Dispatchers.IO) {
        val list = productDao.getAllProducts().first()
        if (list.isEmpty()) {
            val seedProducts = listOf(
                ProductEntity(
                    id = 1,
                    title = "Organic Bananas",
                    description = "Sweet, delicious organic bananas imported fresh daily. Perfect for healthy smoothies, baking, or an easy grab-and-go snack.",
                    price = 1.89,
                    originalPrice = 2.49,
                    category = "Groceries",
                    rating = 4.8,
                    unit = "1 bunch (5-6 bananas)",
                    imageLocalResName = "ic_bananas",
                    rollback = true,
                    stock = 150,
                    calories = 105,
                    organic = true
                ),
                ProductEntity(
                    id = 2,
                    title = "Honeycrisp Apples",
                    description = "Crunchy, sweet, and delightfully juicy handpicked apples. Ideal for snacks, lunchbox additions, or warm crumbles.",
                    price = 3.49,
                    originalPrice = 3.49,
                    category = "Groceries",
                    rating = 4.6,
                    unit = "3 lb bag",
                    imageLocalResName = "ic_apples",
                    rollback = false,
                    stock = 80,
                    calories = 80,
                    organic = false
                ),
                ProductEntity(
                    id = 3,
                    title = "Organic Hass Avocados",
                    description = "Rich, creamy green Haas avocados; packed with heart-healthy monounsaturated fats. Perfect for salads, toast, and fresh guacamole.",
                    price = 4.99,
                    originalPrice = 5.99,
                    category = "Groceries",
                    rating = 4.7,
                    unit = "4-pack bag",
                    imageLocalResName = "ic_avocado",
                    rollback = true,
                    stock = 120,
                    calories = 240,
                    organic = true
                ),
                ProductEntity(
                    id = 4,
                    title = "Fresh Strawberries",
                    description = "Incredibly sweet, bright red succulent strawberries sourced locally from sustainable family farming partners.",
                    price = 2.99,
                    originalPrice = 3.89,
                    category = "Groceries",
                    rating = 4.5,
                    unit = "1 lb container",
                    imageLocalResName = "ic_strawberries",
                    rollback = true,
                    stock = 60,
                    calories = 45,
                    organic = false
                ),
                ProductEntity(
                    id = 5,
                    title = "Organic Baby Spinach",
                    description = "Triple-washed, tender organic baby spinach leaves ready to eat. A nutritious base for power salads or sautéed greens.",
                    price = 3.29,
                    originalPrice = 3.29,
                    category = "Groceries",
                    rating = 4.4,
                    unit = "5 oz tub",
                    imageLocalResName = "ic_spinach",
                    rollback = false,
                    stock = 45,
                    calories = 20,
                    organic = true
                ),
                ProductEntity(
                    id = 6,
                    title = "Fresh Baked French Baguette",
                    description = "Crafted in our in-store bakery. Authentic recipe with a golden-crisp crackly crust and warm, soft, airy interior crumb.",
                    price = 1.99,
                    originalPrice = 2.49,
                    category = "Bakery & Desserts",
                    rating = 4.8,
                    unit = "1 loaf (12 oz)",
                    imageLocalResName = "ic_baguette",
                    rollback = true,
                    stock = 30,
                    calories = 210,
                    organic = false
                ),
                ProductEntity(
                    id = 7,
                    title = "Chocolate Fudge Cake Slice",
                    description = "Decadent multi-layered chocolate cake filled and iced with premium cocoa-rich fudge frosting. Absolute bliss.",
                    price = 3.99,
                    originalPrice = 3.99,
                    category = "Bakery & Desserts",
                    rating = 4.9,
                    unit = "1 slice (6 oz)",
                    imageLocalResName = "ic_cake",
                    rollback = false,
                    stock = 15,
                    calories = 420,
                    organic = false
                ),
                ProductEntity(
                    id = 8,
                    title = "Glazed Yeast Donuts",
                    description = "Light, fluffy yeast-raised donut rings covered in a melt-in-your-mouth sweet sugary glaze. Perfect with morning coffee.",
                    price = 4.49,
                    originalPrice = 5.49,
                    category = "Bakery & Desserts",
                    rating = 4.3,
                    unit = "6-pack box",
                    imageLocalResName = "ic_donuts",
                    rollback = true,
                    stock = 25,
                    calories = 280,
                    organic = false
                ),
                ProductEntity(
                    id = 9,
                    title = "USDA Choice Ribeye Steak",
                    description = "Juicy USDA choice beef ribeye steak, thick cut and boasting exquisite marbling for exceptional buttery flavor and tenderness on the grill.",
                    price = 14.99,
                    originalPrice = 17.99,
                    category = "Meat & Seafood",
                    rating = 4.9,
                    unit = "1 lb steak",
                    imageLocalResName = "ic_ribeye",
                    rollback = true,
                    stock = 20,
                    calories = 310,
                    organic = false
                ),
                ProductEntity(
                    id = 10,
                    title = "Fresh Atlantic Salmon Fillet",
                    description = "Freshly caught rich Atlantic salmon skin-on fillet, loaded with healthy Omega-3 fatty acids. Ideal for baking, pan-searing, or grilling.",
                    price = 11.99,
                    originalPrice = 11.99,
                    category = "Meat & Seafood",
                    rating = 4.7,
                    unit = "1 lb",
                    imageLocalResName = "ic_salmon",
                    rollback = false,
                    stock = 30,
                    calories = 180,
                    organic = false
                ),
                ProductEntity(
                    id = 11,
                    title = "All-Natural Chicken Breasts",
                    description = "Boneless, skinless high-quality chicken breast fillets. Raised with no artificial ingredients and no antibiotics ever.",
                    price = 4.99,
                    originalPrice = 5.99,
                    category = "Meat & Seafood",
                    rating = 4.6,
                    unit = "1.5 lb tray",
                    imageLocalResName = "ic_chicken",
                    rollback = true,
                    stock = 50,
                    calories = 120,
                    organic = false
                ),
                ProductEntity(
                    id = 12,
                    title = "Whole Milk Grade A",
                    description = "Pasteurized, vitamin-D enriched whole cows milk produced by local dairies. Rich, full-bodied, and highly nutritious.",
                    price = 2.89,
                    originalPrice = 2.89,
                    category = "Dairy & Eggs",
                    rating = 4.7,
                    unit = "1 gallon",
                    imageLocalResName = "ic_milk",
                    rollback = false,
                    stock = 100,
                    calories = 150,
                    organic = false
                ),
                ProductEntity(
                    id = 13,
                    title = "Cage-Free Large Brown Eggs",
                    description = "Grade A large brown eggs sourced from hens fed a high-quality vegetarian diet under healthy, cage-free living standards.",
                    price = 3.99,
                    originalPrice = 4.89,
                    category = "Dairy & Eggs",
                    rating = 4.8,
                    unit = "12-count carton",
                    imageLocalResName = "ic_eggs",
                    rollback = true,
                    stock = 90,
                    calories = 70,
                    organic = false
                ),
                ProductEntity(
                    id = 14,
                    title = "Greek Yogurt - Honey Vanilla",
                    description = "Thick, rich, and creamy traditional strained Greek yogurt sweetened with wild mountain honey and aromatic natural vanilla bean extract.",
                    price = 4.29,
                    originalPrice = 4.29,
                    category = "Dairy & Eggs",
                    rating = 4.5,
                    unit = "32 oz tub",
                    imageLocalResName = "ic_yogurt",
                    rollback = false,
                    stock = 75,
                    calories = 120,
                    organic = false
                ),
                ProductEntity(
                    id = 15,
                    title = "Organic Cold Brew Coffee",
                    description = "Gently cold-steeped for 18 hours. Ultra-smooth unsweetened black coffee made from 100% organic Arabica beans.",
                    price = 4.99,
                    originalPrice = 5.99,
                    category = "Beverages",
                    rating = 4.8,
                    unit = "32 oz bottle",
                    imageLocalResName = "ic_coldbrew",
                    rollback = true,
                    stock = 40,
                    calories = 15,
                    organic = true
                ),
                ProductEntity(
                    id = 16,
                    title = "Sparkling Lime Water",
                    description = "Zero sugar, zero calorie sparkling spring water infused with the crisp, refreshing essence of natural Key limes.",
                    price = 3.79,
                    originalPrice = 3.79,
                    category = "Beverages",
                    rating = 4.4,
                    unit = "12-pack cans",
                    imageLocalResName = "ic_sparkling",
                    rollback = false,
                    stock = 110,
                    calories = 0,
                    organic = false
                ),
                ProductEntity(
                    id = 17,
                    title = "100% Squeezed Orange Juice",
                    description = "Premium non-GMO oranges, freshly squeezed with pulp. An excellent source of daily Vitamin C with no added sugar or water.",
                    price = 3.99,
                    originalPrice = 4.49,
                    category = "Beverages",
                    rating = 4.7,
                    unit = "52 oz bottle",
                    imageLocalResName = "ic_oj",
                    rollback = true,
                    stock = 60,
                    calories = 110,
                    organic = false
                ),
                ProductEntity(
                    id = 18,
                    title = "Roasted Salted Almonds",
                    description = "Crunchy California almonds, dry-roasted and lightly sprinkled with sea salt. Safe heart-healthy snack rich in fiber.",
                    price = 5.99,
                    originalPrice = 6.99,
                    category = "Pantry & Snacks",
                    rating = 4.6,
                    unit = "12 oz bag",
                    imageLocalResName = "ic_almonds",
                    rollback = true,
                    stock = 80,
                    calories = 160,
                    organic = false
                ),
                ProductEntity(
                    id = 19,
                    title = "Organic Tomato Basil Sauce",
                    description = "Slow-simmered organic Italian tomatoes, fresh garden sweet basil, extra virgin olive oil, and herbs for rich, homestyle pasta nights.",
                    price = 2.49,
                    originalPrice = 2.49,
                    category = "Pantry & Snacks",
                    rating = 4.5,
                    unit = "24 oz jar",
                    imageLocalResName = "ic_pasta_sauce",
                    rollback = false,
                    stock = 70,
                    calories = 80,
                    organic = true
                ),
                ProductEntity(
                    id = 20,
                    title = "Classic Penne Rigate Pasta",
                    description = "Authentic semolina durum wheat penne rigate pasta. Extruded through bronze dies for a rough texture that holds sauce perfectly.",
                    price = 1.29,
                    originalPrice = 1.79,
                    category = "Pantry & Snacks",
                    rating = 4.7,
                    unit = "16 oz box",
                    imageLocalResName = "ic_penne",
                    rollback = true,
                    stock = 100,
                    calories = 200,
                    organic = false
                ),
                ProductEntity(
                    id = 21,
                    title = "Ultra Soft Bath Tissue",
                    description = "Super cushiony, absorbent triple-layer sheet rolls designed to break up easily in septic systems.",
                    price = 8.99,
                    originalPrice = 9.99,
                    category = "Household Essentials",
                    rating = 4.6,
                    unit = "9 mega-rolls",
                    imageLocalResName = "ic_toiletpaper",
                    rollback = true,
                    stock = 50,
                    calories = 0,
                    organic = false
                ),
                ProductEntity(
                    id = 22,
                    title = "Lavender Liquid Dish Soap",
                    description = "Tough on grease, gentle on hands. Made from plant-based formulas scented with pure organic lavender essential oils.",
                    price = 2.99,
                    originalPrice = 2.99,
                    category = "Household Essentials",
                    rating = 4.5,
                    unit = "24 oz squeeze bottle",
                    imageLocalResName = "ic_dishsoap",
                    rollback = false,
                    stock = 40,
                    calories = 0,
                    organic = false
                )
            )
            productDao.insertProducts(seedProducts)
        }
        val bannerList = bannerDao.getAllBanners().first()
        if (bannerList.isEmpty()) {
            val seedBanners = listOf(
                BannerEntity(
                    section = "top",
                    title = "Fresh Organics Sale",
                    subtitle = "Grab 20% off USDA Organic Produce",
                    targetCategory = "Groceries",
                    backgroundColor = "#0284C7",
                    imageEmoji = "🍏"
                ),
                BannerEntity(
                    section = "top",
                    title = "Artisan Bakery Delight",
                    subtitle = "Freshly baked sourdough and croissants",
                    targetCategory = "Bakery & Desserts",
                    backgroundColor = "#D97706",
                    imageEmoji = "🥐"
                ),
                BannerEntity(
                    section = "top",
                    title = "Refreshing Drinks Hub",
                    subtitle = "Stay hydrated with 2-for-1 premium sodas",
                    targetCategory = "Beverages",
                    backgroundColor = "#059669",
                    imageEmoji = "🥤"
                ),
                BannerEntity(
                    section = "middle",
                    title = "Premium Meat Deals",
                    subtitle = "Grilling weekend! Prime steak & chicken cuts",
                    targetCategory = "Meat & Seafood",
                    backgroundColor = "#DC2626",
                    imageEmoji = "🥩"
                ),
                BannerEntity(
                    section = "middle",
                    title = "Dairy & Eggs Specials",
                    subtitle = "Farm-fresh milk & cheese up to 15% off",
                    targetCategory = "Dairy & Eggs",
                    backgroundColor = "#2563EB",
                    imageEmoji = "🧀"
                ),
                BannerEntity(
                    section = "bottom",
                    title = "Snack Time Rollbacks!",
                    subtitle = "Bite-size snacks, chips & trail mixes",
                    targetCategory = "Pantry & Snacks",
                    backgroundColor = "#7C3AED",
                    imageEmoji = "🥨"
                ),
                BannerEntity(
                    section = "bottom",
                    title = "Clean Green Essentials",
                    subtitle = "USDA organic household cleaning supplies",
                    targetCategory = "Household Essentials",
                    backgroundColor = "#4B5563",
                    imageEmoji = "🧼"
                )
            )
            bannerDao.insertBanners(seedBanners)
        }
    }
}
