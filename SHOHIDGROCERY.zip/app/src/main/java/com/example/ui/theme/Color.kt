package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FreshMartBlue = Color(0xFF0071CE) // True Walmart Brand Blue
val FreshMartAmber = Color(0xFFFFAA00) // Energetic Golden Sun Accent
val FreshMartLightBg = Color(0xFFF4F6F9) // Modern slate-tinted background

// Slate shades
val Slate50 = Color(0xFFF1F5F9)
val Slate100 = Color(0xFFE2E8F0)
val Slate200 = Color(0xFFCBD5E1)
val Slate700 = Color(0xFF334155)
val Slate800 = Color(0xFF1E293B)
val Slate900 = Color(0xFF0F172A)

// Highlight colors
val RollbackRed = Color(0xFFD32F2F) // Classic rollback discount red
val OrganicGreen = Color(0xFF2E7D32) // Healthy fresh organic green
