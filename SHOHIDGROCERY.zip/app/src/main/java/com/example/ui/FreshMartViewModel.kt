package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.api.GenerateContentRequest
import com.example.api.Content
import com.example.api.Part
import com.example.api.GenerationConfig
import com.example.api.RetrofitClient
import com.example.api.RecipeResponse
import com.example.data.*
import com.example.BuildConfig
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

sealed interface RecipeState {
    object Idle : RecipeState
    object Loading : RecipeState
    data class Success(val recipe: RecipeResponse) : RecipeState
    data class Error(val message: String) : RecipeState
}

sealed interface FirebaseTestState {
    object Idle : FirebaseTestState
    object Loading : FirebaseTestState
    data class Success(val message: String) : FirebaseTestState
    data class Error(val message: String) : FirebaseTestState
}

data class CartUiItem(
    val product: ProductEntity,
    val quantity: Int
)

data class CartTotals(
    val subtotal: Double = 0.0,
    val originalSubtotal: Double = 0.0,
    val savings: Double = 0.0,
    val tax: Double = 0.0,
    val grandTotal: Double = 0.0,
    val itemCount: Int = 0
)

class FreshMartViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = FreshMartRepository(
        productDao = database.productDao(),
        cartDao = database.cartDao(),
        orderDao = database.orderDao(),
        favoriteDao = database.favoriteDao(),
        bannerDao = database.bannerDao()
    )

    // Customer Sign Up States (Persisted in SharedPreferences)
    private val prefs = application.getSharedPreferences("freshmart_bd_customer_prefs", android.content.Context.MODE_PRIVATE)

    val customerName = MutableStateFlow(prefs.getString("customer_name", "") ?: "")
    val customerPhone = MutableStateFlow(prefs.getString("customer_phone", "") ?: "")
    val customerIsRegistered = MutableStateFlow(prefs.getBoolean("customer_is_registered", false))
    val customerEmail = MutableStateFlow(prefs.getString("customer_email", "") ?: "")
    val customerPhotoUrl = MutableStateFlow(prefs.getString("customer_photo_url", "") ?: "")
    val customerCreatedAt = MutableStateFlow(prefs.getLong("customer_created_at", 0L))

    private var ordersListener: com.google.firebase.firestore.ListenerRegistration? = null

    fun startOrdersListener() {
        if (!customerIsRegistered.value || customerPhone.value.isEmpty()) return
        if (ordersListener != null) return
        try {
            val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
            ordersListener = db.collection("orders")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        android.util.Log.e("FreshMartViewModel", "Orders snapshot listener error", error)
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        viewModelScope.launch {
                            for (doc in snapshot.documents) {
                                try {
                                    val id = doc.getString("id") ?: doc.id
                                    val timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis()
                                    val status = doc.getString("status") ?: "Processing"
                                    val total = doc.getDouble("total") ?: 0.0
                                    val savings = doc.getDouble("savings") ?: 0.0
                                    val deliveryType = doc.getString("deliveryType") ?: "Delivery"
                                    val itemsJson = doc.getString("itemsJson") ?: "[]"
                                    
                                    val order = OrderEntity(id, timestamp, status, total, savings, deliveryType, itemsJson)
                                    repository.insertOrderDirectly(order)
                                } catch (e: Exception) {
                                    android.util.Log.e("FreshMartViewModel", "Error parsing real-time order", e)
                                }
                            }
                        }
                    }
                }
        } catch (e: Exception) {
            android.util.Log.w("FreshMartViewModel", "Real-time orders listener failed to initialize: ${e.message}")
        }
    }

    fun stopOrdersListener() {
        ordersListener?.remove()
        ordersListener = null
    }

    fun registerCustomer(name: String, phone: String) {
        val now = System.currentTimeMillis()
        registerGoogleCustomer(
            uid = phone,
            name = name,
            email = "firebase.phone.user@gmail.com",
            photoUrl = "",
            createdAt = now
        )
    }

    fun registerGoogleCustomer(uid: String, name: String, email: String, photoUrl: String, createdAt: Long) {
        prefs.edit().apply {
            putString("customer_name", name)
            putString("customer_phone", uid)
            putString("customer_email", email)
            putString("customer_photo_url", photoUrl)
            putLong("customer_created_at", createdAt)
            putBoolean("customer_is_registered", true)
            apply()
        }
        customerName.value = name
        customerPhone.value = uid
        customerEmail.value = email
        customerPhotoUrl.value = photoUrl
        customerCreatedAt.value = createdAt
        customerIsRegistered.value = true
        
        // Persist registration to Firestore
        viewModelScope.launch {
            val user = com.example.data.User(
                id = uid,
                name = name,
                email = email,
                phone = "",
                address = "",
                registeredAt = createdAt,
                role = "customer",
                photoUrl = photoUrl,
                createdAt = createdAt
            )
            FirestoreManager.saveUser(user)
            FirestoreManager.saveCustomer(uid, name)
            try {
                val remoteCart = FirestoreManager.getCart(uid)
                if (remoteCart.isNotEmpty()) {
                    remoteCart.forEach { item ->
                        repository.addToCart(item.productId, item.quantity)
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("FreshMartViewModel", "Error syncing remote cart: ${e.message}", e)
            }
            startOrdersListener()
            queryFirestoreCollections()
        }
    }

    fun logoutCustomer() {
        prefs.edit().apply {
            remove("customer_name")
            remove("customer_phone")
            remove("customer_email")
            remove("customer_photo_url")
            remove("customer_created_at")
            putBoolean("customer_is_registered", false)
            apply()
        }
        customerName.value = ""
        customerPhone.value = ""
        customerEmail.value = ""
        customerPhotoUrl.value = ""
        customerCreatedAt.value = 0L
        customerIsRegistered.value = false
        stopOrdersListener()
        
        try {
            com.google.firebase.auth.FirebaseAuth.getInstance().signOut()
        } catch (e: Exception) {
            android.util.Log.e("FreshMartViewModel", "Firebase sign out error: ${e.message}")
        }
    }

    // Banners StateFlows
    val allBanners: StateFlow<List<BannerEntity>> = repository.allBanners
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val topBanners: StateFlow<List<BannerEntity>> = repository.getActiveBannersBySection("top")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val middleBanners: StateFlow<List<BannerEntity>> = repository.getActiveBannersBySection("middle")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bottomBanners: StateFlow<List<BannerEntity>> = repository.getActiveBannersBySection("bottom")
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI state parameters
    val searchQuery = MutableStateFlow("")
    val selectedCategory = MutableStateFlow("All")

    // Products Flow
    val products: StateFlow<List<ProductEntity>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Products (by Category & Search)
    val filteredProducts: StateFlow<List<ProductEntity>> = combine(
        products,
        searchQuery,
        selectedCategory
    ) { prodList, query, cat ->
        prodList.filter { prod ->
            val matchCat = (cat == "All") || (prod.category.equals(cat, ignoreCase = true))
            val matchQuery = query.isEmpty() || 
                    prod.title.contains(query, ignoreCase = true) || 
                    prod.description.contains(query, ignoreCase = true)
            matchCat && matchQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Rollback items (Deals)
    val rollbackProducts: StateFlow<List<ProductEntity>> = products
        .map { prodList -> prodList.filter { it.rollback } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart Items combined with Product information
    val cartUiItems: StateFlow<List<CartUiItem>> = combine(
        repository.cartItems,
        products
    ) { cartList, prodList ->
        cartList.mapNotNull { cartItem ->
            val p = prodList.find { it.id == cartItem.productId }
            p?.let { CartUiItem(product = it, quantity = cartItem.quantity) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart Totals State
    val cartTotals: StateFlow<CartTotals> = cartUiItems.map { items ->
        var subtotal = 0.0
        var originalSubtotal = 0.0
        var count = 0
        items.forEach { uiItem ->
            subtotal += uiItem.product.price * uiItem.quantity
            originalSubtotal += uiItem.product.originalPrice * uiItem.quantity
            count += uiItem.quantity
        }
        val savings = originalSubtotal - subtotal
        val tax = subtotal * 0.07 // 7% standard tax
        val grandTotal = subtotal + tax
        CartTotals(
            subtotal = subtotal,
            originalSubtotal = originalSubtotal,
            savings = savings,
            tax = tax,
            grandTotal = grandTotal,
            itemCount = count
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CartTotals())

    // Order history
    val orders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Favorite Products Set of IDs
    val favoriteIds: StateFlow<Set<Int>> = repository.favorites
        .map { favList -> favList.map { it.productId }.toSet() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptySet())

    // Coupon clipping simulation (clipped item ids)
    val clippedCouponIds = MutableStateFlow<Set<Int>>(emptySet())

    // Firestore Collections Flow lists for Admin dashboard integration
    val firestoreSuppliers = MutableStateFlow<List<Supplier>>(emptyList())
    val firestoreInventoryList = MutableStateFlow<List<Map<String, Any>>>(emptyList())
    val firestoreCustomersList = MutableStateFlow<List<Map<String, Any>>>(emptyList())

    // AI Chef/Recipe State
    val recipeState = MutableStateFlow<RecipeState>(RecipeState.Idle)
    val recipePrompt = MutableStateFlow("Suggest a quick organic healthy family dinner")

    // Scanned code simulator state
    val scannerOpen = MutableStateFlow(false)
    val scannedProduct = MutableStateFlow<ProductEntity?>(null)
    val scanningInProgress = MutableStateFlow(false)

    // User Profile Location mockup
    val storeZipCode = MutableStateFlow("10001 (New York)")
    val isDeliveryOption = MutableStateFlow(true) // true = Delivery, false = Pickup
    val isOnline = MutableStateFlow(true)

    // Firebase Firestore connection test state
    val firebaseTestState = MutableStateFlow<FirebaseTestState>(FirebaseTestState.Idle)

    fun runFirebaseConnectionTest() {
        viewModelScope.launch {
            firebaseTestState.value = FirebaseTestState.Loading
            try {
                val outcome = FirestoreManager.testFirestoreConnection()
                firebaseTestState.value = FirebaseTestState.Success(outcome)
            } catch (e: Exception) {
                firebaseTestState.value = FirebaseTestState.Error(e.message ?: "Unknown Firestore Error")
            }
        }
    }

    fun queryFirestoreCollections() {
        viewModelScope.launch {
            try {
                firestoreSuppliers.value = FirestoreManager.getSuppliers()
                firestoreInventoryList.value = FirestoreManager.getInventoryList()
                firestoreCustomersList.value = FirestoreManager.getCustomers()
            } catch (e: Exception) {
                android.util.Log.e("FreshMartViewModel", "Error querying supplementary collections: ${e.message}", e)
            }
        }
    }

    fun syncWithFirestore() {
        viewModelScope.launch {
            try {
                // Ensure Room is pre-seeded first
                repository.seedIfNeeded()

                // 1. Retrieve products dynamically from Firestore
                val remoteProducts = FirestoreManager.getProducts()
                if (remoteProducts.isNotEmpty()) {
                    repository.insertProducts(remoteProducts)
                    android.util.Log.d("FreshMartViewModel", "Products dynamically loaded from Firestore: ${remoteProducts.size} items")
                } else {
                    // Populate Firestore with initial seed products from Room
                    android.util.Log.d("FreshMartViewModel", "Firestore empty. Uploading local product database as seed...")
                    val localProducts = products.value
                    if (localProducts.isNotEmpty()) {
                        localProducts.forEach { prod ->
                            FirestoreManager.saveProduct(prod)
                        }
                    } else {
                        // Wait a tiny moment for flow to emit, or retrieve direct
                        val directProducts = repository.allProducts.first()
                        directProducts.forEach { prod ->
                            FirestoreManager.saveProduct(prod)
                        }
                    }
                }

                // 2. Synchronize order reports
                val remoteOrders = FirestoreManager.getOrders()
                if (remoteOrders.isNotEmpty()) {
                    remoteOrders.forEach { order ->
                        repository.insertOrderDirectly(order)
                    }
                }

                // 3. Register standard active members in Firestore
                if (customerIsRegistered.value) {
                    FirestoreManager.saveCustomer(customerPhone.value, customerName.value)
                    
                    // Recover/Sync cart from Firestore if local Room cart is empty or freshly initialized
                    val localCart = repository.cartItems.first()
                    if (localCart.isEmpty()) {
                        val remoteCart = FirestoreManager.getCart(customerPhone.value)
                        if (remoteCart.isNotEmpty()) {
                            remoteCart.forEach { item ->
                                repository.addToCart(item.productId, item.quantity)
                            }
                            android.util.Log.d("FreshMartViewModel", "Cart synchronized and restored from Firestore for: ${customerPhone.value}")
                        }
                    }
                }

                // Fetch supplementary lists
                queryFirestoreCollections()

            } catch (e: Exception) {
                android.util.Log.e("FreshMartViewModel", "Firestore sync exception: ${e.message}", e)
            }
        }
    }

    init {
        // Run seeding and remote sync
        viewModelScope.launch {
            repository.seedIfNeeded()
            syncWithFirestore()
            startOrdersListener()
        }

        // Auto-save cart items stream to Firestore in real-time when registered
        viewModelScope.launch {
            repository.cartItems.collect { items ->
                val phone = customerPhone.value
                if (customerIsRegistered.value && phone.isNotEmpty()) {
                    FirestoreManager.saveCart(phone, items)
                }
            }
        }

        // Monitor standard network connectivity to connect the app to standard internet feedback
        val connectivityManager = application.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as? android.net.ConnectivityManager
        if (connectivityManager != null) {
            try {
                val activeNetwork = connectivityManager.activeNetwork
                val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
                isOnline.value = capabilities != null && capabilities.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)

                val request = android.net.NetworkRequest.Builder()
                    .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build()

                connectivityManager.registerNetworkCallback(request, object : android.net.ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: android.net.Network) {
                        isOnline.value = true
                    }

                    override fun onLost(network: android.net.Network) {
                        val hasInternet = connectivityManager.activeNetwork?.let { activeNet ->
                            connectivityManager.getNetworkCapabilities(activeNet)?.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
                        } ?: false
                        isOnline.value = hasInternet
                    }
                })
            } catch (e: Exception) {
                // Default to online if registration fails
                isOnline.value = true
            }
        }
    }

    // Cart modification actions
    fun addToCart(productId: Int, quantity: Int = 1) {
        viewModelScope.launch {
            repository.addToCart(productId, quantity)
        }
    }

    fun updateCartQuantity(productId: Int, quantity: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(productId, quantity)
        }
    }

    fun removeFromCart(productId: Int) {
        viewModelScope.launch {
            repository.removeFromCart(productId)
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    fun toggleFavorite(productId: Int) {
        viewModelScope.launch {
            repository.toggleFavorite(productId)
        }
    }

    fun toggleCouponClip(productId: Int) {
        val current = clippedCouponIds.value
        if (current.contains(productId)) {
            clippedCouponIds.value = current - productId
        } else {
            clippedCouponIds.value = current + productId
        }
    }

    // Checkout Order Flow
    fun submitCheckoutOrder(completionCallback: (String) -> Unit) {
        viewModelScope.launch {
            val currentItems = cartUiItems.value
            if (currentItems.isEmpty()) return@launch

            val totals = cartTotals.value
            val orderId = "SG-" + UUID.randomUUID().toString().take(8).uppercase()
            
            // Build simple JSON array representing items
            val serializedParts = currentItems.map { 
                """{"id":${it.product.id},"title":"${it.product.title}","price":${it.product.price},"quantity":${it.quantity}}"""
            }
            val itemsJson = "[" + serializedParts.joinToString(",") + "]"

            // Format deliveryType with customer details if registered
            val typeBase = if (isDeliveryOption.value) "Delivery" else "Store Pickup"
            val deliveryLabel = if (customerIsRegistered.value) {
                "$typeBase (${customerName.value} • ${customerPhone.value})"
            } else {
                "$typeBase (Guest Customer)"
            }

            val order = OrderEntity(
                id = orderId,
                timestamp = System.currentTimeMillis(),
                status = if (typeBase == "Delivery") "Processing" else "Ready for Pickup",
                total = totals.grandTotal,
                savings = totals.savings,
                deliveryType = deliveryLabel,
                itemsJson = itemsJson
            )

            // Save order locally and remotely, linked with logged-in user
            val currentUserId = if (customerIsRegistered.value) customerPhone.value else null
            repository.insertOrderDirectly(order)
            repository.clearCart()
            FirestoreManager.saveOrder(order, currentUserId)

            // Auto-update inventory: deduct stock and update collections automatically after every sale
            currentItems.forEach { item ->
                val nextStock = maxOf(0, item.product.stock - item.quantity)
                val updatedProduct = item.product.copy(stock = nextStock)
                repository.saveProduct(updatedProduct)
                FirestoreManager.saveProduct(updatedProduct)
            }

            // Refresh supplementary collections
            queryFirestoreCollections()

            completionCallback(orderId)
        }
    }

    // Scanning Simulator Actions
    fun openScanner() {
        scannerOpen.value = true
        scannedProduct.value = null
        scanningInProgress.value = false
    }

    fun closeScanner() {
        scannerOpen.value = false
        scannedProduct.value = null
    }

    fun triggerMockScan() {
        viewModelScope.launch {
            scanningInProgress.value = true
            kotlinx.coroutines.delay(1200) // Simulating scan visual delays
            val allProd = products.value
            if (allProd.isNotEmpty()) {
                scannedProduct.value = allProd.random()
            }
            scanningInProgress.value = false
        }
    }

    // Smart chef Recipe generator with Gemini API
    fun generateRecipe() {
        val promptText = recipePrompt.value
        if (promptText.isBlank()) return

        recipeState.value = RecipeState.Loading

        viewModelScope.launch {
            try {
                val catalogDescription = """
You are "Shohid Grocery Smart Chef", an intelligent supermarket assistant. Your job is to help users with recipes, cooking advice, and meal planning. 
When asked for a recipe, meal idea, or grocery list, you MUST respond ONLY with a clean JSON object following this exact JSON schema:
{
  "recipeName": "String",
  "description": "String explaining the recipe briefly",
  "prepTime": "String (e.g. 10 mins)",
  "cookTime": "String (e.g. 25 mins)",
  "servings": 4,
  "ingredients": ["String list of ingredient details with quantities"],
  "instructions": ["Step-by-step numbered cooking instructions"],
  "matchingProductIds": [Int, Int, ...]
}

CRITICAL: Return ONLY and EXCLUSIVELY the raw JSON. Do NOT wrap it in ```json ... ``` markdown block. Just return raw JSON text.

To make the shopping experience seamless, you MUST match ingredients of the recipe with our exact available store catalog!
Here is the complete list of available product IDs and titles in our store:
- ID 1: Organic Bananas (Groceries / Fruits)
- ID 2: Honeycrisp Apples (Groceries / Fruits)
- ID 3: Organic Hass Avocados (Groceries / Fruits)
- ID 4: Fresh Strawberries (Groceries / Fruits)
- ID 5: Organic Baby Spinach (Groceries / Greens)
- ID 6: Fresh Baked French Baguette (Bakery)
- ID 7: Chocolate Fudge Cake Slice (Bakery / Sweets)
- ID 8: Glazed Yeast Donuts (Bakery / Sweets)
- ID 9: USDA Choice Ribeye Steak (Meat & Seafood)
- ID 10: Fresh Atlantic Salmon Fillet (Meat & Seafood)
- ID 11: All-Natural Chicken Breasts (Meat & Seafood)
- ID 12: Whole Milk Grade A (Dairy / Eggs)
- ID 13: Cage-Free Large Brown Eggs (Dairy / Eggs)
- ID 14: Greek Yogurt - Honey Vanilla (Dairy / Eggs)
- ID 15: Organic Cold Brew Coffee (Beverages)
- ID 16: Sparkling Lime Water (Beverages)
- ID 17: 100% Squeezed Orange Juice (Beverages)
- ID 18: Roasted Salted Almonds (Pantry & Snacks)
- ID 19: Organic Tomato Basil Sauce (Pantry & Snacks)
- ID 20: Classic Penne Rigate Pasta (Pantry & Snacks)
- ID 21: Ultra Soft Bath Tissue (Household)
- ID 22: Lavender Liquid Dish Soap (Household)

In the "matchingProductIds" list, include the product IDs from the catalog above that are relevant ingredients or accompaniments for the recipe. For example, if you suggest pasta, include ID 20 and ID 19. If you suggest a baked salmon dinner, include ID 10. If you suggest a chicken dish, include ID 11. Only match with the exact catalog list above.
"""

                val systemContent = Content(parts = listOf(Part(text = catalogDescription)))
                val request = GenerateContentRequest(
                    contents = listOf(Content(parts = listOf(Part(text = "User prompt: $promptText")))),
                    generationConfig = GenerationConfig(
                        temperature = 0.7f,
                        responseMimeType = "application/json"
                    ),
                    systemInstruction = systemContent
                )

                val apiKey = BuildConfig.GEMINI_API_KEY
                
                if (apiKey == "MY_GEMINI_API_KEY" || apiKey.isBlank()) {
                    recipeState.value = RecipeState.Error("API Key is missing. Please configuration via early Studio Secrets Panel.")
                    return@launch
                }

                val response = RetrofitClient.geminiService.generateContent(apiKey, request)
                val rawText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                
                if (rawText != null) {
                    val cleanText = cleanJsonString(rawText)
                    val moshiFormatter = com.squareup.moshi.Moshi.Builder()
                        .addLast(com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory())
                        .build()
                    val adapter = moshiFormatter.adapter(RecipeResponse::class.java)
                    val parsedRecipe = adapter.fromJson(cleanText)
                    
                    if (parsedRecipe != null) {
                        recipeState.value = RecipeState.Success(parsedRecipe)
                    } else {
                        recipeState.value = RecipeState.Error("Failed to parse recipe details. Raw text: $rawText")
                    }
                } else {
                    recipeState.value = RecipeState.Error("Empty recipe response returned.")
                }
            } catch (e: Exception) {
                recipeState.value = RecipeState.Error("Error connecting to Gemini API: ${e.localizedMessage}")
            }
        }
    }

    private fun cleanJsonString(raw: String): String {
        var text = raw.trim()
        if (text.startsWith("```json")) {
            text = text.substringAfter("```json")
        } else if (text.startsWith("```")) {
            text = text.substringAfter("```")
        }
        if (text.endsWith("```")) {
            text = text.substringBeforeLast("```")
        }
        return text.trim()
    }

    fun addAllRecipeIngredientsToCart(ingredientIds: List<Int>) {
        recipePrompt.value = "" // clear input
        viewModelScope.launch {
            ingredientIds.forEach { id ->
                repository.addToCart(id, 1)
            }
        }
    }

    // --- Admin Dashboard Binding Methods ---
    fun saveProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.saveProduct(product)
            FirestoreManager.saveProduct(product)
            queryFirestoreCollections()
        }
    }

    fun deleteProduct(productId: Int) {
        viewModelScope.launch {
            repository.deleteProduct(productId)
            FirestoreManager.deleteProduct(productId)
            queryFirestoreCollections()
        }
    }

    fun updateOrderStatus(id: String, status: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(id, status)
            FirestoreManager.updateOrderStatus(id, status)
            queryFirestoreCollections()
        }
    }

    fun deleteOrder(id: String) {
        viewModelScope.launch {
            repository.deleteOrder(id)
            FirestoreManager.deleteOrder(id)
            queryFirestoreCollections()
        }
    }

    fun replenishAllInventoryStock(amount: Int = 100) {
        viewModelScope.launch {
            val currentProds = products.value
            currentProds.forEach { prod ->
                val updated = prod.copy(stock = amount)
                repository.saveProduct(updated)
                FirestoreManager.saveProduct(updated)
            }
            queryFirestoreCollections()
        }
    }

    fun simulateRandomClientOrder() {
        viewModelScope.launch {
            val allProd = products.value
            if (allProd.isEmpty()) return@launch

            // Choose 1 to 3 random items
            val samples = allProd.shuffled().take((1..3).random())
            val orderId = "SIM-" + UUID.randomUUID().toString().take(8).uppercase()
            val total = samples.sumOf { it.price }
            val savings = samples.sumOf { it.originalPrice - it.price }
            val isDelivery = (0..1).random() == 1
            val itemsJson = "[" + samples.map { 
                """{"id":${it.id},"title":"${it.title}","price":${it.price},"quantity":1}"""
            }.joinToString(",") + "]"

            val order = OrderEntity(
                id = orderId,
                timestamp = System.currentTimeMillis(),
                status = if (isDelivery) "Processing" else "Ready for Pickup",
                total = total + (total * 0.07),
                savings = savings,
                deliveryType = if (isDelivery) "Delivery" else "Store Pickup",
                itemsJson = itemsJson
            )

            repository.insertOrderDirectly(order)
            FirestoreManager.saveOrder(order)

            // Reduce stock for those items and auto-update inventory on both databases after simulations
            samples.forEach { prod ->
                val nextStock = maxOf(0, prod.stock - 1)
                val updated = prod.copy(stock = nextStock)
                repository.saveProduct(updated)
                FirestoreManager.saveProduct(updated)
            }

            queryFirestoreCollections()
        }
    }

    // --- Banner Management API for Control Center ---
    fun saveBanner(banner: BannerEntity) {
        viewModelScope.launch {
            repository.saveBanner(banner)
        }
    }

    fun deleteBanner(id: Int) {
        viewModelScope.launch {
            repository.deleteBanner(id)
        }
    }

    fun placePOSOrder(
        orderId: String,
        total: Double,
        savings: Double,
        itemsJson: String,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val order = OrderEntity(
                id = orderId,
                timestamp = System.currentTimeMillis(),
                status = "Completed",
                total = total,
                savings = savings,
                deliveryType = "POS Register Walk-in",
                itemsJson = itemsJson
            )
            repository.insertOrderDirectly(order)
            FirestoreManager.saveOrder(order)
            
            queryFirestoreCollections()
            onSuccess()
        }
    }

    // --- Suppliers CRUD bindings for Admin Panel ---
    fun saveSupplier(supplier: Supplier) {
        viewModelScope.launch {
            FirestoreManager.saveSupplier(supplier)
            queryFirestoreCollections()
        }
    }

    fun deleteSupplier(supplierId: String) {
        viewModelScope.launch {
            FirestoreManager.deleteSupplier(supplierId)
            queryFirestoreCollections()
        }
    }

    fun deleteCustomer(phone: String) {
        viewModelScope.launch {
            FirestoreManager.deleteCustomer(phone)
            queryFirestoreCollections()
        }
    }
}
