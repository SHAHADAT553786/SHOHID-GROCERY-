package com.example.ui

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.*
import com.example.getEmojiForProduct
import com.example.getCategoryGradient
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.lazy.LazyRow
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(viewModel: FreshMartViewModel, onBack: () -> Unit) {
    var isUnlocked by remember { mutableStateOf(false) }
    var pinInput by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    if (!isUnlocked) {
        AdminPasscodeGate(
            pinInput = pinInput,
            pinError = pinError,
            onDigitClick = { digit ->
                if (pinInput.length < 6) {
                    pinError = false
                    pinInput += digit
                }
                if (pinInput.length == 6) {
                    if (pinInput == "545254") {
                        isUnlocked = true
                        pinError = false
                    } else {
                        pinError = true
                        pinInput = ""
                    }
                }
            },
            onDeleteClick = {
                if (pinInput.isNotEmpty()) {
                    pinError = false
                    pinInput = pinInput.dropLast(1)
                }
            },
            onBackClick = onBack
        )
        return
    }

    val scrollState = rememberScrollState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val products by viewModel.products.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val banners by viewModel.allBanners.collectAsState()

    val firestoreSuppliers by viewModel.firestoreSuppliers.collectAsState()
    val firestoreCustomersList by viewModel.firestoreCustomersList.collectAsState()

    LaunchedEffect(Unit) {
        viewModel.queryFirestoreCollections()
    }

    var activeTab by remember { mutableStateOf("metrics") } // metrics, inventory, orders

    // Form/dialog states
    var showAddDialog by remember { mutableStateOf(false) }
    var editProductTarget by remember { mutableStateOf<ProductEntity?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FreshMartLightBg)
    ) {
        // Top Banner for Store Manager Mode
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Slate900, Slate800)
                    )
                )
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.15f), CircleShape)
                    ) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                    Column {
                        Text(
                            text = "Shohid Grocery Control Center",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                            color = Color.White
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF4ADE80))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Store Management Mode Active",
                                style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                color = Color(0xFF4ADE80)
                            )
                        }
                    }
                }

                // Rapid Replenish action
                TextButton(
                    onClick = {
                        viewModel.replenishAllInventoryStock(100)
                        Toast.makeText(context, "All product stocks replenished to 100 units!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = FreshMartAmber)
                ) {
                    Icon(imageVector = Icons.Default.Autorenew, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Restock All", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                }
            }
        }

        // Horizontal management Tab Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .border(BorderStroke(1.dp, Slate100))
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(
                Triple("metrics", "Metrics", Icons.Default.Leaderboard),
                Triple("inventory", "Products & Stock", Icons.Default.Inventory2),
                Triple("orders", "Orders Logs", Icons.Default.FactCheck),
                Triple("customers", "Customers Db", Icons.Default.People),
                Triple("suppliers", "Suppliers", Icons.Default.LocalShipping),
                Triple("banners", "Banners", Icons.Default.Slideshow),
                Triple("pos", "POS Checkout", Icons.Default.Receipt)
            ).forEach { (tabId, label, icon) ->
                val isSelected = activeTab == tabId
                Button(
                    onClick = { activeTab = tabId },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Slate900 else Color.Transparent,
                        contentColor = if (isSelected) Color.White else Slate700
                    ),
                    shape = RoundedCornerShape(12.dp),
                    elevation = null,
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                    modifier = Modifier
                        .height(40.dp)
                        .testTag("admin_tab_$tabId")
                ) {
                    Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = label,
                        style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }

        // Active View Render
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            when (activeTab) {
                "metrics" -> MetricsDashboardView(
                    viewModel = viewModel,
                    products = products,
                    orders = orders
                )
                "inventory" -> InventoryManagerView(
                    products = products,
                    onEditClick = { editProductTarget = it },
                    onAddClick = { showAddDialog = true },
                    onDeleteClick = { item ->
                        viewModel.deleteProduct(item.id)
                        Toast.makeText(context, "${item.title} deleted!", Toast.LENGTH_SHORT).show()
                    }
                )
                "orders" -> OrdersFulfillmentView(
                    orders = orders,
                    onUpdateStatus = { id, status ->
                        viewModel.updateOrderStatus(id, status)
                        Toast.makeText(context, "Order $id status updated to $status", Toast.LENGTH_SHORT).show()
                    },
                    onDeleteOrder = { id ->
                        viewModel.deleteOrder(id)
                        Toast.makeText(context, "Order log deleted!", Toast.LENGTH_SHORT).show()
                    }
                )
                "customers" -> CustomersListView(
                    customers = firestoreCustomersList,
                    onDeleteCustomer = { phone ->
                        viewModel.deleteCustomer(phone)
                        Toast.makeText(context, "Member deleted from Firestore!", Toast.LENGTH_SHORT).show()
                    }
                )
                "suppliers" -> SuppliersManagerView(
                    suppliers = firestoreSuppliers,
                    onSaveSupplier = { supplierItem ->
                        viewModel.saveSupplier(supplierItem)
                        Toast.makeText(context, "Supplier routing saved!", Toast.LENGTH_SHORT).show()
                    },
                    onDeleteSupplier = { uuid ->
                        viewModel.deleteSupplier(uuid)
                        Toast.makeText(context, "Supplier severed from Firestore!", Toast.LENGTH_SHORT).show()
                    }
                )
                "banners" -> BannersManagerView(
                    banners = banners,
                    onSaveBanner = { viewModel.saveBanner(it) },
                    onDeleteBanner = { id ->
                        viewModel.deleteBanner(id)
                        Toast.makeText(context, "Banner deleted!", Toast.LENGTH_SHORT).show()
                    }
                )
                "pos" -> PosTerminalView(
                    viewModel = viewModel,
                    products = products
                )
            }
        }
    }

    // Modal Add new product Dialog
    if (showAddDialog) {
        AddProductDialog(
            nextId = (products.maxOfOrNull { it.id } ?: 0) + 1,
            onDismiss = { showAddDialog = false },
            onSave = { newProduct ->
                viewModel.saveProduct(newProduct)
                showAddDialog = false
                Toast.makeText(context, "${newProduct.title} created successfully!", Toast.LENGTH_LONG).show()
            }
        )
    }

    // Modal Edit Product Dialog
    if (editProductTarget != null) {
        EditProductDialog(
            product = editProductTarget!!,
            onDismiss = { editProductTarget = null },
            onSave = { updatedProduct ->
                viewModel.saveProduct(updatedProduct)
                editProductTarget = null
                Toast.makeText(context, "${updatedProduct.title} modifications applied!", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun MetricsDashboardView(
    viewModel: FreshMartViewModel,
    products: List<ProductEntity>,
    orders: List<OrderEntity>
) {
    val scrollState = rememberScrollState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val totalGrossRevenue = orders.sumOf { it.total }
    val totalSavingsPoint = orders.sumOf { it.savings }
    val pendingCount = orders.count { it.status == "Processing" }
    val readyCount = orders.count { it.status == "Ready for Pickup" }
    val completedCount = orders.count { it.status == "Delivered" || it.status == "Completed" }

    val lowStockItems = products.filter { it.stock < 25 }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Simulated Client Simulator quick banner action
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = FreshMartBlue),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(Color.White.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = FreshMartAmber)
                    }
                    Text(
                        "Live Supermarket Client Simulator",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                Text(
                    "Click to let a simulated shopper choose random items, build a cart, apply active coupons, and buy. You will see stock quantities deplete and sales count go up in real-time!",
                    color = Color.White.copy(alpha = 0.9f),
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp
                )
                Button(
                    onClick = {
                        viewModel.simulateRandomClientOrder()
                        Toast.makeText(context, "Shopper placed a dynamic in-store order!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FreshMartAmber, contentColor = FreshMartBlue),
                    modifier = Modifier.fillMaxWidth().height(36.dp).testTag("simulate_shoppers_btn"),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(imageVector = Icons.Default.Groups, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Trigger Simulated Fast Purchase", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                }
            }
        }

        // Dynamic metrics cards grid layout
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Gross Revenue
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Slate100),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Gross Sales", style = TextStyle(fontSize = 12.sp, color = Color.Gray))
                        Icon(imageVector = Icons.Default.Payments, contentDescription = null, tint = OrganicGreen, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$${String.format("%.2f", totalGrossRevenue)}",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                        color = Slate900
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Total from ${orders.size} simulated orders",
                        style = TextStyle(fontSize = 10.sp, color = Color.Gray)
                    )
                }
            }

            // Coupon Savings Point Generated
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Slate100),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Digital Savings", style = TextStyle(fontSize = 12.sp, color = Color.Gray))
                        Icon(imageVector = Icons.Default.LocalActivity, contentDescription = null, tint = RollbackRed, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$${String.format("%.2f", totalSavingsPoint)}",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                        color = RollbackRed
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Coupons and rollbacks saved",
                        style = TextStyle(fontSize = 10.sp, color = Color.Gray)
                    )
                }
            }
        }

        // Shipment workflow status row metrics
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, Slate100),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    "Order Shipment Workflow Status",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = Slate800
                )
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(FreshMartBlue.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.HourglassEmpty, contentDescription = null, tint = FreshMartBlue, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Processing", fontSize = 11.sp, color = Color.Gray)
                        Text(pendingCount.toString(), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Slate900)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(FreshMartAmber.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, tint = FreshMartBlue, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Ready/In Transit", fontSize = 11.sp, color = Color.Gray)
                        Text(readyCount.toString(), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Slate900)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(OrganicGreen.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = OrganicGreen, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Completed", fontSize = 11.sp, color = Color.Gray)
                        Text(completedCount.toString(), fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Slate900)
                    }
                }
            }
        }

        // Low stock alerts list
        Text(
            "Low Stock Alerts (< 25 units)",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
            color = Slate800
        )

        if (lowStockItems.isEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Slate100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(OrganicGreen.copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = OrganicGreen, modifier = Modifier.size(18.dp))
                    }
                    Column {
                        Text("All stock levels healthy!", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text("No items are below target safety levels.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                lowStockItems.forEach { product ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, Slate100),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(getEmojiForProduct(product.id), fontSize = 28.sp)
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(product.title, fontWeight = FontWeight.Bold)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Stock remaining: ", color = Color.Gray, fontSize = 11.sp)
                                        Text(
                                            product.stock.toString(), 
                                            fontWeight = FontWeight.Bold, 
                                            fontSize = 11.sp, 
                                            color = if (product.stock < 10) RollbackRed else FreshMartAmber
                                        )
                                    }
                                }
                            }

                            // Quick Restock button
                            Button(
                                onClick = { 
                                    viewModel.saveProduct(product.copy(stock = 100))
                                    Toast.makeText(context, "Replenished ${product.title} to 100!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Slate100, contentColor = Slate800),
                                contentPadding = PaddingValues(horizontal = 12.dp),
                                modifier = Modifier.height(28.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("Restock (100)", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
fun InventoryManagerView(
    products: List<ProductEntity>,
    onEditClick: (ProductEntity) -> Unit,
    onAddClick: () -> Unit,
    onDeleteClick: (ProductEntity) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filtered = products.filter {
        searchQuery.isEmpty() ||
        it.title.contains(searchQuery, ignoreCase = true) ||
        it.category.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search & Add product row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Filter items...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(18.dp)) },
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Slate800,
                    unfocusedBorderColor = Slate100,
                    focusedContainerColor = Slate100,
                    unfocusedContainerColor = Slate100
                ),
                singleLine = true
            )

            Button(
                onClick = onAddClick,
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier.height(44.dp).testTag("add_product_admin_btn"),
                contentPadding = PaddingValues(horizontal = 14.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
            }
        }

        // Product rows list
        if (filtered.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No inventory items match search criteria.", color = Color.Gray, fontWeight = FontWeight.Bold)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered) { product ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Slate100),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Text(getEmojiForProduct(product.id), fontSize = 32.sp)
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(product.title, fontWeight = FontWeight.Bold, color = Slate900)
                                        if (product.organic) {
                                            Box(
                                                modifier = Modifier
                                                    .background(OrganicGreen.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                            ) {
                                                Text("Org", style = TextStyle(fontSize = 8.sp, color = OrganicGreen, fontWeight = FontWeight.Bold))
                                            }
                                        }
                                        if (product.rollback) {
                                            Box(
                                                modifier = Modifier
                                                    .background(RollbackRed.copy(alpha = 0.12f), RoundedCornerShape(4.dp))
                                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                                            ) {
                                                Text("Deal", style = TextStyle(fontSize = 8.sp, color = RollbackRed, fontWeight = FontWeight.Bold))
                                            }
                                        }
                                    }
                                    Text(product.category, color = Color.Gray, fontSize = 11.sp)
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text("$${product.price}", color = FreshMartBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("•", color = Color.Gray)
                                        Text("${product.stock} left in stock", color = if (product.stock < 20) RollbackRed else Color.Gray, fontSize = 11.sp, fontWeight = if (product.stock < 20) FontWeight.Bold else FontWeight.Normal)
                                    }
                                }
                            }

                            // Modify/Remove actions
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(onClick = { onEditClick(product) }) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Item", tint = FreshMartBlue)
                                }
                                IconButton(onClick = { onDeleteClick(product) }) {
                                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete Item", tint = RollbackRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OrdersFulfillmentView(
    orders: List<OrderEntity>,
    onUpdateStatus: (String, String) -> Unit,
    onDeleteOrder: (String) -> Unit
) {
    if (orders.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("📦", fontSize = 48.sp)
                Text("No placed checkouts found.", fontWeight = FontWeight.Bold, color = Slate700)
                Text("Simulate order checkouts or use simulator triggers", color = Color.Gray)
            }
        }
    } else {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(orders) { order ->
                val dateStr = SimpleDateFormat("HH:mm a", Locale.getDefault()).format(Date(order.timestamp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Slate100),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("ID: ${order.id}", fontWeight = FontWeight.Bold, color = Slate900)
                                Text("Checked out: $dateStr • ${order.deliveryType}", color = Color.Gray, fontSize = 11.sp)
                            }

                            // Status Badge
                            val statusBg = when(order.status) {
                                "Processing" -> FreshMartBlue.copy(alpha = 0.1f)
                                "Ready for Pickup", "In Transit" -> FreshMartAmber.copy(alpha = 0.15f)
                                else -> OrganicGreen.copy(alpha = 0.1f)
                            }
                            val statusText = when(order.status) {
                                "Processing" -> FreshMartBlue
                                "Ready for Pickup", "In Transit" -> FreshMartBlue
                                else -> OrganicGreen
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(statusBg)
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    order.status,
                                    style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = statusText)
                                )
                            }
                        }

                        // Order totals summary
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Simulated Bill: $${String.format("%.2f", order.total)}", style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 13.sp))
                            if (order.savings > 0) {
                                Text("Saved: $${String.format("%.2f", order.savings)}", color = OrganicGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }

                        // Order items expanded list
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Slate50, RoundedCornerShape(6.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                "Composition items json: ${order.itemsJson}",
                                fontSize = 10.sp,
                                color = Color.Gray,
                                maxLines = 3,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        Divider(color = Slate100)

                        // Manager Fulfillment controls row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { onDeleteOrder(order.id) }) {
                                Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Scrap logs", tint = Color.LightGray)
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (order.status == "Processing") {
                                    val nextState = if (order.deliveryType == "Delivery") "In Transit" else "Ready for Pickup"
                                    Button(
                                        onClick = { onUpdateStatus(order.id, nextState) },
                                        colors = ButtonDefaults.buttonColors(containerColor = FreshMartAmber, contentColor = FreshMartBlue),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                        modifier = Modifier.height(32.dp),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(nextState, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else if (order.status == "Ready for Pickup" || order.status == "In Transit") {
                                    Button(
                                        onClick = { onUpdateStatus(order.id, "Delivered") },
                                        colors = ButtonDefaults.buttonColors(containerColor = OrganicGreen, contentColor = Color.White),
                                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                                        modifier = Modifier.height(32.dp),
                                        shape = RoundedCornerShape(16.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Complete", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                } else {
                                    Text("Order Archived", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold, modifier = Modifier.padding(end = 10.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddProductDialog(
    nextId: Int,
    onDismiss: () -> Unit,
    onSave: (ProductEntity) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Groceries") }
    var priceStr by remember { mutableStateOf("") }
    var origPriceStr by remember { mutableStateOf("") }
    var stockStr by remember { mutableStateOf("") }
    var isRollback by remember { mutableStateOf(false) }
    var isOrganic by remember { mutableStateOf(false) }
    var unitSize by remember { mutableStateOf("1 lb") }

    val categories = listOf("Groceries", "Bakery & Desserts", "Meat & Seafood", "Dairy & Eggs", "Beverages", "Pantry & Snacks", "Household Essentials")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Custom Supermarket Product", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Product Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_title_field")
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                // Category selector
                Column {
                    Text("Supermarket Department:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Slate700)
                    Box(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                            categories.forEach { cat ->
                                FilterChip(
                                    selected = category == cat,
                                    onClick = { category = cat },
                                    label = { Text(cat, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text("Price ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f).testTag("add_price_field"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = origPriceStr,
                        onValueChange = { origPriceStr = it },
                        label = { Text("Original Price ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = stockStr,
                        onValueChange = { stockStr = it },
                        label = { Text("Stock Stock") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1.3f).testTag("add_stock_field"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unitSize,
                        onValueChange = { unitSize = it },
                        label = { Text("Unit Size") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Boolean flags togglers
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isRollback, onCheckedChange = { isRollback = it }, modifier = Modifier.testTag("add_rollback_chk"))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Trigger Active Rollback (Weekly Deal)")
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isOrganic, onCheckedChange = { isOrganic = it })
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("USDA Certified Organic Healthy")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalPrice = priceStr.toDoubleOrNull() ?: 0.0
                    val finalOriginalPrice = if (origPriceStr.isNotEmpty()) origPriceStr.toDoubleOrNull() ?: finalPrice else finalPrice
                    val finalStock = stockStr.toIntOrNull() ?: 50

                    if (title.isNotEmpty() && finalPrice > 0) {
                        val product = ProductEntity(
                            id = nextId,
                            title = title,
                            description = description,
                            price = finalPrice,
                            originalPrice = finalOriginalPrice,
                            category = category,
                            rating = 4.8,
                            unit = unitSize,
                            imageLocalResName = "ic_custom", // mock drawable fallback, uses custom emoji
                            rollback = isRollback,
                            stock = finalStock,
                            calories = (60..400).random(),
                            organic = isOrganic
                        )
                        onSave(product)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                modifier = Modifier.testTag("submit_product_btn")
            ) {
                Text("Insert Product")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.Gray)
            }
        }
    )
}

@Composable
fun EditProductDialog(
    product: ProductEntity,
    onDismiss: () -> Unit,
    onSave: (ProductEntity) -> Unit
) {
    var title by remember { mutableStateOf(product.title) }
    var description by remember { mutableStateOf(product.description) }
    var category by remember { mutableStateOf(product.category) }
    var priceStr by remember { mutableStateOf(product.price.toString()) }
    var origPriceStr by remember { mutableStateOf(product.originalPrice.toString()) }
    var stockStr by remember { mutableStateOf(product.stock.toString()) }
    var isRollback by remember { mutableStateOf(product.rollback) }
    var isOrganic by remember { mutableStateOf(product.organic) }
    var unitSize by remember { mutableStateOf(product.unit) }

    val categories = listOf("Groceries", "Bakery & Desserts", "Meat & Seafood", "Dairy & Eggs", "Beverages", "Pantry & Snacks", "Household Essentials")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Editing: ${product.title}", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Product Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("edit_title_field")
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )

                // Category selector
                Column {
                    Text("Supermarket Department:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Slate700)
                    Box(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(vertical = 4.dp)) {
                            categories.forEach { cat ->
                                FilterChip(
                                    selected = category == cat,
                                    onClick = { category = cat },
                                    label = { Text(cat, fontSize = 10.sp) }
                                )
                            }
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = priceStr,
                        onValueChange = { priceStr = it },
                        label = { Text("Active Price ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1.1f).testTag("edit_price_field"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = origPriceStr,
                        onValueChange = { origPriceStr = it },
                        label = { Text("Original Price ($)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = stockStr,
                        onValueChange = { stockStr = it },
                        label = { Text("Inventory Count") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1.3f).testTag("edit_stock_field"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = unitSize,
                        onValueChange = { unitSize = it },
                        label = { Text("Unit Size") },
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                // Boolean flags togglers
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isRollback, onCheckedChange = { isRollback = it }, modifier = Modifier.testTag("edit_rollback_chk"))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Trigger Active Rollback (Weekly Deal)")
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isOrganic, onCheckedChange = { isOrganic = it })
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("USDA Certified Organic Healthy")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val finalPrice = priceStr.toDoubleOrNull() ?: product.price
                    val finalOriginalPrice = origPriceStr.toDoubleOrNull() ?: product.originalPrice
                    val finalStock = stockStr.toIntOrNull() ?: product.stock

                    if (title.isNotEmpty() && finalPrice > 0) {
                        val updated = product.copy(
                            title = title,
                            description = description,
                            price = finalPrice,
                            originalPrice = finalOriginalPrice,
                            category = category,
                            unit = unitSize,
                            rollback = isRollback,
                            stock = finalStock,
                            organic = isOrganic
                        )
                        onSave(updated)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                modifier = Modifier.testTag("save_modifications_btn")
            ) {
                Text("Apply Modifications")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = Color.Gray)
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun BannersManagerView(
    banners: List<BannerEntity>,
    onSaveBanner: (BannerEntity) -> Unit,
    onDeleteBanner: (Int) -> Unit
) {
    var showAddBannerDialog by remember { mutableStateOf(false) }
    var editBannerTarget by remember { mutableStateOf<BannerEntity?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Sliding Heat Banner Deck",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = Slate900
                )
                Text(
                    text = "Configure Top, Middle & Bottom sliding displays.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }
            Button(
                onClick = { showAddBannerDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("admin_add_banner_btn")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Slide", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (banners.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("No sliding banners configured yet. Add one!", color = Color.Gray)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val sections = listOf(
                    "top" to "Top Landing Slides",
                    "middle" to "Middle Section Hot Deals",
                    "bottom" to "Bottom Stock up & Save"
                )
                sections.forEach { (sectionKey, sectionHeader) ->
                    val sectionBanners = banners.filter { it.section == sectionKey }
                    if (sectionBanners.isNotEmpty()) {
                        item {
                            Text(
                                text = sectionHeader.uppercase(),
                                style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                                color = FreshMartBlue,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                        items(sectionBanners) { banner ->
                            BannerAdminCard(
                                banner = banner,
                                onEditClick = { editBannerTarget = banner },
                                onToggleActive = { active -> 
                                    onSaveBanner(banner.copy(active = active)) 
                                },
                                onDeleteClick = { onDeleteBanner(banner.id) }
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddBannerDialog) {
        BannerEditDialog(
            banner = null,
            onDismiss = { showAddBannerDialog = false },
            onConfirm = { newBanner ->
                onSaveBanner(newBanner)
                showAddBannerDialog = false
            }
        )
    }

    if (editBannerTarget != null) {
        BannerEditDialog(
            banner = editBannerTarget,
            onDismiss = { editBannerTarget = null },
            onConfirm = { updatedBanner ->
                onSaveBanner(updatedBanner)
                editBannerTarget = null
            }
        )
    }
}

@Composable
fun BannerAdminCard(
    banner: BannerEntity,
    onEditClick: () -> Unit,
    onToggleActive: (Boolean) -> Unit,
    onDeleteClick: () -> Unit
) {
    val bgParsedColor = try {
        Color(android.graphics.Color.parseColor(banner.backgroundColor))
    } catch (e: Exception) {
        FreshMartBlue
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Slate100),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(bgParsedColor),
                contentAlignment = Alignment.Center
            ) {
                Text(banner.imageEmoji, fontSize = 24.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Slate100)
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = banner.section.uppercase(),
                            color = Slate700,
                            style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(FreshMartAmber.copy(alpha = 0.2f))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = banner.targetCategory,
                            color = FreshMartBlue,
                            style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = banner.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = Slate900
                )
                Text(
                    text = banner.subtitle,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Switch(
                    checked = banner.active,
                    onCheckedChange = onToggleActive,
                    modifier = Modifier.scale(0.72f).testTag("banner_active_switch_${banner.id}")
                )
                IconButton(onClick = onEditClick, modifier = Modifier.size(32.dp).testTag("banner_edit_btn_${banner.id}")) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Banner", tint = Slate700, modifier = Modifier.size(16.dp))
                }
                IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp).testTag("banner_delete_btn_${banner.id}")) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete Banner", tint = RollbackRed, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BannerEditDialog(
    banner: BannerEntity?,
    onDismiss: () -> Unit,
    onConfirm: (BannerEntity) -> Unit
) {
    var title by remember { mutableStateOf(banner?.title ?: "") }
    var subtitle by remember { mutableStateOf(banner?.subtitle ?: "") }
    var section by remember { mutableStateOf(banner?.section ?: "top") }
    var targetCategory by remember { mutableStateOf(banner?.targetCategory ?: "All") }
    var backgroundColor by remember { mutableStateOf(banner?.backgroundColor ?: "#0284C7") }
    var imageEmoji by remember { mutableStateOf(banner?.imageEmoji ?: "🍏") }

    val categories = listOf("All", "Groceries", "Bakery & Desserts", "Beverages", "Meat & Seafood", "Dairy & Eggs", "Pantry & Snacks", "Household Essentials")
    val sections = listOf("top" to "Top", "middle" to "Middle", "bottom" to "Bottom")
    val colorPalettes = listOf(
        Pair("#0284C7", "Sky Blue"),
        Pair("#D97706", "Amber Gold"),
        Pair("#059669", "Emerald"),
        Pair("#DC2626", "Rollback Red"),
        Pair("#2563EB", "Walmart Blue"),
        Pair("#7C3AED", "Violet"),
        Pair("#4B5563", "Slate Gray"),
        Pair("#EC4899", "Pink Logo")
    )
    val emojis = listOf("🍏", "🥐", "🥤", "🥩", "🧀", "🥨", "🧼", "🍉", "🥛", "🍉", "🍓", "🥫", "🍇", "🥑", "🛒", "🥑", "🍍", "🍟", "🧻")

    var categoryExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (banner == null) "Create Sliding Promotion" else "Modify Banner Slide",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                color = Slate900
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("LIVE INTERACTIVE MOCKUP PREVIEW", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray))
                val previewBg = try { Color(android.graphics.Color.parseColor(backgroundColor)) } catch(e:Exception) { FreshMartBlue }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(90.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(previewBg)
                        .padding(12.dp)
                ) {
                    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.White.copy(alpha = 0.22f))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = targetCategory.uppercase(),
                                    style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                )
                            }
                            Text(
                                text = if (title.isEmpty()) "Promo Title Preview" else title,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.bodyMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (subtitle.isEmpty()) "Subtext/Call to action banner description." else subtitle,
                                color = Color.White.copy(alpha = 0.9f),
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(imageEmoji, fontSize = 40.sp)
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Promotion Headline") },
                    placeholder = { Text("e.g. Sizzling Ribeye Steaks") },
                    modifier = Modifier.fillMaxWidth().testTag("banner_input_title"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = subtitle,
                    onValueChange = { subtitle = it },
                    label = { Text("Sub-header details") },
                    placeholder = { Text("e.g. Save $4 per pack this weekend") },
                    modifier = Modifier.fillMaxWidth().testTag("banner_input_subtitle"),
                    singleLine = true
                )

                Text("Horizontal Page Section", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold), color = Slate800)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    sections.forEach { (secKey, secLabel) ->
                        val isSel = section == secKey
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSel) Slate900 else Slate100)
                                .clickable { section = secKey }
                                .border(BorderStroke(1.dp, if (isSel) Slate900 else Color.Transparent), RoundedCornerShape(8.dp))
                                .testTag("banner_section_btn_$secKey"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = secLabel,
                                color = if (isSel) Color.White else Slate700,
                                style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }

                Text("Target Collection Department", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold), color = Slate800)
                ExposedDropdownMenuBox(
                    expanded = categoryExpanded,
                    onExpandedChange = { categoryExpanded = it }
                ) {
                    OutlinedTextField(
                        value = targetCategory,
                        onValueChange = {},
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor(),
                        colors = OutlinedTextFieldDefaults.colors()
                    )
                    ExposedDropdownMenu(
                        expanded = categoryExpanded,
                        onDismissRequest = { categoryExpanded = false },
                        modifier = Modifier.background(Color.White)
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    targetCategory = cat
                                    categoryExpanded = false
                                }
                            )
                        }
                    }
                }

                Text("Palette Background Block", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold), color = Slate800)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(colorPalettes) { (hex, name) ->
                        val color = Color(android.graphics.Color.parseColor(hex))
                        val isSelected = backgroundColor == hex
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(CircleShape)
                                .background(color)
                                .clickable { backgroundColor = hex }
                                .border(
                                    border = BorderStroke(if (isSelected) 3.dp else 0.dp, Slate900),
                                    shape = CircleShape
                                )
                                .testTag("banner_color_btn_$hex")
                        )
                    }
                }

                Text("Graphic Illustration Emoji", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold), color = Slate800)
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(emojis) { emo ->
                        val isSelected = imageEmoji == emo
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) Slate200 else Color.Transparent)
                                .clickable { imageEmoji = emo }
                                .testTag("banner_emoji_btn_$emo"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(emo, fontSize = 22.sp)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotEmpty() && subtitle.isNotEmpty()) {
                        val toSave = banner?.copy(
                            title = title,
                            subtitle = subtitle,
                            section = section,
                            targetCategory = targetCategory,
                            backgroundColor = backgroundColor,
                            imageEmoji = imageEmoji
                        ) ?: BannerEntity(
                            title = title,
                            subtitle = subtitle,
                            section = section,
                            targetCategory = targetCategory,
                            backgroundColor = backgroundColor,
                            imageEmoji = imageEmoji,
                            active = true
                        )
                        onConfirm(toSave)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                enabled = title.isNotEmpty() && subtitle.isNotEmpty(),
                modifier = Modifier.testTag("banner_dialog_confirm_btn")
            ) {
                Text("Confirm Save")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                colors = ButtonDefaults.textButtonColors(contentColor = Slate700),
                modifier = Modifier.testTag("banner_dialog_cancel_btn")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun AdminPasscodeGate(
    pinInput: String,
    pinError: Boolean,
    onDigitClick: (String) -> Unit,
    onDeleteClick: () -> Unit,
    onBackClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Slate900, Color(0xFF0F172A))
                )
            )
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(28.dp),
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 400.dp)
        ) {
            // Header with Security Icon
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(
                            if (pinError) RollbackRed.copy(alpha = 0.15f)
                            else FreshMartAmber.copy(alpha = 0.15f)
                        )
                        .border(
                            width = 2.dp,
                            color = if (pinError) RollbackRed else FreshMartAmber,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (pinError) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = "Lock Status",
                        tint = if (pinError) RollbackRed else FreshMartAmber,
                        modifier = Modifier.size(36.dp)
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "FRESHMART SECURITY",
                        color = FreshMartAmber,
                        style = TextStyle(
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 2.sp
                        )
                    )
                    Text(
                        text = "Supermarket Owner Access",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    )
                    Text(
                        text = "Enter 6-digit administrator credentials to manage prices, inventory, orders & slide banners.",
                        color = Color.LightGray.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )
                }
            }

            // Bullet Indicators representing digits
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                repeat(6) { index ->
                    val isFilled = index < pinInput.length
                    Box(
                        modifier = Modifier
                            .size(16.dp)
                            .clip(CircleShape)
                            .background(
                                if (isFilled) {
                                    if (pinError) RollbackRed else FreshMartAmber
                                } else {
                                    Color.White.copy(alpha = 0.15f)
                                }
                            )
                            .border(
                                width = 1.dp,
                                color = if (isFilled) {
                                    if (pinError) RollbackRed else FreshMartAmber
                                } else {
                                    Color.White.copy(alpha = 0.3f)
                                },
                                shape = CircleShape
                            )
                            .testTag("admin_pin_bullet_$index")
                    )
                }
            }

            // Error Feedback
            Box(modifier = Modifier.height(20.dp), contentAlignment = Alignment.Center) {
                if (pinError) {
                    Text(
                        text = "Access Denied: Incorrect PIN Code",
                        color = RollbackRed,
                        style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.SemiBold),
                        modifier = Modifier.testTag("admin_pin_error_msg")
                    )
                }
            }

            // Numeric Keypad Grid (ATM style layout)
            Column(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
            ) {
                val keyboardRows = listOf(
                    listOf("1", "2", "3"),
                    listOf("4", "5", "6"),
                    listOf("7", "8", "9"),
                    listOf("BACK", "0", "DEL")
                )

                keyboardRows.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        row.forEach { key ->
                            when (key) {
                                "DEL" -> {
                                    IconButton(
                                        onClick = onDeleteClick,
                                        modifier = Modifier
                                            .size(68.dp)
                                            .clip(CircleShape)
                                            .background(Color.White.copy(alpha = 0.05f))
                                            .testTag("admin_pin_delete_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Backspace,
                                            contentDescription = "Backspace",
                                            tint = Color.White
                                        )
                                    }
                                }
                                "BACK" -> {
                                    IconButton(
                                        onClick = onBackClick,
                                        modifier = Modifier
                                            .size(68.dp)
                                            .clip(CircleShape)
                                            .background(Color.White.copy(alpha = 0.05f))
                                            .testTag("admin_pin_back_btn")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowBack,
                                            contentDescription = "Cancel/Back",
                                            tint = Color.LightGray
                                        )
                                    }
                                }
                                else -> {
                                    Box(
                                        modifier = Modifier
                                            .size(68.dp)
                                            .clip(CircleShape)
                                            .background(Color.White.copy(alpha = 0.1f))
                                            .clickable { onDigitClick(key) }
                                            .testTag("admin_pin_digit_$key"),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = key,
                                            style = TextStyle(
                                                fontSize = 24.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// POS Order receipt structural definition
data class PosOrderInfo(
    val orderId: String,
    val items: List<Pair<ProductEntity, Int>>,
    val subtotal: Double,
    val discount: Double,
    val tax: Double,
    val grandTotal: Double,
    val paymentMethod: String,
    val amountPaid: Double,
    val changeDue: Double,
    val timestamp: Long,
    val walletNumber: String = "",
    val transactionId: String = ""
)

val Slate600 = Color(0xFF475569)

fun ProductEntity.getBarcode(): String {
    return String.format(Locale.US, "999%05d", id)
}

@Composable
fun PosTerminalView(
    viewModel: FreshMartViewModel,
    products: List<ProductEntity>
) {
    var barcodeInput by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var discountPercentage by remember { mutableStateOf(0) }
    var couponInput by remember { mutableStateOf("") }
    var couponStatus by remember { mutableStateOf("") }
    
    val posCart = remember { mutableStateListOf<Pair<ProductEntity, Int>>() }
    var showCameraScanner by remember { mutableStateOf(false) }
    var showCheckoutDialog by remember { mutableStateOf(false) }
    var activeReceipt by remember { mutableStateOf<PosOrderInfo?>(null) }
    
    val context = LocalContext.current

    // Compute totals
    val subtotal = posCart.sumOf { it.first.price * it.second }
    val savings = posCart.sumOf { (it.first.originalPrice - it.first.price) * it.second }
    val discountAmount = subtotal * (discountPercentage / 100.0)
    val taxableAmount = maxOf(0.0, subtotal - discountAmount)
    val taxAmount = taxableAmount * 0.075 // 7.5% sales tax
    val grandTotal = taxableAmount + taxAmount

    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAFC)) // Soft light background
    ) {
        // Left Panel (Cart Ticket and Subtotals)
        Column(
            modifier = Modifier
                .weight(1.2f)
                .fillMaxHeight()
                .background(Color.White)
                .border(BorderStroke(1.dp, Color(0xFFE2E8F0)))
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Receipt,
                        contentDescription = null,
                        tint = FreshMartBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = "POS Checkout Ticket",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                        color = Slate900
                    )
                }
                Text(
                    text = "${posCart.sumOf { it.second }} Items",
                    style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate700),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Slate100)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Barcode input box (supports typing or hand scanner wedge)
            OutlinedTextField(
                value = barcodeInput,
                onValueChange = { input ->
                    barcodeInput = input
                    // Auto scan if barcode matches instantly
                    val cleaned = input.trim()
                    val match = products.find { it.getBarcode() == cleaned }
                    if (match != null) {
                        val index = posCart.indexOfFirst { it.first.id == match.id }
                        if (index >= 0) {
                            posCart[index] = Pair(match, posCart[index].second + 1)
                        } else {
                            posCart.add(Pair(match, 1))
                        }
                        barcodeInput = ""
                        Toast.makeText(context, "Scan Beep! Added ${match.title}", Toast.LENGTH_SHORT).show()
                    }
                },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null, tint = Slate600)
                },
                placeholder = { Text("Scan / Type product barcode (e.g. 99900001)") },
                label = { Text("Barcode Wedge Reader") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pos_barcode_input"),
                trailingIcon = {
                    if (barcodeInput.isNotEmpty()) {
                        IconButton(onClick = { barcodeInput = "" }) {
                            Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Quick barcode emulator clickable list
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "Hardware Emulator Quick Scanners:",
                    style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate600)
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(products.take(6)) { item ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Slate100)
                                .border(BorderStroke(1.dp, Slate200), RoundedCornerShape(6.dp))
                                .clickable {
                                    barcodeInput = item.getBarcode()
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${getEmojiForProduct(item.id)} Scan U:${item.getBarcode().takeLast(3)}",
                                style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate900)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Phone Camera and Void buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { showCameraScanner = true },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("pos_phone_camera_scanner_btn"),
                    colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Phone Camera scan", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                }

                OutlinedButton(
                    onClick = {
                        posCart.clear()
                        discountPercentage = 0
                        Toast.makeText(context, "POS Ticket Voided", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.weight(0.7f),
                    enabled = posCart.isNotEmpty(),
                    border = BorderStroke(1.dp, RollbackRed),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RollbackRed),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Void Cart", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Pos list of active items
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(BorderStroke(1.dp, Color(0xFFE2E8F0)), RoundedCornerShape(8.dp))
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFFF8FAFC))
            ) {
                if (posCart.isEmpty()) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("Active sales list is blank", color = Color.Gray, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Tap touchscreen items or click quick barcode tools", color = Color.Gray.copy(alpha = 0.7f), fontSize = 11.sp)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(posCart.toList()) { (product, qty) ->
                            PosCartItemCard(
                                product = product,
                                quantity = qty,
                                onIncrement = {
                                    val index = posCart.indexOfFirst { it.first.id == product.id }
                                    if (index >= 0) posCart[index] = Pair(product, qty + 1)
                                },
                                onDecrement = {
                                    val index = posCart.indexOfFirst { it.first.id == product.id }
                                    if (index >= 0) {
                                        if (qty > 1) {
                                            posCart[index] = Pair(product, qty - 1)
                                        } else {
                                            posCart.removeAt(index)
                                        }
                                    }
                                },
                                onDelete = {
                                    posCart.removeAll { it.first.id == product.id }
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Summary breakdown Card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F5F9)),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Premium Discount & Coupon Code Panel
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "POS Discount & Coupons",
                                style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate700)
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf(0, 10, 20, 50).forEach { pct ->
                                    val selected = discountPercentage == pct
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(if (selected) FreshMartAmber else Color.White)
                                            .border(
                                                BorderStroke(1.dp, if (selected) FreshMartAmber else Color(0xFFCBD5E1)),
                                                RoundedCornerShape(6.dp)
                                            )
                                            .clickable {
                                                discountPercentage = pct
                                                couponInput = ""
                                                couponStatus = if (pct > 0) "Preset $pct% Discount Selected" else ""
                                            }
                                            .padding(horizontal = 8.dp, vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (pct == 0) "0%" else "$pct%",
                                            style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Slate900)
                                        )
                                    }
                                }
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = couponInput,
                                onValueChange = { input ->
                                    couponInput = input
                                    val clean = input.trim().uppercase()
                                    when (clean) {
                                        "SHOHID10" -> {
                                            discountPercentage = 10
                                            couponStatus = "Coupon SHOHID10 Applied (10% Off)"
                                        }
                                        "FRESH25" -> {
                                            discountPercentage = 25
                                            couponStatus = "Coupon FRESH25 Applied (25% Off)"
                                        }
                                        "MEGA50" -> {
                                            discountPercentage = 50
                                            couponStatus = "Coupon MEGA50 Applied (50% Off)"
                                        }
                                        "FREE" -> {
                                            discountPercentage = 100
                                            couponStatus = "Coupon FREE Applied (100% Off)"
                                        }
                                        else -> {
                                            val parsedPct = clean.toIntOrNull()
                                            if (parsedPct != null && parsedPct in 0..100) {
                                                discountPercentage = parsedPct
                                                couponStatus = "Custom $parsedPct% Discount Applied"
                                            } else if (clean.isEmpty()) {
                                                discountPercentage = 0
                                                couponStatus = ""
                                            } else {
                                                couponStatus = "Searching/Invalid Code..."
                                            }
                                        }
                                    }
                                },
                                placeholder = { Text("Coupon (e.g. SHOHID10) or Custom % (e.g. 15)", fontSize = 10.sp) },
                                label = { Text("Promo Code / Manual %", fontSize = 9.sp) },
                                singleLine = true,
                                textStyle = TextStyle(fontSize = 11.sp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("pos_coupon_input"),
                                shape = RoundedCornerShape(8.dp)
                            )
                        }

                        if (couponStatus.isNotEmpty()) {
                            Text(
                                text = couponStatus,
                                color = if (couponStatus.contains("Applied") || couponStatus.contains("Selected")) OrganicGreen else RollbackRed,
                                style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                        }
                    }

                    Divider(color = Color(0xFFCBD5E1).copy(alpha = 0.5f))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Ticket Subtotal", color = Color.Gray, fontSize = 11.sp)
                        Text(String.format(Locale.US, "$%.2f", subtotal), color = Slate800, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    if (discountPercentage > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Discount Applied", color = RollbackRed, fontSize = 11.sp)
                            Text(String.format(Locale.US, "-$%.2f", discountAmount), color = RollbackRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Sales Tax (7.5%)", color = Color.Gray, fontSize = 11.sp)
                        Text(String.format(Locale.US, "$%.2f", taxAmount), color = Slate800, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Divider(color = Color(0xFFCBD5E1))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("GRAND TOTAL", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.ExtraBold), color = Slate900)
                        Text(String.format(Locale.US, "$%.2f", grandTotal), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = FreshMartBlue))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action payment button
            Button(
                onClick = { showCheckoutDialog = true },
                enabled = posCart.isNotEmpty(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("pos_checkout_btn"),
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Execute Checkout POS Ledger", style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold))
            }
        }

        // Right Panel (Quicktouch buttons database list)
        Column(
            modifier = Modifier
                .weight(0.8f)
                .fillMaxHeight()
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "Cashier Touch Panel",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = Slate900
                )
                Text(
                    text = "Tap product shortcuts to instantly checkout.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Slate600) },
                placeholder = { Text("Quick key filter...") },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pos_search_input"),
                shape = RoundedCornerShape(8.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            val filtered = products.filter {
                it.title.contains(searchQuery, ignoreCase = true) ||
                        it.category.contains(searchQuery, ignoreCase = true)
            }

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No matched items", color = Color.Gray, fontSize = 12.sp)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(filtered) { item ->
                        PosQuickKeyCard(
                            product = item,
                            onClick = {
                                val index = posCart.indexOfFirst { it.first.id == item.id }
                                if (index >= 0) {
                                    posCart[index] = Pair(item, posCart[index].second + 1)
                                } else {
                                    posCart.add(Pair(item, 1))
                                }
                                Toast.makeText(context, "${item.title} added!", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        }
    }

    if (showCameraScanner) {
        PosCameraScannerModal(
            products = products,
            onDismiss = { showCameraScanner = false },
            onScanProduct = { match ->
                val index = posCart.indexOfFirst { it.first.id == match.id }
                if (index >= 0) {
                    posCart[index] = Pair(match, posCart[index].second + 1)
                } else {
                    posCart.add(Pair(match, 1))
                }
                showCameraScanner = false
                Toast.makeText(context, "Camera Scan Beep! ${match.title}", Toast.LENGTH_SHORT).show()
            }
        )
    }

    if (showCheckoutDialog) {
        PosPaymentCheckoutDialog(
            grandTotal = grandTotal,
            subtotal = subtotal,
            discountAmount = discountAmount,
            taxAmount = taxAmount,
            posCart = posCart,
            viewModel = viewModel,
            onDismiss = { showCheckoutDialog = false },
            onCheckoutSuccess = { details ->
                posCart.clear()
                discountPercentage = 0
                showCheckoutDialog = false
                activeReceipt = details
            }
        )
    }

    if (activeReceipt != null) {
        PosReceiptDialog(
            receipt = activeReceipt!!,
            onDismiss = { activeReceipt = null }
        )
    }
}

@Composable
fun PosCartItemCard(
    product: ProductEntity,
    quantity: Int,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(Slate100),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = getEmojiForProduct(product.id),
                    style = TextStyle(fontSize = 20.sp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.title,
                    style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = Slate900
                )
                Text(
                    text = "UPC: ${product.getBarcode()}",
                    style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                )
                Text(
                    text = String.format(Locale.US, "$%.2f ea", product.price),
                    style = TextStyle(fontSize = 11.sp, color = Slate600)
                )
            }

            // Quantity adjusters
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(30.dp))
                    .background(Color(0xFFF1F5F9))
                    .border(BorderStroke(1.dp, Color(0xFFE2E8F0)), RoundedCornerShape(30.dp))
                    .padding(2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                IconButton(
                    onClick = onDecrement,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(imageVector = Icons.Default.Remove, contentDescription = "Minus", modifier = Modifier.size(12.dp), tint = Slate700)
                }
                Text(
                    text = quantity.toString(),
                    style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                    color = Slate900
                )
                IconButton(
                    onClick = onIncrement,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Plus", modifier = Modifier.size(12.dp), tint = Slate700)
                }
            }

            Text(
                text = String.format(Locale.US, "$%.2f", product.price * quantity),
                style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Black, color = FreshMartBlue)
            )

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(28.dp)
            ) {
                Icon(imageVector = Icons.Default.Delete, contentDescription = "Trash", tint = RollbackRed.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun PosQuickKeyCard(
    product: ProductEntity,
    onClick: () -> Unit
) {
    val isLowStock = product.stock <= 10

    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isLowStock) Color(0xFFFEF2F2) else Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(
            width = 1.dp,
            color = if (isLowStock) Color(0xFFFCA5A5) else Color(0xFFE2E8F0)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(if (isLowStock) Color(0xFFFEE2E2) else Slate50),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = getEmojiForProduct(product.id), fontSize = 16.sp)
                }

                if (isLowStock) {
                    Text(
                        text = "LowStock: ${product.stock}",
                        color = RollbackRed,
                        style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Black),
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color(0xFFFEE2E2))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    )
                } else {
                    Text(
                        text = "Stock: ${product.stock}",
                        color = Color.Gray,
                        style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Column {
                Text(
                    text = product.title,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                    color = Slate900
                )
                Text(
                    text = "UPC: ${product.getBarcode()}",
                    style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Slate600)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = String.format(Locale.US, "$%.2f", product.price),
                    style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Black, color = FreshMartBlue)
                )
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(FreshMartBlue.copy(alpha = 0.1f))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "+ ADD",
                        style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Black, color = FreshMartBlue)
                    )
                }
            }
        }
    }
}

@Composable
fun PosCameraScannerModal(
    products: List<ProductEntity>,
    onDismiss: () -> Unit,
    onScanProduct: (ProductEntity) -> Unit
) {
    var searchByCameraQuery by remember { mutableStateOf("") }
    var activelySimulatingScanningItem by remember { mutableStateOf<ProductEntity?>(null) }
    var scanProgress by remember { mutableStateOf(0f) }
    
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    LaunchedEffect(activelySimulatingScanningItem) {
        if (activelySimulatingScanningItem != null) {
            scanProgress = 0f
            while (scanProgress < 1f) {
                kotlinx.coroutines.delay(50)
                scanProgress += 0.05f
            }
            onScanProduct(activelySimulatingScanningItem!!)
            activelySimulatingScanningItem = null
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, tint = FreshMartBlue)
                    Text("Phone Camera Barcode Scanner", style = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Bold))
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Interactive Camera Viewfinder
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                        .border(2.dp, if (activelySimulatingScanningItem != null) FreshMartAmber else Color.White, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (activelySimulatingScanningItem != null) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            CircularProgressIndicator(
                                progress = scanProgress,
                                color = FreshMartAmber,
                                trackColor = Color.White.copy(alpha = 0.2f),
                                modifier = Modifier.size(40.dp)
                            )
                            Text(
                                text = "Camera autofocussing on UPC stick: ${activelySimulatingScanningItem!!.getBarcode()}...",
                                color = Color.White,
                                style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            )
                        }
                    } else {
                        // Viewfinder guide
                        Box(modifier = Modifier.fillMaxSize()) {
                            // Red laser line helper
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(2.dp)
                                    .background(RollbackRed)
                                    .align(Alignment.Center)
                            )
                            Text(
                                text = "[ LIVE POSITION OVERLAY VIEWPORT ]",
                                color = Color.White.copy(alpha = 0.5f),
                                style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.ExtraBold),
                                modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp)
                            )
                            Text(
                                text = "Align physical barcode inside scanner grid to auto trigger recognition",
                                color = Color.White.copy(alpha = 0.6f),
                                style = TextStyle(fontSize = 8.sp, textAlign = TextAlign.Center),
                                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 12.dp)
                            )
                        }
                    }
                }

                Text(
                    text = "Select a product shelf item below to simulate pointing the device's camera:",
                    color = Slate700,
                    style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold)
                )

                OutlinedTextField(
                    value = searchByCameraQuery,
                    onValueChange = { searchByCameraQuery = it },
                    placeholder = { Text("Filter items...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp)
                )

                // List of items to simulate camera targeting
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .border(BorderStroke(1.dp, Slate200), RoundedCornerShape(8.dp))
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    val filteredList = products.filter {
                        it.title.contains(searchByCameraQuery, ignoreCase = true)
                    }
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        contentPadding = PaddingValues(4.dp)
                    ) {
                        items(filteredList) { prod ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        activelySimulatingScanningItem = prod
                                    }
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(text = getEmojiForProduct(prod.id), fontSize = 16.sp)
                                    Column {
                                        Text(text = prod.title, style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                                        Text(text = "UPC ${prod.getBarcode()}", style = TextStyle(fontSize = 8.sp, color = Color.Gray))
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(FreshMartBlue)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("POINT LENS", color = Color.White, style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Black))
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = Slate100, contentColor = Slate900),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Cancel / Shut Lens")
            }
        }
    )
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PosPaymentCheckoutDialog(
    grandTotal: Double,
    subtotal: Double,
    discountAmount: Double,
    taxAmount: Double,
    posCart: List<Pair<ProductEntity, Int>>,
    viewModel: FreshMartViewModel,
    onDismiss: () -> Unit,
    onCheckoutSuccess: (PosOrderInfo) -> Unit
) {
    var paymentMethod by remember { mutableStateOf("Cash") } // Cash, Card, bKash, or Nagad
    var cashPaid by remember { mutableStateOf("") }
    
    // Card simulation states
    var cardStep by remember { mutableStateOf("idle") } // idle, processing, complete
    var cardStepProgress by remember { mutableStateOf(0f) }

    // bKash simulation states
    var bKashPhone by remember { mutableStateOf("") }
    var bKashOTP by remember { mutableStateOf("") }
    var bKashPIN by remember { mutableStateOf("") }
    var bKashStep by remember { mutableStateOf("input_number") } // input_number, input_otp, input_pin, complete
    var bKashGeneratedOTP by remember { mutableStateOf("") }
    var bKashGeneratedTxnId by remember { mutableStateOf("") }
    var bKashProcessingProgress by remember { mutableStateOf(0f) }

    // Nagad simulation states
    var nagadPhone by remember { mutableStateOf("") }
    var nagadOTP by remember { mutableStateOf("") }
    var nagadPIN by remember { mutableStateOf("") }
    var nagadStep by remember { mutableStateOf("input_number") } // input_number, input_otp, input_pin, complete
    var nagadGeneratedOTP by remember { mutableStateOf("") }
    var nagadGeneratedTxnId by remember { mutableStateOf("") }
    var nagadProcessingProgress by remember { mutableStateOf(0f) }
    
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val totalAmountPaid = if (paymentMethod == "Cash") {
        cashPaid.toDoubleOrNull() ?: 0.0
    } else {
        grandTotal
    }
    val changeDue = maxOf(0.0, totalAmountPaid - grandTotal)
    val isCashSufficient = paymentMethod == "Cash" && totalAmountPaid >= grandTotal

    LaunchedEffect(cardStep) {
        if (cardStep == "processing") {
            cardStepProgress = 0f
            while (cardStepProgress < 1f) {
                kotlinx.coroutines.delay(40)
                cardStepProgress += 0.05f
            }
            cardStep = "complete"
        }
    }

    LaunchedEffect(bKashStep) {
        if (bKashStep == "processing_verification") {
            bKashProcessingProgress = 0f
            while (bKashProcessingProgress < 1f) {
                kotlinx.coroutines.delay(40)
                bKashProcessingProgress += 0.05f
            }
            bKashGeneratedTxnId = "BKSH" + (100000..999999).random().toString() + "X"
            bKashStep = "complete"
        }
    }

    LaunchedEffect(nagadStep) {
        if (nagadStep == "processing_verification") {
            nagadProcessingProgress = 0f
            while (nagadProcessingProgress < 1f) {
                kotlinx.coroutines.delay(40)
                nagadProcessingProgress += 0.05f
            }
            nagadGeneratedTxnId = "NGD" + (100000..999999).random().toString() + "Y"
            nagadStep = "complete"
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "POS Cashier Payment Terminal",
                    style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Black, color = Slate900)
                )
                Text(
                    text = "Reg #04",
                    style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate600),
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(Slate100)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Total Due Callout
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(FreshMartBlue.copy(alpha = 0.06f))
                        .border(BorderStroke(1.dp, FreshMartBlue.copy(alpha = 0.15f)), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "LEDGER BALANCE DUE:",
                            style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = FreshMartBlue)
                        )
                        Text(
                            text = String.format(Locale.US, "$%.2f", grandTotal),
                            style = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Black, color = FreshMartBlue)
                        )
                    }
                }

                // Choose Payment Type Buttons Organized 2x2 Grid
                Column(
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "SELECT PAYMENT GATEWAY",
                        style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, color = Slate600)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { paymentMethod = "Cash" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (paymentMethod == "Cash") Slate900 else Slate100,
                                contentColor = if (paymentMethod == "Cash") Color.White else Slate700
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.AttachMoney, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Register Cash", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold))
                        }

                        Button(
                            onClick = { paymentMethod = "Card" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (paymentMethod == "Card") Slate900 else Slate100,
                                contentColor = if (paymentMethod == "Card") Color.White else Slate700
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Credit Card", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold))
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // bKash Button (Distinctive Deep Pink/Magenta branding)
                        Button(
                            onClick = { paymentMethod = "bKash" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (paymentMethod == "bKash") Color(0xFFE2125B) else Color(0xFFFFECEF),
                                contentColor = if (paymentMethod == "bKash") Color.White else Color(0xFFE2125B)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("bKash Wallet", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold))
                        }

                        // Nagad Button (Distinctive Vibrant Orange/Red branding)
                        Button(
                            onClick = { paymentMethod = "Nagad" },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (paymentMethod == "Nagad") Color(0xFFF15A22) else Color(0xFFFFF2EC),
                                contentColor = if (paymentMethod == "Nagad") Color.White else Color(0xFFF15A22)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 4.dp)
                        ) {
                            Icon(imageVector = Icons.Default.AccountBalanceWallet, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(3.dp))
                            Text("Nagad Wallet", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold))
                        }
                    }
                }

                Divider(color = Slate200.copy(alpha = 0.6f))

                if (paymentMethod == "Cash") {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = cashPaid,
                            onValueChange = { cashPaid = it },
                            leadingIcon = { Icon(imageVector = Icons.Default.AttachMoney, contentDescription = null) },
                            placeholder = { Text("Enter Cash amount tendered...") },
                            label = { Text("Cash Received From Customer (USD / ৳)") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(8.dp)
                        )

                        // Cash quick buttons matching common currency presets
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            listOf(5.0, 10.0, 20.0, 50.0, 100.0, 500.0).forEach { preset ->
                                if (preset >= grandTotal) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Slate100)
                                            .border(BorderStroke(1.dp, Slate200), RoundedCornerShape(6.dp))
                                            .clickable {
                                                cashPaid = String.format(Locale.US, "%.2f", preset)
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = String.format(Locale.US, "$%.0f", preset),
                                            style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Black, color = Slate900)
                                        )
                                    }
                                }
                            }
                        }

                        // Realtime Change Due calculations
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isCashSufficient) Color(0xFFECFDF5) else Slate50)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("CHANGE BACK DUE:", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Slate700))
                            Text(
                                text = String.format(Locale.US, "$%.2f", changeDue),
                                style = TextStyle(
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black,
                                    color = if (isCashSufficient) Color(0xFF10B981) else Color.Gray
                                )
                            )
                        }
                    }
                } else if (paymentMethod == "Card") {
                    // Card payment flow simulation
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (cardStep == "idle") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(115.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFE2E8F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(imageVector = Icons.Default.CreditCard, contentDescription = null, tint = Slate600, modifier = Modifier.size(32.dp))
                                    Text("Simulated EMV Terminal Ready", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                                    Text("TAP, SWIPE OR DIRECT CHIP INSERT", style = TextStyle(fontSize = 8.sp, color = Color.Gray))
                                }
                            }

                            Button(
                                onClick = { cardStep = "processing" },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Slate900),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Simulate Card Present Tap", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                            }
                        } else if (cardStep == "processing") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(115.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Slate900),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    CircularProgressIndicator(progress = cardStepProgress, color = FreshMartAmber)
                                    Text("Authorizing Visa/Mastercard...", color = Color.White, style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold))
                                }
                            }
                        } else {
                            // approved complete
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(115.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFFECFDF5))
                                    .border(BorderStroke(1.dp, Color(0xFF10B981)), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(32.dp))
                                    Text("TRANSACTION SUCCESSFUL", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color(0xFF047857)))
                                    Text("Auth Code: FM-CRD-${(100000..999999).random()}", style = TextStyle(fontSize = 9.sp, color = Color.Gray))
                                }
                            }
                        }
                    }
                } else if (paymentMethod == "bKash") {
                    // bKash Mobile Wallet Simulation with authentic branding colors
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(1.dp, Color(0xFFE2125B).copy(alpha = 0.3f)), RoundedCornerShape(8.dp))
                            .background(Color(0xFFFFECEF))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE2125B)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("b", color = Color.White, style = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Black))
                            }
                            Text(
                                text = "bKash Automated Checkout",
                                style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color(0xFFE2125B))
                            )
                        }

                        if (bKashStep == "input_number") {
                            OutlinedTextField(
                                value = bKashPhone,
                                onValueChange = { if (it.length <= 11) bKashPhone = it },
                                placeholder = { Text("e.g. 01712345678", fontSize = 11.sp) },
                                label = { Text("Customer bKash Number (11-Digits)", fontSize = 10.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Button(
                                onClick = {
                                    if (bKashPhone.trim().length == 11) {
                                        bKashGeneratedOTP = (100000..999999).random().toString()
                                        bKashStep = "input_otp"
                                    } else {
                                        Toast.makeText(context, "Please enter a valid 11-digit mobile wallet number!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2125B)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Verify Account & dispatch SMS OTP", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                            }
                        } else if (bKashStep == "input_otp") {
                            // Display simulated SMS bubble for realistic customer feedback
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.White)
                                    .border(1.dp, Color(0xFFE2125B).copy(alpha = 0.2f))
                                    .padding(8.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("💬 SIMULATED MSG RECEIVED", style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Black, color = Color(0xFFE2125B)))
                                    Text("FreshMart verification token: $bKashGeneratedOTP. Use this to authorize transaction.", style = TextStyle(fontSize = 9.sp, color = Slate900, fontWeight = FontWeight.Medium))
                                }
                            }

                            OutlinedTextField(
                                value = bKashOTP,
                                onValueChange = { if (it.length <= 6) bKashOTP = it },
                                placeholder = { Text("Type 6-digit OTP code", fontSize = 11.sp) },
                                label = { Text("Enter OTP", fontSize = 10.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { bKashStep = "input_number" },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Back", style = TextStyle(fontSize = 11.sp))
                                }
                                Button(
                                    onClick = {
                                        if (bKashOTP.trim() == bKashGeneratedOTP) {
                                            bKashStep = "input_pin"
                                        } else {
                                            Toast.makeText(context, "Invalid OTP. Use simulated bubble value!", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.weight(1.5f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2125B)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Verify Token", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                                }
                            }
                        } else if (bKashStep == "input_pin") {
                            OutlinedTextField(
                                value = bKashPIN,
                                onValueChange = { if (it.length <= 5) bKashPIN = it },
                                placeholder = { Text("Type 5-digit PIN code", fontSize = 11.sp) },
                                label = { Text("Customer Account PIN (Simulation)", fontSize = 10.sp) },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { bKashStep = "input_otp" },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Back", style = TextStyle(fontSize = 11.sp))
                                }
                                Button(
                                    onClick = {
                                        if (bKashPIN.trim().length >= 4) {
                                            bKashStep = "processing_verification"
                                        } else {
                                            Toast.makeText(context, "Please enter numeric PIN to authorize!", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.weight(1.5f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE2125B)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Authorize Pay", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                                }
                            }
                        } else if (bKashStep == "processing_verification") {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(progress = bKashProcessingProgress, color = Color(0xFFE2125B))
                                Text("Incurring Merchant Charges on bKash Ledger...", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE2125B)))
                            }
                        } else {
                            // bKash Success Callout!
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFD1FAE5))
                                    .border(1.dp, Color(0xFF10B981), RoundedCornerShape(6.dp))
                                    .padding(8.dp)
                            ) {
                                Column {
                                    Text("✓ BKASH PAYMENT APPROVED", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF047857)))
                                    Text("Wallet: ${bKashPhone.take(4)}***${bKashPhone.takeLast(4)}", style = TextStyle(fontSize = 9.sp, color = Slate700))
                                    Text("TxnID: $bKashGeneratedTxnId", style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Slate900))
                                }
                            }
                            
                            OutlinedButton(
                                onClick = {
                                    bKashStep = "input_number"
                                    bKashPhone = ""
                                    bKashOTP = ""
                                    bKashPIN = ""
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Reset Wallet Form", style = TextStyle(fontSize = 10.sp))
                            }
                        }
                    }
                } else if (paymentMethod == "Nagad") {
                    // Nagad Mobile Wallet Simulation with authentic branding colors
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(BorderStroke(1.dp, Color(0xFFF15A22).copy(alpha = 0.3f)), RoundedCornerShape(8.dp))
                            .background(Color(0xFFFFF2EC))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFF15A22)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("N", color = Color.White, style = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Black))
                            }
                            Text(
                                text = "Nagad Automated Checkout",
                                style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color(0xFFF15A22))
                            )
                        }

                        if (nagadStep == "input_number") {
                            OutlinedTextField(
                                value = nagadPhone,
                                onValueChange = { if (it.length <= 11) nagadPhone = it },
                                placeholder = { Text("e.g. 01712345678", fontSize = 11.sp) },
                                label = { Text("Customer Nagad Number (11-Digits)", fontSize = 10.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Button(
                                onClick = {
                                    if (nagadPhone.trim().length == 11) {
                                        nagadGeneratedOTP = (100000..999999).random().toString()
                                        nagadStep = "input_otp"
                                    } else {
                                        Toast.makeText(context, "Please enter a valid 11-digit mobile wallet number!", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF15A22)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Verify Account & dispatch SMS OTP", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                            }
                        } else if (nagadStep == "input_otp") {
                            // Display simulated SMS bubble for realistic customer feedback
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.White)
                                    .border(1.dp, Color(0xFFF15A22).copy(alpha = 0.2f))
                                    .padding(8.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text("💬 SIMULATED MSG RECEIVED", style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Black, color = Color(0xFFF15A22)))
                                    Text("Nagad verification code: $nagadGeneratedOTP. Valid for 5 minutes.", style = TextStyle(fontSize = 9.sp, color = Slate900, fontWeight = FontWeight.Medium))
                                }
                            }

                            OutlinedTextField(
                                value = nagadOTP,
                                onValueChange = { if (it.length <= 6) nagadOTP = it },
                                placeholder = { Text("Type 6-digit OTP code", fontSize = 11.sp) },
                                label = { Text("Enter OTP", fontSize = 10.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { nagadStep = "input_number" },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Back", style = TextStyle(fontSize = 11.sp))
                                }
                                Button(
                                    onClick = {
                                        if (nagadOTP.trim() == nagadGeneratedOTP) {
                                            nagadStep = "input_pin"
                                        } else {
                                            Toast.makeText(context, "Invalid OTP! Check simulated bubble message.", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.weight(1.5f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF15A22)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Verify Token", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                                }
                            }
                        } else if (nagadStep == "input_pin") {
                            OutlinedTextField(
                                value = nagadPIN,
                                onValueChange = { if (it.length <= 4) nagadPIN = it },
                                placeholder = { Text("Type 4-digit PIN code", fontSize = 11.sp) },
                                label = { Text("Customer Account PIN (Simulation)", fontSize = 10.sp) },
                                singleLine = true,
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            )

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                OutlinedButton(
                                    onClick = { nagadStep = "input_otp" },
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Back", style = TextStyle(fontSize = 11.sp))
                                }
                                Button(
                                    onClick = {
                                        if (nagadPIN.trim().length >= 4) {
                                            nagadStep = "processing_verification"
                                        } else {
                                            Toast.makeText(context, "Please enter 4-digit PIN to authorize!", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    modifier = Modifier.weight(1.5f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF15A22)),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("Authorize Pay", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
                                }
                            }
                        } else if (nagadStep == "processing_verification") {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(progress = nagadProcessingProgress, color = Color(0xFFF15A22))
                                Text("Querying Nagad merchant database...", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFFF15A22)))
                            }
                        } else {
                            // Nagad Success Callout!
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFD1FAE5))
                                    .border(1.dp, Color(0xFF10B981), RoundedCornerShape(6.dp))
                                    .padding(8.dp)
                            ) {
                                Column {
                                    Text("✓ NAGAD PAYMENT APPROVED", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF047857)))
                                    Text("Wallet: ${nagadPhone.take(4)}***${nagadPhone.takeLast(4)}", style = TextStyle(fontSize = 9.sp, color = Slate700))
                                    Text("TxnID: $nagadGeneratedTxnId", style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Slate900))
                                }
                            }
                            
                            OutlinedButton(
                                onClick = {
                                    nagadStep = "input_number"
                                    nagadPhone = ""
                                    nagadOTP = ""
                                    nagadPIN = ""
                                },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Reset Wallet Form", style = TextStyle(fontSize = 10.sp))
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            val isExecutable = when (paymentMethod) {
                "Cash" -> isCashSufficient
                "Card" -> cardStep == "complete"
                "bKash" -> bKashStep == "complete"
                "Nagad" -> nagadStep == "complete"
                else -> false
            }
            Button(
                onClick = {
                    scope.launch {
                        // 1. Decrement SQLite and remote Firestore products
                        posCart.forEach { (prod, qty) ->
                            val currentStock = prod.stock
                            val nextStock = maxOf(0, currentStock - qty)
                            // saveProduct writes local Room and remote Firestore
                            viewModel.saveProduct(prod.copy(stock = nextStock))
                        }

                        // 2. Generate custom unique order ID
                        val orderIdString = "POS-" + java.util.UUID.randomUUID().toString().take(6).uppercase()

                        // 3. Serialize items json
                        val serializedParts = posCart.map { (prod, qty) ->
                            """{"id":${prod.id},"title":"${prod.title}","price":${prod.price},"quantity":$qty}"""
                        }
                        val itemsJson = "[" + serializedParts.joinToString(",") + "]"

                        // 4. Place order into DB
                        viewModel.placePOSOrder(
                            orderId = orderIdString,
                            total = grandTotal,
                            savings = discountAmount,
                            itemsJson = itemsJson,
                            onSuccess = {
                                Toast.makeText(context, "POS Register Transaction successful!", Toast.LENGTH_SHORT).show()
                                
                                val wallNum = when (paymentMethod) {
                                    "bKash" -> bKashPhone
                                    "Nagad" -> nagadPhone
                                    else -> ""
                                }
                                val txnIdVal = when (paymentMethod) {
                                    "bKash" -> bKashGeneratedTxnId
                                    "Nagad" -> nagadGeneratedTxnId
                                    "Card" -> "CARD-AUTH-${(100000..999999).random()}"
                                    else -> ""
                                }

                                val finalInfo = PosOrderInfo(
                                    orderId = orderIdString,
                                    items = posCart.toList(),
                                    subtotal = subtotal,
                                    discount = discountAmount,
                                    tax = taxAmount,
                                    grandTotal = grandTotal,
                                    paymentMethod = paymentMethod,
                                    amountPaid = totalAmountPaid,
                                    changeDue = changeDue,
                                    timestamp = System.currentTimeMillis(),
                                    walletNumber = wallNum,
                                    transactionId = txnIdVal
                                )
                                onCheckoutSuccess(finalInfo)
                            }
                        )
                    }
                },
                enabled = isExecutable,
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Compile & Print Receipt", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onDismiss,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Cancel", style = TextStyle(fontSize = 11.sp))
            }
        }
    )
}

@Composable
fun PosReceiptDialog(
    receipt: PosOrderInfo,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Transaction Receipt Printed", style = TextStyle(fontSize = 13.sp, fontWeight = FontWeight.Bold))
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // Real thermal style ticket
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFBFBF6)),
                    border = BorderStroke(1.dp, Slate200),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "FRESHMART SUPERMARKET",
                            style = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Slate900)
                        )
                        Text(
                            text = "100 Eastside Avenue, New York, NY",
                            style = TextStyle(fontSize = 9.sp, color = Color.Gray)
                        )
                        Text(
                            text = "Store Terminal: Register #04",
                            style = TextStyle(fontSize = 9.sp, color = Color.Gray)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = "--------------------------------------",
                            style = TextStyle(fontSize = 10.sp, color = Color.Gray)
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("TXN ID: ${receipt.orderId}", style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold))
                            val dateString = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(receipt.timestamp))
                            Text(text = dateString, style = TextStyle(fontSize = 9.sp, color = Color.Gray))
                        }

                        Text(
                            text = "--------------------------------------",
                            style = TextStyle(fontSize = 10.sp, color = Color.Gray)
                        )

                        // Line items rows
                        receipt.items.forEach { (item, qty) ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(text = item.title, style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold))
                                    Text(text = "$qty x \$${String.format(Locale.US, "%.2f", item.price)}", style = TextStyle(fontSize = 8.sp, color = Color.Gray))
                                }
                                Text(
                                    text = String.format(Locale.US, "$%.2f", item.price * qty),
                                    style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Slate900)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                        }

                        Text(
                            text = "--------------------------------------",
                            style = TextStyle(fontSize = 10.sp, color = Color.Gray)
                        )

                        // Invoice totals breakdown
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("SUBTOTAL", style = TextStyle(fontSize = 9.sp, color = Color.Gray))
                            Text(String.format(Locale.US, "$%.2f", receipt.subtotal), style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold))
                        }

                        if (receipt.discount > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("TOTAL SAVINGS / DISCOUNT", style = TextStyle(fontSize = 9.sp, color = RollbackRed))
                                Text(String.format(Locale.US, "-$%.2f", receipt.discount), style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = RollbackRed))
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("SALES TAX (7.5%)", style = TextStyle(fontSize = 9.sp, color = Color.Gray))
                            Text(String.format(Locale.US, "$%.2f", receipt.tax), style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold))
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("TOTAL PAID", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.ExtraBold))
                            Text(String.format(Locale.US, "$%.2f", receipt.grandTotal), style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Black, color = FreshMartBlue))
                        }

                        Text(
                            text = "--------------------------------------",
                            style = TextStyle(fontSize = 10.sp, color = Color.Gray)
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("PAYMENT METHOD", style = TextStyle(fontSize = 9.sp, color = Color.Gray))
                            Text(text = receipt.paymentMethod.uppercase(), style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold))
                        }

                        if (receipt.walletNumber.isNotEmpty()) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("WALLET NUMBER", style = TextStyle(fontSize = 9.sp, color = Color.Gray))
                                Text(text = receipt.walletNumber, style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold))
                            }
                        }

                        if (receipt.transactionId.isNotEmpty()) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("TRANSACTION ID", style = TextStyle(fontSize = 9.sp, color = Color.Gray))
                                Text(text = receipt.transactionId, style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold))
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("AMOUNT TENDERED", style = TextStyle(fontSize = 9.sp, color = Color.Gray))
                            Text(String.format(Locale.US, "$%.2f", receipt.amountPaid), style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold))
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("CHANGE BACK", style = TextStyle(fontSize = 9.sp, color = Color.Gray))
                            Text(String.format(Locale.US, "$%.2f", receipt.changeDue), style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981)))
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Receipt barcode image decoration
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(56.dp)
                                .background(Color.White)
                                .border(BorderStroke(1.dp, Slate200)),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                // Draw a series of black vertical stripes simulating barcode lines
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(1.dp),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                ) {
                                    val pattern = listOf(2, 1, 4, 2, 1, 3, 2, 4, 1, 2, 3, 1, 2, 4, 2, 1, 3, 1, 1, 4)
                                    pattern.forEach { width ->
                                        Box(
                                            modifier = Modifier
                                                .width(width.dp)
                                                .fillMaxHeight()
                                                .background(Color.Black)
                                        )
                                        Box(
                                            modifier = Modifier
                                                .width(1.dp)
                                                .fillMaxHeight()
                                                .background(Color.Transparent)
                                        )
                                    }
                                }
                                Text("TXN-${receipt.orderId}", style = TextStyle(fontSize = 8.sp, color = Color.Gray, fontWeight = FontWeight.Bold))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Thank you for shopping at Shohid Grocery!",
                            style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        )
                        Text(
                            text = "Have a wonderful day! Cashier: Admin #04",
                            style = TextStyle(fontSize = 8.sp, color = Color.Gray)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Confirm & Close Ledger")
            }
        }
    )
}

// ==========================================
// CUSTOMERS & SUPPLIERS FIRESTORE INTERFACES
// ==========================================

@Composable
fun CustomersListView(
    customers: List<Map<String, Any>>,
    onDeleteCustomer: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Registered Shohid Grocery Members",
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
            color = Slate900
        )
        Text(
            text = "These customers are connected live to your Firebase Firestore database.",
            fontSize = 12.sp,
            color = Slate600
        )

        if (customers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No registered members found. Register a customer via the member signup area in the shop!",
                    color = Color.Gray,
                    fontSize = 13.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            customers.forEach { cust ->
                val phone = cust["phone"]?.toString() ?: ""
                val name = cust["name"]?.toString() ?: "Guest Member"
                val registeredAt = cust["registeredAt"] as? Long ?: System.currentTimeMillis()
                val dateStr = java.text.SimpleDateFormat("MMM dd, yyyy - hh:mm a", java.util.Locale.getDefault()).format(java.util.Date(registeredAt))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Slate100)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Slate900)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = phone, fontSize = 12.sp, color = Slate600)
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.CalendarToday, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "Joined: $dateStr", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                        IconButton(
                            onClick = { onDeleteCustomer(phone) },
                            modifier = Modifier.testTag("delete_customer_$phone")
                        ) {
                            Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete Member", tint = Color.Red)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SuppliersManagerView(
    suppliers: List<Supplier>,
    onSaveSupplier: (Supplier) -> Unit,
    onDeleteSupplier: (String) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }
    var editingSupplier by remember { mutableStateOf<Supplier?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Partners & Suppliers Directory",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = Slate900
                )
                Text(
                    text = "Manage supply relations from Firestore.",
                    fontSize = 12.sp,
                    color = Slate600
                )
            }
            Button(
                onClick = { showAddDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                modifier = Modifier.testTag("add_supplier_button")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add Supplier", fontSize = 11.sp)
            }
        }

        if (suppliers.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No supplier listed. Add some fresh supplier routes!", color = Color.Gray, fontSize = 13.sp)
            }
        } else {
            suppliers.forEach { supp ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Slate100)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Top
                        ) {
                            Column {
                                Text(
                                    text = supp.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Slate900
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                SuggestionChip(
                                    onClick = {},
                                    label = { Text(supp.category, fontSize = 10.sp) },
                                    modifier = Modifier.height(24.dp)
                                )
                            }
                            Row {
                                IconButton(onClick = { editingSupplier = supp }) {
                                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit Supplier", tint = Slate700)
                                }
                                IconButton(onClick = { onDeleteSupplier(supp.id) }) {
                                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete Supplier", tint = Color.Red)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Divider(color = Slate100)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = supp.contact, fontSize = 11.sp, color = Slate600)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(imageVector = Icons.Default.Email, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = supp.email, fontSize = 10.sp, color = Slate600)
                                }
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.Top) {
                                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.Gray)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = supp.address, fontSize = 10.sp, color = Slate600, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AddEditSupplierDialog(
            supplier = null,
            onDismiss = { showAddDialog = false },
            onSave = {
                onSaveSupplier(it)
                showAddDialog = false
            }
        )
    }

    if (editingSupplier != null) {
        AddEditSupplierDialog(
            supplier = editingSupplier,
            onDismiss = { editingSupplier = null },
            onSave = {
                onSaveSupplier(it)
                editingSupplier = null
            }
        )
    }
}

@Composable
fun AddEditSupplierDialog(
    supplier: Supplier?,
    onDismiss: () -> Unit,
    onSave: (Supplier) -> Unit
) {
    val isEdit = supplier != null
    var name by remember { mutableStateOf(supplier?.name ?: "") }
    var contact by remember { mutableStateOf(supplier?.contact ?: "") }
    var email by remember { mutableStateOf(supplier?.email ?: "") }
    var category by remember { mutableStateOf(supplier?.category ?: "Fresh Produce") }
    var address by remember { mutableStateOf(supplier?.address ?: "") }

    val categories = listOf("Fresh Produce", "Dairy & Eggs", "Meat & Seafood", "Beverages", "Bakery & Sweets", "Dry Logistics", "Pantry Brands")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isEdit) "Edit Supplier Route" else "Add New Supplier Link", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Supplier Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = contact,
                    onValueChange = { contact = it },
                    label = { Text("Contact Number") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Supplier Category", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Slate700)
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    categories.forEach { cat ->
                        val selected = category == cat
                        SuggestionChip(
                            onClick = { category = cat },
                            label = { Text(cat, fontSize = 10.sp) },
                            border = if (selected) BorderStroke(2.dp, FreshMartBlue) else ButtonDefaults.outlinedButtonBorder
                        )
                    }
                }
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Fulfillment Warehouse Address") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 3
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotEmpty()) {
                        val finalId = supplier?.id ?: java.util.UUID.randomUUID().toString().take(6).uppercase()
                        onSave(
                            Supplier(
                                id = finalId,
                                name = name,
                                contact = contact,
                                email = email,
                                category = category,
                                address = address
                              )
                          )
                      }
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                  shape = RoundedCornerShape(8.dp)
              ) {
                  Text("Save Routing")
              }
          },
          dismissButton = {
              TextButton(onClick = onDismiss) {
                  Text("Cancel")
              }
          }
      )
}
