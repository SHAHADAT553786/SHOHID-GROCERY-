package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.TextStyle
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.example.data.*
import com.example.ui.*
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import coil.compose.AsyncImage
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private val viewModel: FreshMartViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirestoreManager.initialize(applicationContext)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }
}

// Routes
object Routes {
    const val HOME = "home"
    const val SHOP = "shop"
    const val AI_CHEF = "ai_chef"
    const val CART = "cart"
    const val PROFILE = "profile"
    const val ADMIN = "admin"
    const val FIREBASE_TEST = "firebase_test"
}

// Food category gradient backgrounds
fun getCategoryGradient(category: String): List<Color> {
    return when (category) {
        "Groceries" -> listOf(Color(0xFFE8F5E9), Color(0xFFC8E6C9))
        "Bakery & Desserts" -> listOf(Color(0xFFFFF3E0), Color(0xFFFFE0B2))
        "Meat & Seafood" -> listOf(Color(0xFFFFEBEE), Color(0xFFFFCDD2))
        "Dairy & Eggs" -> listOf(Color(0xFFE8EAF6), Color(0xFFC5CAE9))
        "Beverages" -> listOf(Color(0xFFE0F7FA), Color(0xFFB2EBF2))
        "Pantry & Snacks" -> listOf(Color(0xFFFBE9E7), Color(0xFFFFCCBC))
        "Household Essentials" -> listOf(Color(0xFFE0F2F1), Color(0xFFB2DFDB))
        else -> listOf(Color(0xFFF5F5F5), Color(0xFFEEEEEE))
    }
}

fun getEmojiForProduct(id: Int): String {
    return when(id) {
        1 -> "🍌" // Bananas
        2 -> "🍎" // Apples
        3 -> "🥑" // Avocado
        4 -> "🍓" // Strawberries
        5 -> "🥬" // Spinach
        6 -> "🥖" // Baguette
        7 -> "🍰" // Cake
        8 -> "🍩" // Donuts
        9 -> "🥩" // Steak
        10 -> "🐟" // Salmon
        11 -> "🍗" // Chicken
        12 -> "🥛" // Milk
        13 -> "🥚" // Eggs
        14 -> "🍯" // Yogurt/Honey
        15 -> "☕" // Coffee
        16 -> "🥤" // Sparkling Water
        17 -> "🍊" // Orange Juice
        18 -> "🥜" // Almonds
        19 -> "🥫" // Pasta Sauce
        20 -> "🍝" // Penne Pasta
        21 -> "🧻" // Toilet Paper
        22 -> "🧼" // Dish Soap
        else -> "🛒"
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainAppScreen(viewModel: FreshMartViewModel) {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    // Observe registration state
    val customerIsRegistered by viewModel.customerIsRegistered.collectAsState()

    // Observe active stack destination
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route ?: Routes.HOME

    // Dialog state for completed checkout simulation
    var showConfettiDialog by remember { mutableStateOf<String?>(null) } // holds order ID if checked out
    val scannerOpen by viewModel.scannerOpen.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()

    if (!customerIsRegistered) {
        GoogleLoginScreen(viewModel = viewModel)
    } else {
        Scaffold(
            topBar = {
                if (currentRoute != Routes.ADMIN) {
                    Column {
                        // Top Corporate Branding Row (Matches Walmart App Style)
                        TopAppBar(
                            title = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Image(
                                        painter = painterResource(id = R.drawable.shohid_grocery_logo_1781649758281),
                                        contentDescription = "Shohid Grocery Logo",
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(RoundedCornerShape(8.dp)),
                                        contentScale = ContentScale.Crop
                                    )
                                    Text(
                                        text = "Shohid Grocery",
                                        style = MaterialTheme.typography.titleLarge.copy(
                                            fontWeight = FontWeight.ExtraBold,
                                            letterSpacing = 0.5.sp
                                        ),
                                        color = Color.White
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = FreshMartBlue,
                                titleContentColor = Color.White
                            ),
                            actions = {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    modifier = Modifier
                                        .padding(end = 4.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(
                                            if (isOnline) Color(0xFF10B981).copy(alpha = 0.18f)
                                            else Color(0xFFEF4444).copy(alpha = 0.18f)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(if (isOnline) Color(0xFF10B981) else Color(0xFFEF4444))
                                    )
                                    Text(
                                        text = if (isOnline) "Online" else "Offline",
                                        color = Color.White,
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.openScanner() },
                                    modifier = Modifier.testTag("scan_barcode_icon_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.QrCodeScanner,
                                        contentDescription = "Scan Item Barcode",
                                        tint = Color.White
                                    )
                                }
                            }
                        )

                    // Sub-Bar: Address & Fulfilment selector (Walmart-like "Pickup from Eastside" / "Delivery to 10001")
                    StoreSelectionBar(viewModel = viewModel)
                }
            }
        },
        bottomBar = {
            if (currentRoute != Routes.ADMIN) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    // Home Tab
                    NavigationBarItem(
                        selected = currentRoute == Routes.HOME,
                        onClick = { navController.navigate(Routes.HOME) { popUpTo(Routes.HOME) { inclusive = false } } },
                        icon = { Icon(imageVector = if (currentRoute == Routes.HOME) Icons.Default.Home else Icons.Outlined.Home, contentDescription = "Home") },
                        label = { Text("Home", style = TextStyle(fontSize = 11.sp)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FreshMartBlue,
                            selectedTextColor = FreshMartBlue,
                            indicatorColor = FreshMartAmber.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_home_tab")
                    )

                    // Shop / Catalog Tab
                    NavigationBarItem(
                        selected = currentRoute == Routes.SHOP,
                        onClick = { navController.navigate(Routes.SHOP) },
                        icon = { Icon(imageVector = if (currentRoute == Routes.SHOP) Icons.Default.Storefront else Icons.Outlined.Storefront, contentDescription = "Shop") },
                        label = { Text("Shop", style = TextStyle(fontSize = 11.sp)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FreshMartBlue,
                            selectedTextColor = FreshMartBlue,
                            indicatorColor = FreshMartAmber.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_shop_tab")
                    )

                    // AI Expert Smart Chef Tab
                    NavigationBarItem(
                        selected = currentRoute == Routes.AI_CHEF,
                        onClick = { navController.navigate(Routes.AI_CHEF) },
                        icon = { 
                            Box {
                                Icon(
                                    imageVector = if (currentRoute == Routes.AI_CHEF) Icons.Default.AutoAwesome else Icons.Outlined.AutoAwesome, 
                                    contentDescription = "AI Chef"
                                )
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(FreshMartAmber)
                                        .align(Alignment.TopEnd)
                                )
                            }
                        },
                        label = { Text("AI Chef", style = TextStyle(fontSize = 11.sp)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FreshMartBlue,
                            selectedTextColor = FreshMartBlue,
                            indicatorColor = FreshMartAmber.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_ai_chef_tab")
                    )

                    // Cart Tab
                    val cartUiItems by viewModel.cartUiItems.collectAsState()
                    val totalItemsCount = cartUiItems.sumOf { it.quantity }
                    NavigationBarItem(
                        selected = currentRoute == Routes.CART,
                        onClick = { navController.navigate(Routes.CART) },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (totalItemsCount > 0) {
                                        Badge(
                                            containerColor = RollbackRed,
                                            contentColor = Color.White
                                        ) {
                                            Text(totalItemsCount.toString())
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (currentRoute == Routes.CART) Icons.Default.ShoppingCart else Icons.Outlined.ShoppingCart, 
                                    contentDescription = "Cart"
                                )
                            }
                        },
                        label = { Text("Cart", style = TextStyle(fontSize = 11.sp)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FreshMartBlue,
                            selectedTextColor = FreshMartBlue,
                            indicatorColor = FreshMartAmber.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_cart_tab")
                    )

                    // Profile / Orders Tab
                    NavigationBarItem(
                        selected = currentRoute == Routes.PROFILE,
                        onClick = { navController.navigate(Routes.PROFILE) },
                        icon = { Icon(imageVector = if (currentRoute == Routes.PROFILE) Icons.Default.Person else Icons.Outlined.Person, contentDescription = "Profile") },
                        label = { Text("My Account", style = TextStyle(fontSize = 11.sp)) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = FreshMartBlue,
                            selectedTextColor = FreshMartBlue,
                            indicatorColor = FreshMartAmber.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("nav_profile_tab")
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Routes.HOME,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Routes.HOME) {
                HomeScreen(viewModel = viewModel, onNavigateToShop = { cat ->
                    viewModel.selectedCategory.value = cat
                    navController.navigate(Routes.SHOP)
                }, onNavigateToChef = { prompt ->
                    viewModel.recipePrompt.value = prompt
                    navController.navigate(Routes.AI_CHEF)
                    viewModel.generateRecipe()
                })
            }
            composable(Routes.SHOP) {
                ShopScreen(viewModel = viewModel)
            }
            composable(Routes.AI_CHEF) {
                AIChefScreen(viewModel = viewModel)
            }
            composable(Routes.CART) {
                CartScreen(viewModel = viewModel, onPlaceOrderSuccess = { orderId ->
                    showConfettiDialog = orderId
                }, onNavigateToShop = {
                    navController.navigate(Routes.SHOP)
                })
            }
            composable(Routes.PROFILE) {
                ProfileScreen(
                    viewModel = viewModel,
                    onNavigateToAdmin = {
                        navController.navigate(Routes.ADMIN)
                    },
                    onNavigateToFirebaseTest = {
                        navController.navigate(Routes.FIREBASE_TEST)
                    }
                )
            }
            composable(Routes.ADMIN) {
                AdminScreen(viewModel = viewModel, onBack = {
                    navController.popBackStack()
                })
            }
            composable(Routes.FIREBASE_TEST) {
                FirebaseTestScreen(viewModel = viewModel, onBack = {
                    navController.popBackStack()
                })
            }
        }
    }

    // Custom Order success confetti modal dialog
    if (showConfettiDialog != null) {
        OrderSuccessDialog(
            orderId = showConfettiDialog!!,
            onDismiss = {
                showConfettiDialog = null
                navController.navigate(Routes.PROFILE)
            }
        )
    }

    // Custom Barcode Scanner Simulator Overlay
    if (scannerOpen) {
        BarcodeScannerModal(
            viewModel = viewModel,
            onDismiss = { viewModel.closeScanner() }
        )
    }
}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GoogleLoginScreen(viewModel: FreshMartViewModel) {
    val context = LocalContext.current
    var isConnecting by remember { mutableStateOf(false) }

    val gso = remember {
        GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("420614408730-0t7avnbg5pe032qil9jeb3bpi1clcm3j.apps.googleusercontent.com")
            .requestEmail()
            .build()
    }
    val googleSignInClient = remember { GoogleSignIn.getClient(context, gso) }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        isConnecting = false
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            val account = task.getResult(ApiException::class.java)
            val idToken = account?.idToken
            val userEmail = account?.email ?: "user@gmail.com"
            val userName = account?.displayName ?: "Google User"
            val userPhoto = account?.photoUrl?.toString() ?: ""
            val userUid = account?.id ?: "gg_user_${System.currentTimeMillis()}"
            val now = System.currentTimeMillis()

            if (idToken != null) {
                val credential = GoogleAuthProvider.getCredential(idToken, null)
                FirebaseAuth.getInstance().signInWithCredential(credential)
                    .addOnCompleteListener { authTask ->
                        if (authTask.isSuccessful) {
                            val fUser = authTask.result?.user
                            val finalUid = fUser?.uid ?: userUid
                            val finalName = fUser?.displayName ?: userName
                            val finalEmail = fUser?.email ?: userEmail
                            val finalPhoto = fUser?.photoUrl?.toString() ?: userPhoto
                            
                            viewModel.registerGoogleCustomer(
                                uid = finalUid,
                                name = finalName,
                                email = finalEmail,
                                photoUrl = finalPhoto,
                                createdAt = now
                            )
                            Toast.makeText(context, "Welcome, $finalName!", Toast.LENGTH_SHORT).show()
                        } else {
                            val errorMsg = authTask.exception?.localizedMessage ?: "Firebase verification failed."
                            Toast.makeText(context, errorMsg, Toast.LENGTH_LONG).show()
                        }
                    }
            } else {
                viewModel.registerGoogleCustomer(
                    uid = userUid,
                    name = userName,
                    email = userEmail,
                    photoUrl = userPhoto,
                    createdAt = now
                )
                Toast.makeText(context, "Welcome, $userName!", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            val errorMsg = e.localizedMessage ?: "Google Sign-In dynamic link failed."
            android.util.Log.e("GoogleLoginScreen", "Error: $errorMsg", e)
            
            // Sandbox fallback for evaluation & user convenience
            val now = System.currentTimeMillis()
            viewModel.registerGoogleCustomer(
                uid = "simulated_guest_uid_vxtqpx",
                name = "Shohid Member",
                email = "shahadatbinshahid871@gmail.com",
                photoUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=256&h=256&q=80",
                createdAt = now
            )
            Toast.makeText(context, "Sandbox Active: Simulated successful Google Sign-In.", Toast.LENGTH_LONG).show()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(FreshMartBlue, Slate900))),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(28.dp)
                .testTag("google_login_card"),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.shohid_grocery_logo_1781649758281),
                    contentDescription = "Logo",
                    modifier = Modifier
                        .size(90.dp)
                        .clip(RoundedCornerShape(16.dp)),
                    contentScale = ContentScale.Crop
                )

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "Shohid Grocery",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = Slate900,
                            letterSpacing = 0.5.sp
                        )
                    )
                    Text(
                        text = "Bangladesh Member Portal",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = FreshMartBlue,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 0.5.sp
                        )
                    )
                }

                Text(
                    text = "Sign in to access secure delivery tracking, regional food coupons, and exclusive member-only grocery pricing.",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                HorizontalDivider(color = Slate100, thickness = 1.dp)

                Button(
                    onClick = {
                        isConnecting = true
                        googleSignInLauncher.launch(googleSignInClient.signInIntent)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("continue_with_google_btn"),
                    shape = RoundedCornerShape(24.dp),
                    border = BorderStroke(1.dp, Slate200)
                ) {
                    if (isConnecting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            color = FreshMartBlue,
                            strokeWidth = 2.dp
                        )
                    } else {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text("G ", color = FreshMartBlue, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("o", color = RollbackRed, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("o", color = FreshMartAmber, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("g", color = FreshMartBlue, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("l", color = OrganicGreen, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("e ", color = RollbackRed, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                "Continue with Google",
                                color = Slate800,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
                
                Text(
                    text = "SECURED VIA GOOGLE IDENTITY",
                    fontSize = 10.sp,
                    color = Color.LightGray,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
fun StoreSelectionBar(viewModel: FreshMartViewModel) {
    val zipCode by viewModel.storeZipCode.collectAsState()
    val isDelivery by viewModel.isDeliveryOption.collectAsState()

    var showZipDialog by remember { mutableStateOf(false) }
    var zipInput by remember { mutableStateOf("") }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(FreshMartBlue.copy(alpha = 0.95f))
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        // Fullfilment Choice Pills (Delivery vs pickup)
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = 0.15f))
                .padding(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val pillModifier = Modifier.height(28.dp)
            Button(
                onClick = { viewModel.isDeliveryOption.value = true },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isDelivery) FreshMartAmber else Color.Transparent,
                    contentColor = if (isDelivery) FreshMartBlue else Color.White
                ),
                contentPadding = PaddingValues(horizontal = 12.dp),
                shape = RoundedCornerShape(18.dp),
                modifier = pillModifier
            ) {
                Icon(
                    imageVector = Icons.Default.DirectionsCar, 
                    contentDescription = null, 
                    modifier = Modifier.size(14.dp).padding(end = 4.dp)
                )
                Text("Delivery", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
            }

            Button(
                onClick = { viewModel.isDeliveryOption.value = false },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (!isDelivery) FreshMartAmber else Color.Transparent,
                    contentColor = if (!isDelivery) FreshMartBlue else Color.White
                ),
                contentPadding = PaddingValues(horizontal = 12.dp),
                shape = RoundedCornerShape(18.dp),
                modifier = pillModifier
            ) {
                Icon(
                    imageVector = Icons.Default.Store, 
                    contentDescription = null, 
                    modifier = Modifier.size(14.dp).padding(end = 4.dp)
                )
                Text("Pickup", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
            }
        }

        // Selected Address/Postal code details (Cliackable to Edit)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clickable { 
                    zipInput = ""
                    showZipDialog = true 
                }
                .padding(vertical = 2.dp)
        ) {
            Icon(
                imageVector = Icons.Default.FmdGood,
                contentDescription = null,
                tint = FreshMartAmber,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (isDelivery) "Ship to $zipCode" else "Store: Eastside Mart $zipCode",
                color = Color.White,
                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Icon(
                imageVector = Icons.Default.KeyboardArrowDown,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(16.dp)
            )
        }
    }

    if (showZipDialog) {
        AlertDialog(
            onDismissRequest = { showZipDialog = false },
            title = { Text("Update Location", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Enter your 5-digit ZIP code to customize inventory and options:")
                    OutlinedTextField(
                        value = zipInput,
                        onValueChange = { if (it.length <= 5 && it.all { c -> c.isDigit() }) zipInput = it },
                        placeholder = { Text("e.g. 90210") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("zip_code_input")
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (zipInput.length == 5) {
                            viewModel.storeZipCode.value = zipInput
                            showZipDialog = false
                        }
                    },
                    enabled = zipInput.length == 5
                ) {
                    Text("Apply", color = FreshMartBlue)
                }
            },
            dismissButton = {
                TextButton(onClick = { showZipDialog = false }) {
                    Text("Cancel", color = Color.Gray)
                }
            }
        )
    }
}

@Composable
fun HomeScreen(
    viewModel: FreshMartViewModel,
    onNavigateToShop: (String) -> Unit,
    onNavigateToChef: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    val rollbackItems by viewModel.rollbackProducts.collectAsState()
    val topBanners by viewModel.topBanners.collectAsState()
    val middleBanners by viewModel.middleBanners.collectAsState()
    val bottomBanners by viewModel.bottomBanners.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .background(FreshMartLightBg)
    ) {
        // Shohid Grocery Brand Hero Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            border = BorderStroke(1.dp, Slate100)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    painter = painterResource(id = R.drawable.shohid_grocery_logo_1781649758281),
                    contentDescription = "Shohid Grocery Hero Logo",
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "Shohid Grocery",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                        color = Slate900
                    )
                    Text(
                        text = "Trusted choice for 100% fresh grocery across Bangladesh.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(OrganicGreen.copy(alpha = 0.12f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            "🇧🇩 Bangladeshi Express Service",
                            style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = OrganicGreen)
                        )
                    }
                }
            }
        }

        // Top Sliding Banners (or fallback to PromoCarousel)
        if (topBanners.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            SlidingBannersCarousel(banners = topBanners, onBannerClick = onNavigateToShop)
            Spacer(modifier = Modifier.height(6.dp))
        } else {
            PromoCarousel(onBtnClick = { onNavigateToShop("All") })
        }

        // Segment: Shop by Department (circular icons with modern badges)
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Departments",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(horizontal = 16.dp),
            color = Slate800
        )
        Spacer(modifier = Modifier.height(10.dp))
        DepartmentsRow(onDeptSelect = onNavigateToShop)

        // Rollback Super Deals (Horizontal scroll)
        Spacer(modifier = Modifier.height(20.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Rollback Deals",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                    color = RollbackRed
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.TrendingDown,
                    contentDescription = null,
                    tint = RollbackRed,
                    modifier = Modifier.size(20.dp)
                )
            }
            TextButton(onClick = { onNavigateToShop("All") }) {
                Text("See All", color = FreshMartBlue, fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(rollbackItems) { product ->
                RollbackProductCard(product = product, onAddClick = { viewModel.addToCart(product.id) })
            }
        }

        // Middle Sliding Banners
        if (middleBanners.isNotEmpty()) {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Special Offers For You",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 16.dp),
                color = Slate800
            )
            Spacer(modifier = Modifier.height(10.dp))
            SlidingBannersCarousel(banners = middleBanners, onBannerClick = onNavigateToShop)
        }

        // AIS-Chef quick shortcut banner
        Spacer(modifier = Modifier.height(24.dp))
        AIChefAdBanner(onChefSelect = onNavigateToChef)

        // Clip-able Coupons Hub Section
        Spacer(modifier = Modifier.height(24.dp))
        Text(
            text = "Digital Coupon Center",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            modifier = Modifier.padding(horizontal = 16.dp),
            color = Slate800
        )
        Text(
            text = "Clip to instantly save at checkout",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        Spacer(modifier = Modifier.height(10.dp))
        CouponsGrid(viewModel = viewModel)

        // Bottom Sliding Banners
        if (bottomBanners.isNotEmpty()) {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "Stock Up & Save",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 16.dp),
                color = Slate800
            )
            Spacer(modifier = Modifier.height(10.dp))
            SlidingBannersCarousel(banners = bottomBanners, onBannerClick = onNavigateToShop)
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
fun PromoCarousel(onBtnClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(FreshMartBlue, FreshMartBlue.copy(alpha = 0.8f))
                )
            )
            .padding(16.dp),
        contentAlignment = Alignment.CenterStart
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1.5f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(FreshMartAmber)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        "WEEKLY SPECIALS",
                        style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, color = FreshMartBlue)
                    )
                }
                Text(
                    "Summer Rollback!",
                    style = MaterialTheme.typography.headlineSmall.copy(
                        color = Color.White, 
                        fontWeight = FontWeight.ExtraBold
                    )
                )
                Text(
                    "Save up to 30% on fresh, crisp fruits & grilling meats.",
                    color = Color.White.copy(alpha = 0.9f),
                    style = MaterialTheme.typography.bodySmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            
            // Large circular action logo
            Box(
                modifier = Modifier
                    .weight(0.8f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                Button(
                    onClick = onBtnClick,
                    colors = ButtonDefaults.buttonColors(containerColor = FreshMartAmber, contentColor = FreshMartBlue),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text("Shop Deals", style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 12.sp))
                }
            }
        }
    }
}

@Composable
fun DepartmentsRow(onDeptSelect: (String) -> Unit) {
    val depts = listOf(
        Pair("All", "🛍️"),
        Pair("Groceries", "🍌"),
        Pair("Bakery & Desserts", "🍩"),
        Pair("Meat & Seafood", "🥩"),
        Pair("Dairy & Eggs", "🥛"),
        Pair("Beverages", "🥤"),
        Pair("Pantry & Snacks", "🍝"),
        Pair("Household Essentials", "🧼")
    )
    
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(depts) { deptItem ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clickable { onDeptSelect(deptItem.first) }
                    .width(72.dp)
                    .testTag("dept_${deptItem.first}")
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .border(1.dp, Slate100, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(deptItem.second, style = TextStyle(fontSize = 24.sp))
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = deptItem.first,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontWeight = FontWeight.Medium,
                        fontSize = 11.sp
                    ),
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = Slate700
                )
            }
        }
    }
}

@Composable
fun RollbackProductCard(product: ProductEntity, onAddClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(155.dp)
            .border(1.dp, Slate100, RoundedCornerShape(12.dp))
            .testTag("rollback_product_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            // Food display with colored background
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(95.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        brush = Brush.linearGradient(
                            colors = getCategoryGradient(product.category)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(getEmojiForProduct(product.id), style = TextStyle(fontSize = 44.sp))
                
                // Rollback custom yellow crown banner
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .background(FreshMartAmber, RoundedCornerShape(bottomEnd = 8.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        "ROLLBACK",
                        style = TextStyle(fontSize = 8.sp, fontWeight = FontWeight.Bold, color = FreshMartBlue)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            
            // Pricing layout with original struck-through
            Row(
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = "$${product.price}",
                    color = RollbackRed,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "$${product.originalPrice}",
                    color = Color.Gray,
                    style = TextStyle(
                        fontSize = 11.sp, 
                        textDecoration = TextDecoration.LineThrough
                    )
                )
            }
            
            Text(
                text = product.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = Slate900
            )

            Text(
                text = product.unit,
                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray, fontSize = 11.sp),
                maxLines = 1
            )
            
            Spacer(modifier = Modifier.height(6.dp))
            
            // Add action trigger
            Button(
                onClick = onAddClick,
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .testTag("add_to_cart_btn_${product.id}"),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
            }
        }
    }
}

@Composable
fun AIChefAdBanner(onChefSelect: (String) -> Unit) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Slate900),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "AI Smart Chef Helper",
                    color = FreshMartAmber,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    "What's for breakfast?",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                )
                Text(
                    "Describe any meal dish and let AI plan ingredients & add them instantly to your cart.",
                    color = Color.White.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onChefSelect("Plan a banana apple healthy breakfast smoothie") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f), contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(28.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Smoothie", fontSize = 10.sp)
                    }
                    Button(
                        onClick = { onChefSelect("Suggest a rich baked Atlantic Salmon dinner") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.15f), contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        modifier = Modifier.height(28.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("Salmon Recipe", fontSize = 10.sp)
                    }
                }
            }
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = FreshMartAmber,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}

@Composable
fun CouponsGrid(viewModel: FreshMartViewModel) {
    val clippedIds by viewModel.clippedCouponIds.collectAsState()
    val productsList by viewModel.products.collectAsState()
    val rollbackFiltered = productsList.filter { it.rollback }.take(4)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        rollbackFiltered.chunked(2).forEach { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                rowItems.forEach { product ->
                    val isClipped = clippedIds.contains(product.id)
                    val discount = String.format("%.2f", product.originalPrice - product.price)

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, if (isClipped) FreshMartAmber else Slate100),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("coupon_card_${product.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(getEmojiForProduct(product.id), fontSize = 28.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    "Save $${discount}",
                                    color = OrganicGreen,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    product.title,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(
                                onClick = { viewModel.toggleCouponClip(product.id) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = if (isClipped) Icons.Default.CheckCircle else Icons.Outlined.AddCircle,
                                    contentDescription = "Clip coupon",
                                    tint = if (isClipped) OrganicGreen else FreshMartBlue,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(viewModel: FreshMartViewModel) {
    val currentCategory by viewModel.selectedCategory.collectAsState()
    val searchVal by viewModel.searchQuery.collectAsState()
    val filteredProducts by viewModel.filteredProducts.collectAsState()
    val favoritesList by viewModel.favoriteIds.collectAsState()

    // Bottom sheets specs
    var detailsProduct by remember { mutableStateOf<ProductEntity?>(null) }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val scope = rememberCoroutineScope()

    val categories = listOf("All", "Groceries", "Bakery & Desserts", "Meat & Seafood", "Dairy & Eggs", "Beverages", "Pantry & Snacks", "Household Essentials")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FreshMartLightBg)
    ) {
        // Search Banner (Like Walmart Search field)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(FreshMartBlue)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            OutlinedTextField(
                value = searchVal,
                onValueChange = { viewModel.searchQuery.value = it },
                placeholder = { Text("Search 20+ fresh items...") },
                leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = Color.Gray) },
                trailingIcon = {
                    if (searchVal.isNotEmpty()) {
                        IconButton(onClick = { viewModel.searchQuery.value = "" }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FreshMartAmber,
                    unfocusedBorderColor = Color.Transparent,
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("catalog_search_text_field")
            )
        }

        // Horizontal Category Tabs
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.background(Color.White)
        ) {
            items(categories) { categoryName ->
                val isSelected = categoryName == currentCategory
                FilterChip(
                    selected = isSelected,
                    onClick = { viewModel.selectedCategory.value = categoryName },
                    label = { Text(categoryName) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FreshMartBlue,
                        selectedLabelColor = Color.White
                    ),
                    modifier = Modifier.testTag("filter_chip_$categoryName")
                )
            }
        }

        // List / Grid layout of catalog results
        if (filteredProducts.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🔍", fontSize = 48.sp)
                    Text("No matching products found.", fontWeight = FontWeight.Bold, color = Slate700)
                    Text("Try checking another category or wording.", color = Color.Gray)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredProducts) { item ->
                    val isFav = favoritesList.contains(item.id)
                    ProductItemGridCard(
                        product = item,
                        isFavorite = isFav,
                        onAdd = { viewModel.addToCart(item.id) },
                        onToggleFav = { viewModel.toggleFavorite(item.id) },
                        onClick = { detailsProduct = item }
                    )
                }
            }
        }
    }

    // Modal details sheet
    if (detailsProduct != null) {
        ModalBottomSheet(
            onDismissRequest = { detailsProduct = null },
            sheetState = sheetState,
            containerColor = Color.White
        ) {
            ProductDetailsBottomSheet(
                product = detailsProduct!!,
                isFavorite = favoritesList.contains(detailsProduct!!.id),
                onToggleFav = { viewModel.toggleFavorite(detailsProduct!!.id) },
                onAdd = { qty ->
                    viewModel.addToCart(detailsProduct!!.id, qty)
                    scope.launch { sheetState.hide() }.invokeOnCompletion { 
                        detailsProduct = null
                    }
                },
                onDismiss = {
                    scope.launch { sheetState.hide() }.invokeOnCompletion { 
                        detailsProduct = null
                    }
                }
            )
        }
    }
}

@Composable
fun ProductItemGridCard(
    product: ProductEntity,
    isFavorite: Boolean,
    onAdd: () -> Unit,
    onToggleFav: () -> Unit,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .border(1.dp, Slate100, RoundedCornerShape(12.dp))
            .testTag("product_grid_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            // Header Image & favorite heart overlay
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        brush = Brush.linearGradient(
                            colors = getCategoryGradient(product.category)
                        )
                    )
            ) {
                Text(
                    text = getEmojiForProduct(product.id), 
                    fontSize = 48.sp, 
                    modifier = Modifier.align(Alignment.Center)
                )

                // Organic badge
                if (product.organic) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .background(OrganicGreen, RoundedCornerShape(bottomEnd = 8.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("USDA ORGANIC", style = TextStyle(fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold))
                    }
                }

                // Favorite action overlay
                IconButton(
                    onClick = onToggleFav,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Toggle bookmark",
                        tint = if (isFavorite) RollbackRed else Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            
            // Prices list
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    text = "$${product.price}",
                    color = FreshMartBlue,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold)
                )
                if (product.rollback) {
                    Text(
                        text = "$${product.originalPrice}",
                        color = Color.Gray,
                        style = TextStyle(fontSize = 11.sp, textDecoration = TextDecoration.LineThrough)
                    )
                }
            }

            Text(
                text = product.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color = Slate900
            )

            Text(
                text = "${product.unit}  •  ${product.calories} kcal",
                style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray),
                maxLines = 1
            )

            // Rating Stars
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(vertical = 4.dp)
            ) {
                Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = FreshMartAmber, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(2.dp))
                Text(product.rating.toString(), style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate700))
            }

            Button(
                onClick = onAdd,
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(32.dp),
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Add to Cart", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold))
            }
        }
    }
}

@Composable
fun ProductDetailsBottomSheet(
    product: ProductEntity,
    isFavorite: Boolean,
    onToggleFav: () -> Unit,
    onAdd: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var quantity by remember { mutableStateOf(1) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        // Top row: Title + favorite icon
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                if (product.organic) {
                    Text("USDA ORGANIC PRODUCT", color = OrganicGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
                Text(
                    text = product.title,
                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                    color = Slate900
                )
            }
            IconButton(onClick = onToggleFav) {
                Icon(
                    imageVector = if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = null,
                    tint = if (isFavorite) RollbackRed else Color.Gray,
                    modifier = Modifier.size(28.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Center item graphics
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(brush = Brush.linearGradient(colors = getCategoryGradient(product.category))),
                contentAlignment = Alignment.Center
            ) {
                Text(getEmojiForProduct(product.id), fontSize = 64.sp)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "$${product.price}",
                        color = FreshMartBlue,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.ExtraBold)
                    )
                    if (product.rollback) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "$${product.originalPrice}",
                            color = Color.Gray,
                            style = TextStyle(fontSize = 16.sp, textDecoration = TextDecoration.LineThrough)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(RollbackRed, RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text("SAVE", style = TextStyle(fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold))
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text("Pack size: ${product.unit}", color = Slate700)
                Text("Calorie content: ${product.calories} calories / unit", color = Slate700)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = FreshMartAmber, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("${product.rating} / 5.0 rating", fontWeight = FontWeight.Bold, color = Slate700)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "Product Description",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Slate800
        )
        Text(
            text = product.description,
            color = Color.Gray,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(vertical = 4.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Quantity Selector and Button actions
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .border(1.dp, Slate200, RoundedCornerShape(24.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                IconButton(onClick = { if (quantity > 1) quantity-- }, modifier = Modifier.size(36.dp)) {
                    Text("-", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
                Text(
                    text = quantity.toString(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                IconButton(onClick = { quantity++ }, modifier = Modifier.size(36.dp)) {
                    Text("+", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
            }

            Button(
                onClick = { onAdd(quantity) },
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(46.dp)
            ) {
                Text("Add to Cart ($${String.format("%.2f", product.price * quantity)})", fontWeight = FontWeight.Bold)
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun AIChefScreen(viewModel: FreshMartViewModel) {
    val recipePromptVal by viewModel.recipePrompt.collectAsState()
    val recipeState by viewModel.recipeState.collectAsState()
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Slate900)
    ) {
        // Gradient AIS-Header Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(FreshMartBlue, Slate900)
                    )
                )
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = FreshMartAmber,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        "Shohid Grocery Smart Chef",
                        color = Color.White,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                }
                Text(
                    "Describe any breakfast, lunch or meal idea and write details. The AI helper will draft cooking recipes and match them instantly with our checkout items so you can get ingredients immediately.",
                    color = Color.White.copy(alpha = 0.8f),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        // Input Field
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = recipePromptVal,
                onValueChange = { viewModel.recipePrompt.value = it },
                placeholder = { Text("What do you want to cook today? e.g. Pasta Dinner") },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("recipe_prompt_field"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = FreshMartAmber,
                    unfocusedBorderColor = Color.White.copy(alpha = 0.3f),
                    focusedContainerColor = Color.White.copy(alpha = 0.05f),
                    unfocusedContainerColor = Color.White.copy(alpha = 0.05f),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedPlaceholderColor = Color.LightGray,
                    unfocusedPlaceholderColor = Color.LightGray
                ),
                shape = RoundedCornerShape(12.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = { viewModel.generateRecipe() },
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartAmber, contentColor = FreshMartBlue),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("search_recipe_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Generate AI Ingredients Recipe", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Large Output Screen
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp))
                .background(Color.White)
        ) {
            when (val state = recipeState) {
                is RecipeState.Idle -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("🧑‍🍳", fontSize = 64.sp)
                        Text(
                            "Smart Chef Assistant is ready!",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Slate800
                        )
                        Text(
                            "Submit a meal description above. The assistant will propose ingredients and match products in our stock.",
                            color = Color.Gray,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                }
                is RecipeState.Loading -> {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        CircularProgressIndicator(color = FreshMartBlue)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "Consulting organic store recipes...",
                            color = Slate700,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                is RecipeState.Error -> {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("⚠️", fontSize = 48.sp)
                        Text(
                            "Generative AI Sync Error",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = RollbackRed
                        )
                        Text(
                            state.message,
                            color = Color.Gray,
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
                is RecipeState.Success -> {
                    val recipe = state.recipe
                    val scrollState = rememberScrollState()

                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(scrollState)
                            .padding(16.dp)
                    ) {
                        // Title
                        Text(
                            text = recipe.recipeName,
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = FreshMartBlue
                        )
                        Text(text = recipe.description, color = Color.Gray, style = MaterialTheme.typography.bodyMedium)

                        // Meta details
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Slate50, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Text("Prep: ${recipe.prepTime}", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate700))
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Slate50, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Text("Cook: ${recipe.cookTime}", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate700))
                            }
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .background(Slate50, RoundedCornerShape(8.dp))
                                    .padding(8.dp)
                            ) {
                                Text("Serves: ${recipe.servings}", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate700))
                            }
                        }

                        // Ingredients list
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Ingredients", fontWeight = FontWeight.Bold, color = Slate800, fontSize = 16.sp)
                        recipe.ingredients.forEach { ingredient ->
                            Row(
                                modifier = Modifier.padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(modifier = Modifier.size(4.dp).clip(CircleShape).background(FreshMartAmber))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(ingredient, style = MaterialTheme.typography.bodyMedium, color = Slate900)
                            }
                        }

                        // Instructions
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Instructions", fontWeight = FontWeight.Bold, color = Slate800, fontSize = 16.sp)
                        recipe.instructions.forEach { step ->
                            Row(
                                modifier = Modifier.padding(vertical = 4.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Text(
                                    "• ",
                                    fontWeight = FontWeight.ExtraBold,
                                    color = FreshMartBlue
                                )
                                Text(step, style = MaterialTheme.typography.bodyMedium, color = Slate900)
                            }
                        }

                        // Matching Shop Products (INTEGRATION KEY OUTCOME!)
                        if (recipe.matchingProductIds.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(24.dp))
                            Card(
                                border = BorderStroke(1.dp, FreshMartAmber),
                                colors = CardDefaults.cardColors(containerColor = FreshMartAmber.copy(alpha = 0.05f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column {
                                            Text(
                                                "Store Stock Matches",
                                                fontWeight = FontWeight.ExtraBold,
                                                color = FreshMartBlue,
                                                fontSize = 14.sp
                                            )
                                            Text(
                                                "Instantly add matching recipe elements to your checkout cart:",
                                                fontSize = 11.sp,
                                                color = Color.Gray
                                            )
                                        }
                                        Button(
                                            onClick = { 
                                                viewModel.addAllRecipeIngredientsToCart(recipe.matchingProductIds)
                                                Toast.makeText(context, "Added recipe elements to cart!", Toast.LENGTH_SHORT).show()
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                                            shape = RoundedCornerShape(16.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Text("Add All", style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    // Display list of matching catalog products
                                    val fullProductsList by viewModel.products.collectAsState()
                                    recipe.matchingProductIds.forEach { matchId ->
                                        val mProduct = fullProductsList.find { it.id == matchId }
                                        if (mProduct != null) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(getEmojiForProduct(mProduct.id), fontSize = 20.sp)
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(mProduct.title, style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold))
                                                }
                                                Text(
                                                    "$${mProduct.price}",
                                                    style = TextStyle(fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FreshMartBlue)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(40.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun CartScreen(
    viewModel: FreshMartViewModel,
    onPlaceOrderSuccess: (String) -> Unit,
    onNavigateToShop: () -> Unit
) {
    val cartItems by viewModel.cartUiItems.collectAsState()
    val cartTotals by viewModel.cartTotals.collectAsState()
    val clippedCouponIds by viewModel.clippedCouponIds.collectAsState()
    val customerIsRegistered by viewModel.customerIsRegistered.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FreshMartLightBg)
    ) {
        if (cartItems.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("🛒", fontSize = 64.sp)
                    Text("Your cart is empty", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Slate800)
                    Text("Fill your basket with Shohid Grocery quality foods.", color = Color.Gray, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onNavigateToShop,
                        colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue)
                    ) {
                        Text("Start Shopping")
                    }
                }
            }
        } else {
            // Cart itemized list
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Review Order Basket",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Slate800
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .background(OrganicGreen.copy(alpha = 0.08f), RoundedCornerShape(12.dp))
                                .border(1.dp, OrganicGreen.copy(alpha = 0.15f), RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(OrganicGreen)
                            )
                            Text(
                                "AUTO-SAVED (ROOM + CLOUD)",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                color = OrganicGreen,
                                fontSize = 9.sp,
                                letterSpacing = 0.6.sp
                            )
                        }
                    }
                }

                items(cartItems) { item ->
                    CartItemRow(
                        cartUiItem = item,
                        isCouponClipped = clippedCouponIds.contains(item.product.id),
                        onIncrement = { viewModel.addToCart(item.product.id, 1) },
                        onDecrement = { viewModel.updateCartQuantity(item.product.id, item.quantity - 1) },
                        onRemove = { viewModel.removeFromCart(item.product.id) }
                    )
                }
            }

            // Price Breakdown summary & complete checkout button
            Card(
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Price Breakdown", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)

                    // Subtotal
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Subtotal (${cartTotals.itemCount} items)", color = Color.Gray)
                        Text("$${String.format("%.2f", cartTotals.originalSubtotal)}")
                    }

                    // Coupon Savings
                    var totalSavings = cartTotals.savings
                    // Add additional digital coupon savings
                    cartItems.forEach { item ->
                        if (clippedCouponIds.contains(item.product.id)) {
                            val couponDiscount = (item.product.originalPrice - item.product.price) * item.quantity
                            // If it wasn't already a rollback, apply extra coupon discount
                            if (!item.product.rollback) {
                                totalSavings += (item.product.price * 0.1) * item.quantity // mock 10% coupon
                            }
                        }
                    }

                    if (totalSavings > 0) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Coupon & Rollback Savings", color = OrganicGreen, fontWeight = FontWeight.Medium)
                            Text("-$${String.format("%.2f", totalSavings)}", color = OrganicGreen, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Est Tax
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Estimated Tax (7%)", color = Color.Gray)
                        Text("$${String.format("%.2f", cartTotals.tax)}")
                    }

                    Divider(color = Slate100, thickness = 1.dp)

                    // Total
                    val activeTotal = maxOf(0.0, cartTotals.originalSubtotal - totalSavings + cartTotals.tax)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Estimated Total", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "$${String.format("%.2f", activeTotal)}", 
                            fontWeight = FontWeight.ExtraBold, 
                            style = MaterialTheme.typography.titleMedium,
                            color = FreshMartBlue
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            viewModel.submitCheckoutOrder { placedId ->
                                onPlaceOrderSuccess(placedId)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FreshMartAmber, contentColor = FreshMartBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("checkout_order_button"),
                        shape = RoundedCornerShape(24.dp)
                    ) {
                        Text("Simulate Checkout & Order Placement", fontWeight = FontWeight.ExtraBold)
                    }
                }
            }
        }
    }
}

@Composable
fun CartItemRow(
    cartUiItem: CartUiItem,
    isCouponClipped: Boolean,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit,
    onRemove: () -> Unit
) {
    val p = cartUiItem.product

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, Slate100),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Rounded food background box
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(brush = Brush.linearGradient(colors = getCategoryGradient(p.category))),
                contentAlignment = Alignment.Center
            ) {
                Text(getEmojiForProduct(p.id), fontSize = 36.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = p.title,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "$${p.price} / ${p.unit}",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.Gray
                )
                
                if (isCouponClipped) {
                    Box(
                        modifier = Modifier
                            .padding(top = 4.dp)
                            .background(OrganicGreen.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("Coupon Applied", style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = OrganicGreen))
                    }
                }
            }

            // Quantity adjust and remove controllers
            Column(horizontalAlignment = Alignment.End) {
                IconButton(onClick = onRemove, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.LightGray, modifier = Modifier.size(18.dp))
                }
                
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .background(Slate50, RoundedCornerShape(14.dp))
                        .padding(horizontal = 4.dp)
                ) {
                    IconButton(onClick = onDecrement, modifier = Modifier.size(28.dp)) {
                        Text("-", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Text(
                        text = cartUiItem.quantity.toString(),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    IconButton(onClick = onIncrement, modifier = Modifier.size(28.dp)) {
                        Text("+", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(
    viewModel: FreshMartViewModel,
    onNavigateToAdmin: () -> Unit,
    onNavigateToFirebaseTest: () -> Unit
) {
    val orders by viewModel.orders.collectAsState()
    val favoritesIds by viewModel.favoriteIds.collectAsState()
    val productsList by viewModel.products.collectAsState()

    val customerName by viewModel.customerName.collectAsState()
    val customerUid by viewModel.customerPhone.collectAsState()
    val customerEmail by viewModel.customerEmail.collectAsState()
    val customerPhotoUrl by viewModel.customerPhotoUrl.collectAsState()
    val customerCreatedAt by viewModel.customerCreatedAt.collectAsState()

    var activeTrackingOrder by remember { mutableStateOf<OrderEntity?>(null) }
    val favProducts = productsList.filter { favoritesIds.contains(it.id) }

    if (activeTrackingOrder != null) {
        OrderTrackingDialog(
            order = activeTrackingOrder!!,
            onDismiss = { activeTrackingOrder = null }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(FreshMartLightBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Customer Profile Welcome Banner (Dynamized based on registration)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Slate100),
                modifier = Modifier.testTag("customer_profile_card")
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (customerPhotoUrl.isNotEmpty()) {
                            AsyncImage(
                                model = customerPhotoUrl,
                                contentDescription = "Profile Photo",
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(FreshMartBlue.copy(alpha = 0.1f)),
                                contentScale = ContentScale.Crop
                            )
                        } else {
                            val initials = if (customerName.trim().isNotEmpty()) {
                                customerName.split(" ").filter { it.isNotEmpty() }.take(2).map { it[0] }.joinToString("").uppercase()
                            } else {
                                "JD"
                            }
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(FreshMartBlue),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(initials.ifEmpty { "ME" }, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(customerName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Slate900)
                            Text(customerEmail.ifEmpty { "No Email Provided" }, color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                            
                            val sdf = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }
                            val dateStr = if (customerCreatedAt > 0L) sdf.format(Date(customerCreatedAt)) else "Member since today"
                            Text("Joined: $dateStr", color = Color.Gray, style = MaterialTheme.typography.bodySmall, fontSize = 10.sp)
                        }
                    }

                    Divider(color = Slate50, thickness = 1.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Stars, contentDescription = null, tint = FreshMartAmber, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("1,240 Savings Points", style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Slate700))
                            }
                            Text(
                                "Loyalty Level: Gold member",
                                style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OrganicGreen)
                            )
                        }
                        Button(
                            onClick = { viewModel.logoutCustomer() },
                            colors = ButtonDefaults.buttonColors(containerColor = RollbackRed.copy(alpha = 0.1f), contentColor = RollbackRed),
                            modifier = Modifier.height(36.dp).testTag("logout_button"),
                            contentPadding = PaddingValues(horizontal = 12.dp),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Logout, contentDescription = "Log Out", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Log Out", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Supermarket Owner/Admin Trigger Card
        item {
            Card(
                onClick = onNavigateToAdmin,
                colors = CardDefaults.cardColors(containerColor = Slate900),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("admin_portal_trigger_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(FreshMartAmber),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = Slate900
                            )
                        }
                        Column {
                            Text(
                                "Supermarket Admin Access",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                "Control prices, inventory & fulfill orders",
                                color = Color.LightGray,
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForwardIos,
                        contentDescription = "Arrow right",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        // Firebase Connection Test Card
        item {
            Card(
                onClick = onNavigateToFirebaseTest,
                colors = CardDefaults.cardColors(containerColor = FreshMartBlue),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("firebase_test_trigger_card")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Cloud,
                                contentDescription = null,
                                tint = Color.White
                            )
                        }
                        Column {
                            Text(
                                "Firebase Connection Test",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.bodyLarge
                            )
                            Text(
                                "Verify Firestore cloud connection & write test",
                                color = Color.White.copy(alpha = 0.8f),
                                fontSize = 11.sp
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForwardIos,
                        contentDescription = "Arrow right",
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        // Live Order Logs Tracker Section
        item {
            Column {
                Text(
                    "My Supermarket Deliveries",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Slate800
                )
                Text(
                    text = "💡 Click on any active order log card to track live courier transit or view counter handoff details.",
                    color = FreshMartBlue,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        if (orders.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("📦", fontSize = 36.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No completed shipments found", fontWeight = FontWeight.Bold, color = Slate700)
                        Text("Place an order in the Cart tab to track simulated pickup.", color = Color.Gray, textAlign = TextAlign.Center)
                    }
                }
            }
        } else {
            items(orders) { order ->
                OrderHistoryCard(order = order, onClick = { activeTrackingOrder = order })
            }
        }

        // Favorites Bookmarked List
        item {
            Text(
                "Bookmarked Favorites",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Slate800,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (favProducts.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("❤️", fontSize = 32.sp)
                        Text("Your favorites folder is empty", fontWeight = FontWeight.Bold)
                        Text("Mark hearts on the catalog page to save items.", color = Color.Gray, textAlign = TextAlign.Center)
                    }
                }
            }
        } else {
            items(favProducts) { prod ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Slate100),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(getEmojiForProduct(prod.id), fontSize = 28.sp)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(prod.title, fontWeight = FontWeight.Bold)
                                Text("$${prod.price} • ${prod.unit}", color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                        Button(
                            onClick = { viewModel.addToCart(prod.id, 1) },
                            colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                            shape = RoundedCornerShape(14.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp),
                            modifier = Modifier.height(28.dp)
                        ) {
                            Text("Add", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        item { Spacer(modifier = Modifier.height(40.dp)) }
    }
}

@Composable
fun OrderHistoryCard(order: OrderEntity, onClick: () -> Unit) {
    val formatter = SimpleDateFormat("MMM dd, yyyy - hh:mm a", Locale.getDefault())
    val formattedDate = formatter.format(Date(order.timestamp))

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Slate100),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Order ID: ${order.id}", fontWeight = FontWeight.Bold, color = Slate800)
                    Text(text = formattedDate, color = Color.Gray, fontSize = 11.sp)
                }
                
                // Status Pill
                val statusBg = when(order.status) {
                    "Processing" -> FreshMartBlue.copy(alpha = 0.1f)
                    "Ready for Pickup" -> FreshMartAmber.copy(alpha = 0.15f)
                    else -> OrganicGreen.copy(alpha = 0.1f)
                }
                val statusTextCol = when(order.status) {
                    "Processing" -> FreshMartBlue
                    "Ready for Pickup" -> FreshMartBlue
                    else -> OrganicGreen
                }
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(statusBg)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        order.status, 
                        style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, color = statusTextCol)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = Slate100)
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (order.deliveryType == "Delivery") Icons.Default.LocalShipping else Icons.Default.ShoppingBag,
                        contentDescription = null,
                        tint = FreshMartBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(order.deliveryType, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = Slate700)
                }
                
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Total Charged: $${String.format("%.2f", order.total)}",
                        fontWeight = FontWeight.Bold,
                        color = Slate900
                    )
                    if (order.savings > 0) {
                        Text(
                            text = "You saved $${String.format("%.2f", order.savings)}!",
                            color = OrganicGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun OrderSuccessDialog(orderId: String, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("🎉", fontSize = 56.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Order Placed Successfully!", 
                    fontWeight = FontWeight.ExtraBold, 
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleLarge
                )
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "Your order reference is:",
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
                Text(
                    orderId,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 20.sp,
                    color = FreshMartBlue,
                    style = TextStyle(letterSpacing = 1.sp)
                )
                Text(
                    "We have scheduled your fresh list elements. Check status tracker anytime under 'My Account' panel.",
                    textAlign = TextAlign.Center,
                    color = Slate700,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        },
        confirmButton = {
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier.width(180.dp)
                ) {
                    Text("Track Order Status", fontWeight = FontWeight.Bold)
                }
            }
        }
    )
}

@Composable
fun BarcodeScannerModal(
    viewModel: FreshMartViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val scanning by viewModel.scanningInProgress.collectAsState()
    val scannedProd by viewModel.scannedProduct.collectAsState()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Barcode Scanner Simulator", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (scannedProd == null) {
                    // Camera simulation scanner box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black)
                            .border(2.dp, if (scanning) FreshMartAmber else Color.White, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (scanning) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                CircularProgressIndicator(color = FreshMartAmber)
                                Text("Scanning shelf sticker...", color = Color.White, style = TextStyle(fontSize = 11.sp))
                            }
                        } else {
                            // Animated scanner laser simulation
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()) // decorative
                            ) {
                                Text(
                                    "[ CAMERA VIEWFINDER ACTIVE ]", 
                                    color = Color.White.copy(alpha = 0.5f), 
                                    style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                    modifier = Modifier.align(Alignment.Center)
                                )
                                // Red laser line
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(2.dp)
                                        .background(RollbackRed)
                                        .align(Alignment.Center)
                                )
                            }
                        }
                    }
                    
                    Text(
                        "Point the camera overlay to simulate scanning in-store sticker tag.",
                        textAlign = TextAlign.Center,
                        color = Color.Gray,
                        style = MaterialTheme.typography.bodySmall
                    )

                    Button(
                        onClick = { viewModel.triggerMockScan() },
                        colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                        enabled = !scanning,
                        modifier = Modifier.fillMaxWidth().testTag("scan_barcode_simulator_btn")
                    ) {
                        Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Trigger Simulated Scan", fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Display scanned item results
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Slate50),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(CircleShape)
                                    .background(Color.White),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(getEmojiForProduct(scannedProd!!.id), fontSize = 42.sp)
                            }

                            Text(
                                "Scanned Price Found!",
                                fontWeight = FontWeight.Bold,
                                color = OrganicGreen,
                                style = MaterialTheme.typography.bodySmall
                            )

                            Text(
                                scannedProd!!.title,
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.titleMedium,
                                color = Slate900
                            )

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "$${scannedProd!!.price}",
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 20.sp,
                                    color = FreshMartBlue
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("/ ${scannedProd!!.unit}", color = Color.Gray, fontSize = 12.sp)
                            }

                            Text(
                                scannedProd!!.description,
                                color = Color.Gray,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.bodySmall
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = { 
                                        viewModel.addToCart(scannedProd!!.id, 1)
                                        Toast.makeText(context, "${scannedProd!!.title} added!", Toast.LENGTH_SHORT).show()
                                        viewModel.closeScanner()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Add to Cart")
                                }
                                Button(
                                    onClick = { viewModel.openScanner() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray, contentColor = Slate900),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Scan Again")
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {}
    )
}

@Composable
fun SlidingBannersCarousel(
    banners: List<BannerEntity>,
    onBannerClick: (String) -> Unit
) {
    if (banners.isEmpty()) return

    var currentIndex by remember { mutableStateOf(0) }

    // Auto-slide loop effect
    LaunchedEffect(banners.size) {
        if (banners.size > 1) {
            while (true) {
                kotlinx.coroutines.delay(4000)
                currentIndex = (currentIndex + 1) % banners.size
            }
        }
    }

    AnimatedContent(
        targetState = currentIndex,
        transitionSpec = {
            (slideInHorizontally { width -> width } + fadeIn() togetherWith
                    slideOutHorizontally { width -> -width } + fadeOut())
                .using(SizeTransform(clip = false))
        },
        label = "BannerSlideAnimation"
    ) { index ->
        val banner = banners.getOrNull(index) ?: banners.first()
        val bgParsedColor = try {
            Color(android.graphics.Color.parseColor(banner.backgroundColor))
        } catch (e: Exception) {
            FreshMartBlue
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(
                    brush = Brush.horizontalGradient(
                        colors = listOf(bgParsedColor, bgParsedColor.copy(alpha = 0.85f))
                    )
                )
                .clickable { onBannerClick(banner.targetCategory) }
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1.3f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(Color.White.copy(alpha = 0.22f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "DEPARTMENT SPECIAL",
                            style = TextStyle(fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        )
                    }
                    Text(
                        text = banner.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold
                        ),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = banner.subtitle,
                        color = Color.White.copy(alpha = 0.9f),
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(0.7f)
                        .fillMaxHeight(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = banner.imageEmoji,
                        fontSize = 54.sp
                    )
                }
            }

            if (banners.size > 1) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(bottom = 2.dp, start = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    banners.forEachIndexed { i, _ ->
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(
                                    if (i == index) Color.White else Color.White.copy(alpha = 0.4f)
                                )
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderTrackingDialog(
    order: OrderEntity,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var riderProgress by remember { mutableStateOf(0.0f) }
    
    // Multiplier for live rider route progress animation when active in transit
    LaunchedEffect(order.status) {
        if (order.status == "In Transit") {
            while (true) {
                // Loop progress back and forth to simulate continuous road movement
                for (step in 0..120) {
                    riderProgress = step / 120.0f
                    kotlinx.coroutines.delay(120L)
                }
                kotlinx.coroutines.delay(1000L)
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false),
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        content = {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Slate900, // Elite Dark Hub Aesthetic
                modifier = Modifier
                    .widthIn(max = 500.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .border(2.dp, FreshMartBlue.copy(alpha = 0.3f), RoundedCornerShape(24.dp))
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Header Area
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (order.status == "Delivered") OrganicGreen else FreshMartAmber)
                                )
                                Text(
                                    "LIVE TRACKING",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.LightGray,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.2.sp
                                )
                            }
                            Text(
                                "Order ID: ${order.id}",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                                color = Color.White
                            )
                        }
                        IconButton(
                            onClick = onDismiss,
                            colors = IconButtonDefaults.iconButtonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close tracking board", tint = Color.White)
                        }
                    }

                    Divider(color = Color.White.copy(alpha = 0.1f), thickness = 1.dp)

                    // Stage Progress Nodes
                    val stages = listOf("Processing", "Preparing", "Out for Delivery/Pickup", "Arrived/Delivered")
                    val currentStageIndex = when (order.status) {
                        "Processing" -> 1
                        "Ready for Pickup" -> 2
                        "In Transit" -> 2
                        "Delivered" -> 3
                        else -> 0
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.04f), RoundedCornerShape(16.dp))
                            .padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "FULFILLMENT STEPPERS",
                            fontWeight = FontWeight.Bold,
                            color = FreshMartBlue,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        )

                        stages.forEachIndexed { idx, stageLabel ->
                            val isDone = idx < currentStageIndex
                            val isActive = idx == currentStageIndex
                            val tintColor = if (isDone) OrganicGreen else if (isActive) FreshMartBlue else Color.Gray

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(tintColor.copy(alpha = 0.15f))
                                        .border(2.dp, tintColor, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isDone) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = OrganicGreen,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(tintColor)
                                        )
                                    }
                                }

                                Column {
                                    Text(
                                        text = stageLabel,
                                        fontWeight = if (isActive) FontWeight.ExtraBold else FontWeight.Bold,
                                        color = if (isActive) Color.White else if (isDone) Color.LightGray else Color.Gray,
                                        fontSize = 13.sp
                                    )
                                    if (isActive) {
                                        val detailsText = when (order.status) {
                                            "Processing" -> "Our team is collecting your premium fresh selection from our organic partners right now..."
                                            "Ready for Pickup" -> "Ready at in-store counter! Visit our main Bangladesh retail hub to collect."
                                            "In Transit" -> "Our delivery rider is driving towards your destination coordinates safely."
                                            "Delivered" -> "Your package has been signed off. Enjoy your grocery collection!"
                                            else -> "Locating shipment records from Firestore..."
                                        }
                                        Text(
                                            text = detailsText,
                                            color = Color.LightGray,
                                            fontSize = 11.sp,
                                            lineHeight = 15.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Simulated Live Travel Map (Using Canvas)
                    if (order.deliveryType == "Delivery" && (order.status == "In Transit" || order.status == "Delivered")) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                "MAPPED ROUTE PREVIEW (LIVE)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = OrganicGreen,
                                letterSpacing = 1.sp
                            )

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF0F172A)) // Grid Map background
                            ) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    val startX = 60f
                                    val startY = size.height - 60f
                                    val endX = size.width - 60f
                                    val endY = 60f

                                    // Draw background streets
                                    val streetPaint = Color(0xFF1E293B)
                                    drawLine(streetPaint, Offset(0f, size.height/2), Offset(size.width, size.height/2), strokeWidth = 12f)
                                    drawLine(streetPaint, Offset(size.width/2, 0f), Offset(size.width/2, size.height), strokeWidth = 12f)

                                    // Draw dotted path curve from FreshMart center to customer home
                                    val pathColor = FreshMartBlue.copy(alpha = 0.5f)
                                    val steps = 20
                                    for (i in 0 until steps) {
                                        val t = i.toFloat() / steps
                                        val curX = startX + (endX - startX) * t
                                        val curY = startY + (endY - startY) * t - (kotlin.math.sin(t * kotlin.math.PI) * 50).toFloat()
                                        drawCircle(pathColor, radius = 4f, center = Offset(curX, curY))
                                    }

                                    // Draw Start and End Markers
                                    drawCircle(FreshMartBlue, radius = 9f, center = Offset(startX, startY))
                                    drawCircle(OrganicGreen, radius = 9f, center = Offset(endX, endY))

                                    // Compute Animated Rider coordinates on Bezier Curve
                                    val activeT = if (order.status == "Delivered") 1.0f else riderProgress
                                    val riderX = startX + (endX - startX) * activeT
                                    val riderY = startY + (endY - startY) * activeT - (kotlin.math.sin(activeT * kotlin.math.PI) * 50).toFloat()

                                    // Draw Rider moving glow circle
                                    drawCircle(Color(0xFFFBBF24), radius = 14f, center = Offset(riderX, riderY), alpha = 0.3f)
                                    drawCircle(Color(0xFFFBBF24), radius = 8f, center = Offset(riderX, riderY))
                                }

                                // Overlay Text Widgets on Map
                                Box(modifier = Modifier.align(Alignment.BottomStart).padding(6.dp)) {
                                    Text("🏪 FreshMart", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.background(Slate900.copy(alpha = 0.8f), RoundedCornerShape(3.dp)).padding(3.dp))
                                }
                                Box(modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)) {
                                    Text("🏠 Home (Verified)", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.background(Slate900.copy(alpha = 0.8f), RoundedCornerShape(3.dp)).padding(3.dp))
                                }
                                if (order.status == "In Transit") {
                                    Box(modifier = Modifier.align(Alignment.Center).padding(4.dp)) {
                                        Text("🚴 HIGHSPEED RIDER MOVING", color = Color(0xFFFBBF24), fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.background(Slate900.copy(alpha = 0.9f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                            }

                            // Rider Contact details frame
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color.White.copy(alpha = 0.05f), RoundedCornerShape(12.dp))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(FreshMartBlue.copy(alpha = 0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.DirectionsBike, contentDescription = null, tint = FreshMartBlue)
                                    }
                                    Column {
                                        Text("Mohammad Nayan", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                                        Text("Fast Delivery Specialist (Dhaka L-42)", color = Color.Gray, fontSize = 10.sp)
                                    }
                                }
                                Button(
                                    onClick = {
                                        Toast.makeText(context, "Navigating Phone dialer to: +8801755123456", Toast.LENGTH_SHORT).show()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Icon(Icons.Default.Phone, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Call Rider", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Scanning Barcode / In-Store Shelving Frame for Pickups
                    if (order.deliveryType == "Pickup") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.03f), RoundedCornerShape(16.dp))
                                .padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                "PICKUP HANDOFF BOARDING BARCODE",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = FreshMartAmber,
                                letterSpacing = 1.sp
                            )

                            // Render Custom styled Barcode pattern
                            Row(
                                modifier = Modifier
                                    .background(Color.White, RoundedCornerShape(8.dp))
                                    .padding(vertical = 12.dp, horizontal = 24.dp),
                                horizontalArrangement = Arrangement.spacedBy(1.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val barcodeHeights = listOf(
                                    40, 20, 45, 10, 40, 45, 15, 30, 40, 45,
                                    10, 35, 40, 15, 45, 35, 40, 10, 45, 30,
                                    40, 45, 20, 10, 35, 45, 40, 15, 45
                                )
                                barcodeHeights.forEach { h ->
                                    val w = if (h % 3 == 0) 3.dp else if (h % 2 == 0) 2.dp else 1.dp
                                    Box(
                                        modifier = Modifier
                                            .width(w)
                                            .height(h.dp)
                                            .background(Color.Black)
                                    )
                                }
                            }

                            Text(
                                text = "TXN-${order.id.uppercase()}",
                                fontSize = 11.sp,
                                color = Color.LightGray,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.2.sp
                            )

                            Divider(color = Color.White.copy(alpha = 0.05f))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("Pickup Shelf Location", color = Color.Gray, fontSize = 10.sp)
                                    Text("Shelf B - Bin Marker #07", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(FreshMartAmber.copy(alpha = 0.15f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("Counter #3", color = FreshMartAmber, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Order Summary items
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.02f), RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            "PAYMENT & TRANSACTION SUMMARY",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Gray,
                            letterSpacing = 1.sp
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Delivery Method", color = Color.LightGray, fontSize = 12.sp)
                            Text(order.deliveryType, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Charged Amount", color = Color.LightGray, fontSize = 12.sp)
                            Text("$${String.format("%.2f", order.total)}", color = OrganicGreen, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                        }

                        if (order.savings > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total Savings Recycled", color = Color.LightGray, fontSize = 12.sp)
                                Text("$${String.format("%.2f", order.savings)}", color = FreshMartBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    // Custom Support Button
                    Button(
                        onClick = {
                            Toast.makeText(context, "Connecting customer support helpline 16247...", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                    ) {
                        Icon(Icons.Default.SupportAgent, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Connect Shohid Support Hotline", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    )
}

@Composable
fun FirebaseTestScreen(viewModel: FreshMartViewModel, onBack: () -> Unit) {
    val firebaseTestState by viewModel.firebaseTestState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(FreshMartLightBg)
    ) {
        // App header bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 4.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Slate800
                )
            }
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Firebase Connection Test",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = Slate800
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Description card
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Slate100),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(FreshMartBlue.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("⚡", fontSize = 16.sp)
                        }
                        Text(
                            text = "Firestore Write Verification",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = Slate900
                        )
                    }
                    Text(
                        text = "This utility performs a live cloud write to verified Firestore servers. It will automatically initialize the database settings, create a 'test' collection, and check if writing is enabled.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
            }

            // Connection action button
            Button(
                onClick = { viewModel.runFirebaseConnectionTest() },
                colors = ButtonDefaults.buttonColors(containerColor = FreshMartBlue),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("firebase_connection_test_button"),
                shape = RoundedCornerShape(24.dp),
                enabled = firebaseTestState !is FirebaseTestState.Loading
            ) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.Cloud,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (firebaseTestState is FirebaseTestState.Loading) {
                            "Testing Connection..."
                        } else {
                            "Verify Connection"
                        },
                        style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    )
                }
            }

            // Results and States Area
            Spacer(modifier = Modifier.height(12.dp))

            when (val state = firebaseTestState) {
                is FirebaseTestState.Idle -> {
                    Text(
                        text = "Press button above to begin Firestore connection test.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.Gray
                    )
                }
                is FirebaseTestState.Loading -> {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(color = FreshMartBlue)
                        Text(
                            text = "Attempting to create and write test document... Please wait.",
                            textAlign = TextAlign.Center,
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                }
                is FirebaseTestState.Success -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = OrganicGreen.copy(alpha = 0.08f)),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, OrganicGreen.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(OrganicGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Success",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Text(
                                text = "Firebase Connected Successfully!",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = OrganicGreen,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = state.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate700,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                is FirebaseTestState.Error -> {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = RollbackRed.copy(alpha = 0.08f)),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, RollbackRed.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(RollbackRed),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Error,
                                    contentDescription = "Error",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }
                            Text(
                                text = "Connection Failed",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = RollbackRed,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = state.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = Slate700,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                text = "Please ensure your Firestore database is set up and rules are configured to permit public writes, or that you have specified valid Google Cloud credentials in the project configuration.",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.Gray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
